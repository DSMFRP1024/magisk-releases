#!/system/bin/sh
# customize.sh —— 安装时执行（只在 Magisk 安装阶段跑，不做任何清理动作）

SKIPUNZIP=1

ui_print "- TraceCleaner 安装中"

unzip -o "$ZIPFILE" 'module.prop' -d "$MODPATH" >/dev/null 2>&1
unzip -o "$ZIPFILE" 'bin/*' 'lib/*' 'conf/*' 'web/*' 'README.md' 'uninstall.sh' 'service.sh' -d "$MODPATH" >/dev/null 2>&1

set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm_recursive "$MODPATH/bin" 0 0 0755 0755
set_perm "$MODPATH/bin/tc" 0 0 0755
set_perm "$MODPATH/service.sh" 0 0 0755
# CGI 必须可执行（busybox httpd 只执行有执行位的文件），页面本体 0644
set_perm_recursive "$MODPATH/web/cgi-bin" 0 0 0755 0755
set_perm "$MODPATH/web/index.html" 0 0 0644

mkdir -p /data/adb/tracecleaner/log /data/adb/tracecleaner/backup /sdcard/TraceCleaner
chmod 700 /data/adb/tracecleaner /data/adb/tracecleaner/log /data/adb/tracecleaner/backup

# 首次安装才铺默认配置，升级不覆盖用户改过的白名单
if [ ! -f "$MODPATH/conf/whitelist.conf" ]; then
  cat > "$MODPATH/conf/whitelist.conf" <<'EOF'
# 白名单：这些包的数据目录/缓存永不被清理（一行一个包名，# 注释）
com.tencent.mm
com.tencent.mobileqq
com.android.systemui
com.miui.home
EOF
fi

ui_print "- 安装完成（模块不做任何开机自动清理）"
ui_print "- 用法：su -c 'sh $MODPATH/bin/tc scan'"
ui_print "- 清理默认是预演，必须加 --confirm"
ui_print "- WebUI：su -c 'sh $MODPATH/bin/tc web start'"
ui_print "-   然后电脑浏览器打开 http://127.0.0.1:6789"
ui_print "-   （先执行 adb forward tcp:6789 tcp:6789）"
