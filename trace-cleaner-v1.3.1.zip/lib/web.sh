# web.sh —— WebUI 服务管理（busybox httpd + CGI）
# 用法：tc web start [端口] | tc web stop | tc web restart | tc web status | tc web token

WEB_PORT_DEFAULT=6789
WEBROOT=$MODDIR/web

web_pidfile()  { printf '%s/httpd.pid' "$DATADIR/web"; }
web_portfile() { printf '%s/port' "$DATADIR/web"; }

web_ensure_token() {
  mkdir -p "$DATADIR/web" 2>/dev/null
  chmod 700 "$DATADIR/web" 2>/dev/null
  if [ ! -s "$DATADIR/web/token" ]; then
    "$BB" tr -dc 'A-Za-z0-9' < /dev/urandom 2>/dev/null | "$BB" head -c 32 > "$DATADIR/web/token"
    [ -s "$DATADIR/web/token" ] || "$BB" head -c 32 /dev/urandom > "$DATADIR/web/token"
    chmod 600 "$DATADIR/web/token" 2>/dev/null
  fi
}

# httpd 的 CGI 支持是编译选项，--help 看不出来；这里用最小实例实测一次
web_check_httpd() {
  local probe="$DATADIR/tmp/httpd-probe"
  mkdir -p "$probe/cgi-bin" 2>/dev/null
  printf '#!/system/bin/sh\nprintf "Status: 200 OK\\r\\nContent-Type: text/plain\\r\\n\\r\\ncgi-ok\\n"\n' > "$probe/cgi-bin/p"
  chmod 0755 "$probe/cgi-bin/p" 2>/dev/null
  "$BB" httpd -p 127.0.0.1:16789 -h "$probe" -f >/dev/null 2>&1 &
  local hp=$!
  "$BB" sleep 0.5
  local out
  out=$("$BB" wget -q -O - http://127.0.0.1:16789/cgi-bin/p 2>/dev/null)
  kill "$hp" 2>/dev/null
  rm -rf "$probe"
  [ "$out" = "cgi-ok" ] && return 0
  return 1
}

web_start() {
  local port=${1:-$WEB_PORT_DEFAULT}
  case "$port" in ''|*[!0-9]*) die "端口必须是数字" ;; esac
  [ "$port" -ge 1024 ] && [ "$port" -le 65535 ] || die "端口需在 1024-65535"
  [ -d "$WEBROOT" ] || die "缺少 $WEBROOT（模块安装不完整？）"
  web_ensure_token
  web_check_httpd || die "当前 busybox 的 httpd 不支持 CGI，无法启用 WebUI（可用 tc scan/clean 命令行）"

  # 默认只绑 127.0.0.1（adb forward 专用，局域网摸不到）；--lan 才绑全部网卡
  local bind=127.0.0.1
  shift 2>/dev/null
  while [ $# -gt 0 ]; do
    case "$1" in --lan) bind= ;; *) die "未知参数：$1（支持 --lan）" ;; esac
    shift
  done
  local listen
  if [ -n "$bind" ]; then listen="$bind:$port"; else listen="$port"; fi

  local pf; pf=$(web_pidfile)
  if job_running "$pf"; then
    echo "WebUI 已在运行（pid $(cat "$pf")，端口 $(cat "$(web_portfile)" 2>/dev/null)）"
    return 0
  fi
  rm -f "$pf"

  # -h webroot；-p 端口；-f 前台（由 start-stop-daemon -b 负责守护化；
  #   不加 -f 时 httpd 自己 fork，-m 写的 pid 是那个立刻退出的父进程）
  "$BB" start-stop-daemon -S -b -m -p "$pf" -x "$BB" -- httpd -f -p "$listen" -h "$WEBROOT" \
    || die "httpd 启动失败"
  # start-stop-daemon -m 会写 pid 文件；保险起见补一次探测
  local i=0
  while [ $i -lt 20 ]; do
    job_running "$pf" && break
    i=$((i + 1)); "$BB" sleep 0.1
  done
  job_running "$pf" || die "httpd 启动后立刻退出（端口被占？）"
  printf '%s' "$port" > "$(web_portfile)"
  if [ -n "$bind" ]; then
    echo "WebUI 已启动（仅本机回环，局域网不可达）"
  else
    echo "WebUI 已启动（--lan：监听全部网卡，敏感接口有令牌保护）"
  fi
  echo "  电脑访问：先执行  adb forward tcp:$port tcp:$port  然后浏览器打开  http://127.0.0.1:$port"
  [ -n "$bind" ] && echo "  要局域网访问：tc web start $port --lan"
  echo "  访问令牌：$("$BB" tr -d '\n' < "$DATADIR/web/token")"
  echo "  停止：su -c 'sh $MODDIR/bin/tc web stop'"
  log "web start port=$port bind=${bind:-0.0.0.0} pid=$(cat "$pf")"
}

web_stop() {
  local pf; pf=$(web_pidfile)
  if job_running "$pf"; then
    "$BB" start-stop-daemon -K -p "$pf" 2>/dev/null
    "$BB" sleep 0.2
    job_running "$pf" && kill "$(cat "$pf")" 2>/dev/null
    echo "WebUI 已停止"
    log "web stop"
  else
    echo "WebUI 未在运行"
  fi
  rm -f "$pf"
}

web_status() {
  local pf; pf=$(web_pidfile)
  echo "设备     : $(getprop ro.product.model) / Android $(getprop ro.build.version.release)"
  echo "模块     : $(grep '^version=' "$MODDIR/module.prop" | cut -d= -f2)"
  if job_running "$pf"; then
    echo "WebUI    : 运行中（pid $(cat "$pf")，端口 $(cat "$(web_portfile)" 2>/dev/null)）"
  else
    echo "WebUI    : 未运行（tc web start 启动）"
  fi
  echo "数据目录 : $DATADIR"
  echo "报告目录 : $OUTDIR"
  echo "访问令牌 : $("$BB" tr -d '\n' < "$DATADIR/web/token" 2>/dev/null)"
  echo "最近扫描 : $("$BB" ls -t "$OUTDIR"/scan-*.json 2>/dev/null | "$BB" head -n 1)"
}

web_roll_token() {
  web_ensure_token
  "$BB" tr -dc 'A-Za-z0-9' < /dev/urandom 2>/dev/null | "$BB" head -c 32 > "$DATADIR/web/token"
  chmod 600 "$DATADIR/web/token" 2>/dev/null
  echo "新令牌：$("$BB" tr -d '\n' < "$DATADIR/web/token")"
  echo "（页面里旧令牌立即失效，请用新令牌重新登录）"
}

web_main() {
  need_root "web"
  mkdir -p "$DATADIR/web" "$DATADIR/log" 2>/dev/null
  case "$1" in
    start)  shift; web_start "$@" ;;
    stop)   web_stop ;;
    restart) shift; web_stop; web_start "$@" ;;
    status) web_status ;;
    token|roll-token) web_roll_token ;;
    *) echo "用法：tc web start [端口] | stop | restart | status | token"; exit 2 ;;
  esac
}
