# TraceCleaner v1.4.0

Android（Magisk / KernelSU / APatch）上的「装过什么」痕迹检测与清理模块。

一句话定位：**查得出这台机器装过哪些应用、什么时候装的、什么时候卸的；然后按风险分级把痕迹清掉。**
默认只读扫描，任何删除都必须显式 `--confirm`，且删前先备份。

---

## 1. 它能查出什么

| 数据 | 来源 | 精度 |
|---|---|---|
| 当前已安装应用 | `pm list packages` + `dumpsys package` | 精确，含首次安装/最后更新时间、版本、安装路径 |
| 已卸载但仍被系统记住的包 | `pm list packages -u` 差集 | 精确（包名层面） |
| 卸载残留 | `/data/data`、`/data/user_de`、ART profile、`dalvik-cache`、`Android/data|obb` | 精确到路径与占用大小 |
| 孤儿目录 | 目录存在但包管理器里连 `-u` 都查不到 | 精确（这类通常连包名记录都没了） |
| 安装/卸载**事件流水** | 小米商店 `market_2.db` 的 `h_b` 表（`i`装/`d`下载/`u`卸载/`c`检查/`a`激活/`e`曝光/`up`更新检查） | 精确到毫秒，但只覆盖经过商店流程的操作 |
| 下载记录（带官方应用名） | 酷安 `download.db` | 精确 |
| 安装来源 | 安全中心 `appmanager_installer_pkg` | 精确 |
| 近一月行为上报 | 安全中心 `month_report.db` | 精确到事件 |
| 逐应用使用时长（~90 天） | 设置 `screen-time-database` | 精确到小时/时间段 |
| 使用/流量/进程统计 | `/data/system/usagestats`、`netstats`、`procstats` | 按统计粒度 |
| 崩溃、ANR、事件缓冲区 | `dropbox`、`anr`、`tombstones`、`logcat -b events` | 残留一段时间 |
| 可能被别的 App 存的「应用清单」文件 | ① 文件名特征匹配 ② **内容级匹配**（用全部已装包名当特征串搜 `databases/`、`shared_prefs/`、`files/`） | 内容级可靠：同一文件命中 ≥8 个不同包名才判定 |


### 查不到什么（别指望）

- **系统不保存"卸载时间"这个字段**。卸载时间只能从商店事件流水（`h_b` 的 `u`）拿到；
  不走商店、或用 `pm uninstall` 静默卸载的，系统里没有任何时间戳。
  用 `adb uninstall` 装的同理，只留下"曾装过"的名单（`pm -u` / 残留目录），没有时间。
- **`packages.xml` 在 Android 13 是 ABX 二进制**，不是文本，不能按 XML 解析。
- **删除 packages.xml / packages.list / runtime-permissions.xml 会直接让系统起不来**，
  模块把这些路径写进了硬保护名单，任何参数都删不掉。

---

## 2. 它能清什么（三个级别，逐级包含）

| 级别 | 内容 | 风险 | 系统是否自愈 |
|---|---|---|---|
| **L1** | `usagestats` / `netstats` / `procstats` / `dropbox` / `notification_log` / `jobs.xml` / `recent_tasks` / `recent_images` / `anr` / `tombstones` / `/data/log` / `/data/local/tmp` / `logcat` 缓冲区 | 低 | 会，重启后重建 |
| **L2** | 已卸载包的 `data`、`user_de`、ART profile、`dalvik-cache`、`Android/data|obb`；孤儿目录；`package_cache`；`--apks` 时连 `Download/*.apk` | 中 | 不会（这些本来就是要删的） |
| **L3** | 商店 `market_2.db`、酷安 `download.db`、安全中心 `appmanager_installer_pkg` + `month_report.db`、设置 `screen-time-database`、第三方缓存的「应用清单」文件；加 `--appdata` 时再加**其他软件数据里存的安装记录**（见下表） | 高（历史不可恢复，靠备份） | 应用会重建空库 |
| **L4** | LSPosed `modules_config.db`（需 `--xposed`，会让所有 Xposed 模块的启用状态丢失） | 高 | 不会 |

### L3 里 `--appdata` 的三档（默认不动）

检测方式：用全部已装包名当特征串，扫第三方应用的 `databases/`、`shared_prefs/`、`files/`，
**同一个文件里出现 ≥8 个不同包名**才判定"它存了一份应用清单"（低于 8 个的多半是 deeplink 配置、
某个 SDK 的白名单，不算快照，只列不判）。

| 档位 | 覆盖哪些文件 | 代价 |
|---|---|---|
| `--appdata`（= `cache`） | 扫描缓存：`pkgcache*`、`pkgquery*`、`junk*.db`、`clearpath*`、`applist*`、`installed_app*` | 删了应用会重建，**基本无感** |
| `--appdata=prefs` | 再加 `shared_prefs/*.xml` 和应用管理工具的主库（如 AppManager 的 `apps.db`） | 该应用**丢设置 / 丢历史记录**，靠备份回滚 |
| `--appdata=db` | 再加其他应用的主数据库（如酷安 `com.coolapk.market.v7.db`、相册 `gallery_sub.db`） | **删整库**，应用内数据全清空，只在明确知道后果时用 |


### 一条必须说清的事实

**"让别的应用看不到已安装列表"这件事，删文件做不到。**
任何持有 `QUERY_ALL_PACKAGES` 权限或 root 的程序，都能实时问 `PackageManager` 要列表；
这是进程间调用，不是读缓存文件。

模块能做的是把**历史侧的证据**抹掉：装过什么、什么时候装的、用了多久、什么时候卸的、
残留了什么——让"事后反查"断掉。
真要"隐藏应用列表"，得上 Xposed 级方案（Hide MyApplist / Hail 之类），那是另一个层次的事，
不在本模块范围内，模块的输出里也写明了这点。

---

## 3. 用法

```sh
# 只读扫描（不改任何东西）
su -c 'sh /data/adb/modules/trace_cleaner/bin/tc scan'

# 预演：看会删什么、释放多少空间，不实际删除
su -c 'sh /data/adb/modules/trace_cleaner/bin/tc clean --level 2'

# 真删（L2 = L1 + 卸载残留 + 孤儿目录）
su -c 'sh /data/adb/modules/trace_cleaner/bin/tc clean --level 2 --confirm'

# 清理后复核
su -c 'sh /data/adb/modules/trace_cleaner/bin/tc verify'

# 把历史库导出到 /sdcard/TraceCleaner/export，供 PC 端离线解析
su -c 'sh /data/adb/modules/trace_cleaner/bin/tc export'

# 检查更新 / 下载并安装新版（装完需重启）
su -c 'sh /data/adb/modules/trace_cleaner/bin/tc update'
su -c 'sh /data/adb/modules/trace_cleaner/bin/tc update install'
```

常用开关：

| 开关 | 作用 |
|---|---|
| `--level 1|2|3` | 清理级别，逐级包含 |
| `--appdata[=cache\|prefs\|db]` | L3 时清「其他软件数据里存的安装记录」，见上表；不带这个开关就只在扫描里列出、不删 |
| `--confirm` / `-y` | 真正执行；**不加就是预演** |
| `--no-backup` | 不备份（不推荐，仅用于日志这类无价值目标） |
| `--force` | ① 单目标超过 64 MB 也删；② L3 时允许清 `files/` 下的清单文件 |
| `--apks` | 连 `/sdcard/Download` 下的安装包一起删 |
| `--xposed` | 连 LSPosed 模块配置一起删 |

输出位置：

```
/sdcard/TraceCleaner/scan-<时间>.txt          人读报告
/sdcard/TraceCleaner/scan-<时间>.json         结构化数据（可喂给 tc_report.py 出 HTML）
/sdcard/TraceCleaner/scan-<时间>-*.tsv        已安装 / 残留 / 清单缓存明细
/sdcard/TraceCleaner/clean-<时间>.txt         清理流水
/data/adb/tracecleaner/backup/<时间>/         备份 + manifest.tsv（原路径 → 备份路径）
/data/adb/tracecleaner/log/clean.log          长期操作日志
```

---

## 3.4 三个入口，按你的 Root 管理器选

| 入口 | 出现在哪 | 依赖 |
|---|---|---|
| **模块页「操作」按钮** | Magisk / KernelSU / APatch 模块详情页 | 根目录 `action.sh` |
| **管理器内置 WebUI** | KernelSU / APatch / MMRL 模块页的「打开」 | `webroot/index.html` + `ksu.exec` |
| **浏览器 WebUI** | 手机或电脑的浏览器 | `tc web start`（busybox httpd） |

三者共用同一套逻辑（页面走 `tc json <op>`，命令行走 `tc scan|clean`），行为完全一致：
扫描只读、清理必须确认、删前自动备份。

**① 操作按钮**：点一下 = 起 WebUI 服务 + 用手机浏览器打开（URL 里带令牌，免手输）

```sh
su -c 'sh /data/adb/modules/trace_cleaner/action.sh'      # 等同于点按钮
su -c 'sh /data/adb/modules/trace_cleaner/bin/tc web open' # 只想起服务并开浏览器
```

**② KernelSU / APatch 内置 WebUI**：页面在 `webroot/index.html`，通过管理器的 `ksu.exec`
直接执行 root 命令——**不需要 httpd、不需要联网、不需要 adb**，手机上这是最顺的一条路。
页面有概览 / 扫描 / 清理 / 更新四个标签，手机宽度排版。

**③ 浏览器 WebUI**：见 3.5。同一份页面也会装一份到 `web/ksu.html`，
所以手机浏览器打开 `http://127.0.0.1:6789/ksu.html?token=<令牌>` 也能用（`?token=` 会自动登录）。

---

## 3.5 WebUI（浏览器里操作与查看）

模块内置一个跑在手机上的 Web 控制台（busybox httpd + CGI，零外部依赖，设备不用联网）：

```sh
# 启动（默认只绑 127.0.0.1:6789，局域网摸不到）
su -c 'sh /data/adb/modules/trace_cleaner/bin/tc web start'

# 想让局域网也能访问（敏感接口有令牌保护）
su -c 'sh /data/adb/modules/trace_cleaner/bin/tc web start 6789 --lan'
```

电脑上（USB 线或无线 adb 都行）：

```sh
adb forward tcp:6789 tcp:6789
# 浏览器打开  http://127.0.0.1:6789
# 想跳过手输令牌：http://127.0.0.1:6789/?token=<tc web status 里那串>
```

首次进入要输入**访问令牌**（随机 32 位，启动时生成）：

```sh
su -c 'sh /data/adb/modules/trace_cleaner/bin/tc web status'   # 看当前令牌
su -c 'sh /data/adb/modules/trace_cleaner/bin/tc web token'    # 换一个（旧的立即失效）
su -c 'sh /data/adb/modules/trace_cleaner/bin/tc web stop'     # 停掉
```

页面里能干什么：

| 页面 | 内容 |
|---|---|
| 概览 | 统计卡片（已安装/已卸载/残留/孤儿/历史来源/应用数据快照）、服务与任务状态 |
| 扫描结果 | 七类明细（已安装、已卸载、残留/孤儿、历史来源、应用清单缓存、应用数据快照），可搜索、可排序 |
| 清理 | 选 L1/L2/L3 + appdata 档位 + LSPosed/force/apks，先「预演」看输出，再输入 `CONFIRM` 真删 |
| 日志 | clean.log / scan.log / 最近清理输出，10 秒自动刷新 |

行为说明：扫描是**后台异步**的（点完「重新扫描」可以关页面，扫完自动刷新）；清理是同步执行，
深度清理要等一两分钟，前端有 loading；删前自动备份的逻辑与命令行完全一致。

安全设计：默认只听 `127.0.0.1`；`--lan` 时全部敏感接口校验随机令牌；确认清理要手输 `CONFIRM`；
`scan`/`clean` 之间有互斥，不会并发踩 `tmp` 目录。

关闭开机自启（模块默认在 `service.sh` 里拉起 WebUI）：

```sh
su -c 'touch /data/adb/modules/trace_cleaner/web/disabled'
su -c reboot
```

---

## 3.6 在线升级

三条路，任选：

| 方式 | 操作 |
|---|---|
| Magisk 应用 | 模块页会自动出现「更新」按钮（`module.prop` 里配了 `updateJson`） |
| WebUI | 顶部「更新」标签 → 检查更新 → 下载并安装（有新版时导航上带红点） |
| 命令行 | `tc update` 检查 · `tc update install` 下载并安装 |

```sh
su -c 'sh /data/adb/modules/trace_cleaner/bin/tc update'
# 当前版本 : v1.3.3（10303）
# 最新版本 : v1.3.3（10303）  来源 raw
# 状态     : 已是最新
```

实现要点：

- 清单和安装包在**公开分发仓** `DSMFRP1024/magisk-releases`（设备端没有 GitHub 凭据，
  私有源码仓拉不到）。三个源依次尝试：`raw.githubusercontent.com` → `ghfast.top`（raw 的国内代理）
  → `cdn.jsdelivr.net`（最后兜底），实际用了哪个会显示出来。
- 下载器探测式：系统 `curl` 优先（正规校验证书），Magisk busybox `wget` 兜底（不校验证书）。
- 装之前**先校验 `size` 再校验 `sha256`**，一致才交给 `magisk --install-module`。
- 装到 `modules_update/`，**必须重启手机才生效**——界面和命令行都会明确提示。
- 判定用 `versionCode` 比大小，CDN 缓存滞后只会"晚提示"，不会误装旧版。
- **多源都问一遍、取 `versionCode` 最大的那份**。只信第一个成功的源会出问题：raw 偶发不通时
  回退到 jsDelivr，而 jsDelivr 对 `@main` 缓存很久，会给旧清单，界面于是误报"已最新"。
- 清单 URL 带 `?ts=<时间戳>` 强制回源；安装包 URL 不带（含版本号，内容固定）。
- **发版纪律**：内容一变就升 `versionCode` 并换 zip 文件名，绝不在同一版本号下重发不同内容的包
  （否则各镜像缓存不一致，`size` 校验必然对不上）。
- 设备需要能上网；离线环境请手动 `adb push` 新 zip 用 `magisk --install-module` 安装。

---

### 在电脑上生成可交互报告

设备端已经产出 `scan-*.json`，电脑端可以把它渲染成可搜索、可排序的 HTML：

```sh
adb pull /sdcard/TraceCleaner/scan-20261022-193343.json ./scan.json
python tools/tc_report.py scan.json -o 报告.html
# 可选：--names names.json   其中 names.json = {"com.tencent.mm": "微信", ...}
```

## 4. 安全设计（为什么可以放心跑预演）

1. **默认只读**。`clean` 不加 `--confirm` 时 `DRYRUN=1`，只打印 `rm -rf` 计划，一行都不执行。
2. **删前必过 `guard_path()`**：
   - 必须是绝对路径、不含 `..`、深度 ≥ 3 段；
   - 命中 `PROTECT_EXACT`（`/data`、`/data/data`、`/data/system`、`/sdcard`……）直接拒绝；
   - `/data/system/packages.xml`、`packages.list`、`runtime-permissions.xml`、`appops.xml`、
     `role.xml` 属系统关键库，永久拒绝；
   - **已安装应用的 `/data/data/<pkg>` 包目录本身一律不动**（这是最容易被误删的一类）；
     包目录里的**子文件**只有在 `--appdata` 模式下、该包仍处于已安装状态、且不在白名单时才会被删。
3. **白名单**：`conf/whitelist.conf` 一行一个包名，命中即跳过（默认含微信、QQ、SystemUI、桌面）。
4. **备份优先**：删除前 `cp -a` 到 `/data/adb/tracecleaner/backup/<时间>/`，
   并把映射写进 `manifest.tsv`。单个目标 > 64 MB 时默认跳过删除，提示加 `--force`。
5. **删完复核**：每个目标删后都检查是否真的消失，失败会明确打 `[失败]`，退出码与日志同步记录。
6. **没有任何开机自动清理行为**。`service.sh` / `action.sh` 只做两件事：把 WebUI 服务拉起来、打开浏览器（可
   `touch /data/adb/modules/trace_cleaner/web/disabled` 关掉），后台不会偷偷清理——
   一切清理动作都由你在命令行或 WebUI 里显式触发。

### 恢复

```
备份目录结构：/data/adb/tracecleaner/backup/<时间>/
文件名规则：  /data/data/com.foo  →  data__data__com.foo
manifest.tsv： 原路径 <TAB> 备份路径
```

恢复一条：

```sh
su -c 'cp -a /data/adb/tracecleaner/backup/20261022-193000/data__data__com.foo /data/data/com.foo'
su -c 'chown -R $(stat -c %u:%g /data/data/com.bar) /data/data/com.foo'   # 属主参考同目录其它包
su -c 'restorecon -R /data/data/com.foo'
```

系统库类（usagestats / netstats 等）**不建议手工恢复**，重启后系统会自己重建。

---

## 5. 安装

```sh
# 标准安装（需重启生效）
adb push trace-cleaner-v1.4.0.zip /data/local/tmp/m.zip
adb shell su -c 'magisk --install-module /data/local/tmp/m.zip'

# 开发期免重启：直接铺到模块目录（本模块无开机脚本，铺完即可用）
adb push trace_cleaner /data/local/tmp/
adb shell su -c 'cp -a /data/local/tmp/trace_cleaner/. /data/adb/modules/trace_cleaner/'
```

卸载：Magisk 里移除即可，**不会删 `/data/adb/tracecleaner`**（备份留着，方便回滚取证）。

---

## 6. 已知限制

- 设备上**没有 `sqlite3`**，所以「只删某个包的行」做不到，L3 一律**整库删除**（靠备份回滚）。
  想精细手术：`tc export` 把库拉到 PC，用 Python `sqlite3` 改完再推回去。
- `usagestats` / `netstats` 由系统服务持有内存副本，删文件后**必须重启**才真正清空并重建。
- 「应用清单缓存」有两条识别路径：① 按文件名启发式匹配（`*applist*`、`*installed_app*`、`*packages.json` 等）；
  ② **内容级匹配**——用全部已装包名去搜第三方数据库/偏好/文件，命中 ≥8 个不同包名判定为快照。
  App 把清单加密或压缩成自定义格式时两条都识别不到。
- 内容级扫描要遍历约 3000 个文件，一次 `tc scan` 在 MI 8 上约 **2 分钟**（主要是逐个匹配进程开销）。
- MIUI 的 `packages.xml` 是 ABX 二进制，本模块只读不碰；能查到的包信息全部来自 `dumpsys package`。
