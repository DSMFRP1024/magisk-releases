/* ============================================================
   smsGateway 手机端 WebUI
   后端：webroot/cgi-bin/api（busybox httpd CGI → bin/ctl.sh）
   约定：写操作走 POST，请求体是 base64url 的原文 —— 见 cgi-bin/api 顶部注释。
   ============================================================ */
(function () {
  "use strict";

  var API = "cgi-bin/api";
  var S = { st: null, sims: [], msgs: [], timer: null };

  function $(id) { return document.getElementById(id); }

  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  // ---------- base64url（UTF-8，去掉 = 填充） ----------
  function b64u(str) {
    var bytes, i, bin = "";
    if (window.TextEncoder) {
      bytes = new TextEncoder().encode(str);
      for (i = 0; i < bytes.length; i++) bin += String.fromCharCode(bytes[i]);
    } else {
      bin = unescape(encodeURIComponent(str)); // 老 WebView 兜底
    }
    return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
  }

  // ---------- 请求 ----------
  function api(op, params, body) {
    var qs = "op=" + encodeURIComponent(op);
    if (params) {
      for (var k in params) {
        if (params[k] !== undefined && params[k] !== null) {
          // busybox httpd 不解码 QUERY_STRING，参数值只能是数字/简单键名
          qs += "&" + k + "=" + encodeURIComponent(params[k]);
        }
      }
    }
    var opt = { cache: "no-store" };
    if (body !== undefined) { opt.method = "POST"; opt.body = body; }
    return fetch(API + "?" + qs, opt).then(function (r) {
      return r.text().then(function (t) {
        var j;
        try { j = t ? JSON.parse(t) : {}; }
        catch (e) { throw new Error(t.slice(0, 200) || ("HTTP " + r.status)); }
        if (!r.ok || j.ok === false) throw new Error(j.err || ("HTTP " + r.status));
        return j;
      });
    });
  }

  // ---------- toast ----------
  var tT = null;
  function toast(msg, isErr) {
    var el = $("toast");
    el.textContent = msg;
    el.className = "toast" + (isErr ? " err" : "");
    el.hidden = false;
    clearTimeout(tT);
    tT = setTimeout(function () { el.hidden = true; }, isErr ? 5000 : 2200);
  }

  function fail(e) { toast(e && e.message ? e.message : String(e), true); }

  // ---------- 时间 ----------
  function ts2str(sec) {
    if (!sec || sec < 1000) return "—";
    var d = new Date(sec * 1000), now = new Date();
    var hm = ("0" + d.getHours()).slice(-2) + ":" + ("0" + d.getMinutes()).slice(-2);
    var ss = ("0" + d.getSeconds()).slice(-2);
    if (d.toDateString() === now.toDateString()) return hm + ":" + ss;
    return (d.getMonth() + 1) + "/" + d.getDate() + " " + hm;
  }

  function ago(sec) {
    if (!sec || sec < 1000) return "从未";
    var s = Math.floor(Date.now() / 1000 - sec);
    if (s < 0) return "刚刚";
    if (s < 60) return s + " 秒前";
    if (s < 3600) return Math.floor(s / 60) + " 分钟前";
    if (s < 86400) return Math.floor(s / 3600) + " 小时前";
    return Math.floor(s / 86400) + " 天前";
  }

  // ---------- 运行状态 ----------
  function kv(list) {
    var h = "";
    for (var i = 0; i < list.length; i++) {
      h += "<dt>" + esc(list[i][0]) + "</dt><dd" +
        (list[i][2] ? ' class="' + list[i][2] + '"' : "") + ">" +
        (list[i][3] ? list[i][1] : esc(list[i][1])) + "</dd>";
    }
    return h;
  }

  function loadStatus() {
    return api("status").then(function (r) {
      var st = r.st || {}, db = st.db || {};
      S.st = st;

      $("runDot").className = "dot " + (st.running ? "on" : "off");
      $("ver").textContent = "v" + (st.ver || "?");

      var hub = st.hub_url || "（未配置）";
      var tok = st.has_token ? "✓ 已配" : "✗ 未配";
      $("headMeta").innerHTML =
        esc((st.dev || "?") + " · " + hub + " · 令牌 " + tok +
            " · WebUI " + (r.webui && r.webui.running ? ":" + r.webui.port : "已停"));
      $("headMeta").title = st.hub_url || "";

      $("kvStatus").innerHTML = kv([
        ["守护进程", st.running ? "运行中（pid " + st.pid + "）" : "未运行", st.running ? "ok" : "bad"],
        ["开关 enabled", st.enabled ? "开" : "关（停了收发）", st.enabled ? "ok" : "bad"],
        ["设备名", st.dev || "?"],
        ["硬件码", st.hw || "?"],
        ["库内短信", "共 " + (db.total || 0) + " 条 / 收件箱 " + (db.inbox || 0) + " 条 / 最大 id " + (db.max || 0)],
        ["最近收信", ago(st.last_sms_ts) + "（" + ts2str(st.last_sms_ts) + "）"],
        ["最近心跳", ago(st.last_hb_ts)],
        ["水位 last_id", st.last_id + " / last_ts " + st.last_ts],
        ["间隔", "收信 " + st.poll + "s · 指令 " + st.cmd + "s · 心跳 " + st.hb + "s"],
        ["短信库", db.db || "（未找到）"]
      ]);

      if (!$("cfgHubUrl").value) fillCfg(st);
      return r;
    });
  }

  function fillCfg(st) {
    $("cfgHubUrl").value = st.hub_url || "";
    $("cfgHooks").value = st.webhooks || "";
    $("cfgPoll").value = st.poll;
    $("cfgCmd").value = st.cmd;
  }

  // ---------- 双卡 ----------
  function loadSims() {
    var box = $("simList");
    return api("sims").then(function (r) {
      S.sims = r.items || [];
      if (!S.sims.length) {
        box.innerHTML = '<p class="muted">没有读到 SIM 卡（可能未插卡）</p>';
      } else {
        box.innerHTML = S.sims.map(function (s) {
          var slotTxt = s.slot > 0 ? "卡" + s.slot : "卡?";
          var line2 = ["subId " + s.sub];
          if (s.carrier) line2.push(s.carrier);
          if (s.mcc) line2.push("MCC " + s.mcc + "/MNC " + s.mnc);
          return '<div class="sim"><div class="slot">' + esc(slotTxt) + "</div>" +
            '<div class="info"><b>' + esc(s.name || s.carrier || "未命名") + "</b>" +
            "<small>" + esc(line2.join(" · ")) + "</small></div></div>";
        }).join("");
      }
      // 同步到发送用的卡槽下拉
      var sel = $("sendSub"), keep = sel.value;
      sel.innerHTML = '<option value="0">自动（系统默认卡）</option>';
      S.sims.forEach(function (s) {
        var o = document.createElement("option");
        o.value = String(s.sub);
        o.textContent = (s.slot > 0 ? "卡" + s.slot : "sub " + s.sub) +
          (s.carrier ? " · " + s.carrier : "");
        sel.appendChild(o);
      });
      if (keep) sel.value = keep;
    }).catch(function (e) {
      box.innerHTML = '<p class="muted">读取失败：' + esc(e.message) + "</p>";
    });
  }

  // ---------- 最近短信 ----------
  function loadMsgs() {
    var box = $("msgList");
    return api("msgs", { n: 30 }).then(function (r) {
      S.msgs = r.items || [];
      $("msgCount").textContent = "共 " + S.msgs.length + " 条";
      if (!S.msgs.length) {
        box.innerHTML = '<p class="muted">库里还没有短信</p>';
        return;
      }
      // 后端按 _id 升序返回，界面上按时间倒序更顺手
      var arr = S.msgs.slice().reverse();
      box.innerHTML = arr.map(function (m) {
        return '<div class="msg"><div class="t">' + esc(ts2str((m.ts || 0) / 1000)) +
          '</div><div class="a">' + esc(m.addr || "") +
          (m.sub >= 0 ? ' · sub ' + m.sub : "") +
          '</div><div class="b">' + esc(m.body || "") + "</div></div>";
      }).join("");
    }).catch(function (e) {
      box.innerHTML = '<p class="muted">读取失败：' + esc(e.message) + "</p>";
    });
  }

  // ---------- 日志 ----------
  function loadLog() {
    return fetch(API + "?op=log&n=60", { cache: "no-store" })
      .then(function (r) { return r.text(); })
      .then(function (t) {
        $("logBox").textContent = t || "（日志为空）";
        $("logBox").scrollTop = $("logBox").scrollHeight;
      })
      .catch(function (e) { $("logBox").textContent = "读取失败：" + e.message; });
  }

  // ---------- 模块升级 ----------
  // 清单在公开仓（设备端没有 GitHub 凭据，私有源码仓拉不到）；
  // 后端 ctl.sh check-update 直接吐完整 JSON，这里不做二次包装。
  var U = { cur: null };

  function fmtSize(n) {
    if (!n) return "—";
    return n >= 1048576 ? (n / 1048576).toFixed(1) + " MB" : Math.round(n / 1024) + " KB";
  }

  function loadUpdate() {
    var box = $("kvUpd");
    if (!box) return Promise.resolve();
    box.innerHTML = '<dt>状态</dt><dd class="muted">查询中…</dd>';
    return api("check-update").then(function (r) {
      U.cur = r;
      var tag = $("updTag");
      tag.textContent = r.hasUpdate ? "有新版本" : "已是最新";
      tag.className = "muted" + (r.hasUpdate ? " hot" : "");

      var rows = [
        ["当前版本", r.current + "（versionCode " + r.currentCode + "）"],
        ["最新版本", r.latest + "（versionCode " + r.latestCode + "）", r.hasUpdate ? "warn" : ""],
        ["清单来源", r.source === "jsdelivr" ? "jsDelivr（raw 不通时的兜底）" : "raw.githubusercontent"],
        ["发布时间", r.date || "—"]
      ];
      if (r.hasUpdate) {
        rows.push(["包大小", fmtSize(r.size)]);
        rows.push(["更新摘要", r.notes || "—"]);
      }
      box.innerHTML = kv(rows);

      var b = $("btnDoUpd");
      b.hidden = !r.hasUpdate;
      b.textContent = "下载并安装 " + r.latest;
      return r;
    }).catch(function (e) {
      box.innerHTML = '<dt>状态</dt><dd class="bad">' + esc(e.message) + "</dd>";
      $("btnDoUpd").hidden = true;
    });
  }

  function doUpdate() {
    if (!U.cur || !U.cur.hasUpdate) { toast("先检查更新", true); return; }
    // ★ 装完落在 modules_update/，不重启不生效 —— 必须提前说清楚，否则用户以为点了没反应
    if (!confirm("下载并安装 " + U.cur.latest + "？\n\n装完会进入 modules_update/，必须重启手机才生效。")) return;

    var btn = $("btnDoUpd"), log = $("updLog");
    btn.disabled = true;
    btn.textContent = "下载中…";
    log.hidden = false;
    log.textContent = "正在下载并校验（大小 + sha256）…";

    api("update-install").then(function (r) {
      log.textContent = "已安装 " + r.installed +
        "（sha256 " + String(r.sha256 || "").slice(0, 12) + "…，来源 " + r.source + "）\n" +
        "★ 必须重启手机才生效（包已放进 modules_update/）\n\n" + (r.log || "");
      toast("已安装，重启手机后生效");
    }).catch(function (e) {
      log.textContent = "失败：" + e.message;
      fail(e);
    }).then(function () {
      btn.disabled = false;
      btn.hidden = true;
      loadStatus().catch(function () {});
    });
  }

  // ---------- 发送 ----------
  function doSend() {
    var to = $("sendTo").value.trim();
    var text = $("sendText").value;
    if (!to) { toast("先填收件号码", true); return; }
    if (!text) { toast("先填短信内容", true); return; }
    var btn = $("btnSend");
    btn.disabled = true;
    $("sendHint").textContent = "发送中…";
    api("send", { sub: $("sendSub").value || 0, to: to }, b64u(text))
      .then(function (r) {
        var res = r.res || {};
        // dex 的返回：{"ok":true,...} 或 {"ok":false,"err":"..."}
        if (res.ok === false) {
          $("sendHint").textContent = "";
          toast("发送失败：" + (res.err || "未知错误"), true);
        } else {
          $("sendHint").textContent = "已提交：" + ts2str(Math.floor(Date.now() / 1000));
          toast("已发送（或已进入发件箱）");
          $("sendText").value = "";
          setTimeout(function () { loadMsgs(); }, 2500);
        }
      })
      .catch(fail)
      .then(function () { btn.disabled = false; });
  }

  // ---------- 保存配置 ----------
  function saveCfg() {
    var items = [
      ["hub_url", $("cfgHubUrl").value.trim()],
      ["hub_token", $("cfgToken").value.trim()],
      ["webhooks", $("cfgHooks").value.trim()],
      ["poll_interval", $("cfgPoll").value.trim()],
      ["cmd_interval", $("cfgCmd").value.trim()]
    ];
    // hub_token 留空表示「不改」，避免把已有令牌刷掉
    var todo = items.filter(function (it) { return it[1] !== ""; });
    if (!todo.length) { toast("没有要保存的改动"); return; }

    var btn = $("btnSaveCfg");
    btn.disabled = true;
    var chain = Promise.resolve();
    var bad = [];
    todo.forEach(function (it) {
      chain = chain.then(function () {
        return api("set", { k: it[0] }, b64u(it[1])).then(function (r) {
          if (r.res && r.res.ok === false) bad.push(it[0] + "：" + (r.res.err || "失败"));
        }).catch(function (e) { bad.push(it[0] + "：" + e.message); });
      });
    });
    chain.then(function () {
      btn.disabled = false;
      if (bad.length) { toast("部分未保存 — " + bad.join("；"), true); }
      else { toast("已保存，守护进程下一轮生效（约 15–30 秒）"); }
      $("cfgToken").value = "";
      loadStatus().catch(function () {});
    });
  }

  // ---------- 事件 ----------
  function bind() {
    $("btnReload").onclick = function () { refresh(); };
    $("btnSync").onclick = function () {
      api("sync").then(function () { toast("已回退水位，下一轮会补推"); })
        .catch(fail);
    };
    $("btnRestart").onclick = function () {
      if (!confirm("重启手机端守护进程？")) return;
      api("restart").then(function (r) {
        var res = r.res || {};
        if (res.ok === false) toast("重启失败：" + (res.err || ""), true);
        else toast("已重启（pid " + res.pid + "）");
        setTimeout(function () { loadStatus().catch(function () {}); }, 1500);
      }).catch(fail);
    };
    $("btnSims").onclick = function () { loadSims(); toast("已重新读取"); };
    $("btnCheckUpd").onclick = function () {
      var b = $("btnCheckUpd");
      b.disabled = true;
      loadUpdate().then(function () { b.disabled = false; });
    };
    $("btnDoUpd").onclick = doUpdate;
    $("btnSend").onclick = doSend;
    $("btnSaveCfg").onclick = saveCfg;
  }

  function refresh() {
    loadStatus().catch(fail);
    loadUpdate();
    loadSims();
    loadMsgs();
    loadLog();
  }

  // 状态每 10 秒刷一次（后台标签页不刷，省电）
  function startTimer() {
    clearInterval(S.timer);
    S.timer = setInterval(function () {
      if (document.hidden) return;
      loadStatus().catch(function () {});
    }, 10000);
  }

  function boot() {
    bind();
    refresh();
    startTimer();
    document.addEventListener("visibilitychange", function () {
      if (!document.hidden) loadStatus().catch(function () {});
    });
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
})();
