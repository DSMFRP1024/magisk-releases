# util.sh —— TraceCleaner 公共函数
# 依赖：调用方已导出 MODDIR / BB

DATADIR=${DATADIR:-/data/adb/tracecleaner}
OUTDIR=${OUTDIR:-/sdcard/TraceCleaner}
export LC_ALL=C

ts_now() { "$BB" date '+%Y-%m-%d %H:%M:%S'; }
ts_name() { "$BB" date '+%Y%m%d-%H%M%S'; }

# 同时写控制台与报告文件
o() { printf '%s\n' "$*" >> "$OUT"; printf '%s\n' "$*"; }

log() {
  mkdir -p "$DATADIR/log" 2>/dev/null
  printf '%s %s\n' "$("$BB" date '+%Y-%m-%d %H:%M:%S')" "$*" >> "$DATADIR/log/clean.log"
}

die() { printf '[错误] %s\n' "$*" >&2; exit 1; }

warn() { printf '[警告] %s\n' "$*" >&2; }

# JSON 字符串转义（只转义反斜杠与双引号，够用且不依赖分支配对）
jstr() {
  printf '"%s"' "$(printf '%s' "$1" | "$BB" sed -e 's/[\\"]/\\&/g' | "$BB" tr -d '\n\r')"
}

kb2human() {
  _k=${1:-0}
  case "$_k" in ''|*[!0-9]*) _k=0 ;; esac
  if [ "$_k" -ge 1048576 ]; then
    printf '%s.%s GB' $((_k / 1048576)) $((( _k % 1048576 ) * 10 / 1048576))
  elif [ "$_k" -ge 1024 ]; then
    printf '%s MB' $((_k / 1024))
  else
    printf '%s KB' "$_k"
  fi
}

# ---------------- 安全防护 ----------------
# 这些路径本身（或作为前缀的顶层目录）绝不允许被整棵删除
PROTECT_EXACT="/ /data /data/data /data/system /data/user /data/user/0 /data/user_de /data/user_de/0 \
/data/adb /data/app /data/dalvik-cache /data/local /data/local/tmp /data/misc /data/media \
/data/media/0 /data/media/0/Android /sdcard /storage/emulated/0 /system /vendor /product \
/data/system/users /data/system/users/0 /data/misc/profiles /data/misc/profiles/cur /data/misc/profiles/ref"

guard_path() {
  _p=$1
  case "$_p" in /*) ;; *) return 1 ;; esac
  case "$_p" in *..*) return 1 ;; esac
  case "$_p" in */) return 1 ;; esac
  # 必须至少有 3 层目录（/data/data/<pkg> 之类）
  _n=$(printf '%s' "$_p" | "$BB" awk -F/ '{print NF}')
  case "$_n" in ''|*[!0-9]*) return 1 ;; esac
  [ "$_n" -ge 4 ] || return 1
  for _x in $PROTECT_EXACT; do
    [ "$_p" = "$_x" ] && return 1
  done
  # 本模块自身与数据目录永不清理
  case "$_p" in
    "$MODDIR"|"$MODDIR"/*|"$DATADIR"|"$DATADIR"/*) return 1 ;;
  esac
  # 系统关键库：只读，永不删除
  case "$_p" in
    /data/system/packages.xml|/data/system/packages.xml*|/data/system/packages.list|/data/system/packages-backup.xml) return 1 ;;
    /data/system/users/*/runtime-permissions.xml) return 1 ;;
    /data/system/appops.xml|/data/system/role.xml|/data/system/device_policies.xml) return 1 ;;
    /data/misc/profiles/cur/0|/data/misc/profiles/ref) return 1 ;;
  esac
  # 已安装应用的私有目录：
  #   · 包目录本身（/data/data/<pkg>）→ 永不允许删（本模块不提供整目录删除）
  #   · 包目录内部的子文件 → 仅在 --appdata 模式下、且该包已安装、且不在白名单时才放行
  case "$_p" in
    /data/data/*|/data/user/0/*|/data/user_de/0/*)
      _pkg=$(printf '%s' "$_p" | "$BB" sed 's|^/data/data/||; s|^/data/user/0/||; s|^/data/user_de/0/||; s|/.*||')
      _nf=$(printf '%s' "$_p" | "$BB" awk -F/ '{print NF}')
      case "$_nf" in ''|*[!0-9]*) return 1 ;; esac
      if [ "$_nf" -ge 6 ] && [ "$ALLOW_APPDATA" = 1 ] && is_installed "$_pkg"; then
        in_whitelist "$_pkg" && return 1
        return 0
      fi
      if [ "$ALLOW_INSTALLED" != 1 ] && [ -n "$_pkg" ] && is_installed "$_pkg"; then
        return 1
      fi
      ;;
  esac
  return 0
}

is_installed() {
  [ -f "$TMP/inst.txt" ] || return 1
  "$BB" grep -qxF "$1" "$TMP/inst.txt"
}

in_whitelist() {
  [ -f "$MODDIR/conf/whitelist.conf" ] || return 1
  "$BB" grep -qxF "$1" "$MODDIR/conf/whitelist.conf"
}

# 备份单个路径；超过 BACKUP_MAX_MB 且未 --force 时拒绝（返回 2）
BACKUP_MAX_MB=${BACKUP_MAX_MB:-64}
BACKUP_ROOT=

bk_init() {
  [ -n "$BACKUP_ROOT" ] && return 0
  BACKUP_ROOT="$DATADIR/backup/$(ts_name)"
  mkdir -p "$BACKUP_ROOT" || return 1
}

bk_path() {
  [ "$DO_BACKUP" = 1 ] || return 0
  _src=$1
  _kb=$("$BB" du -sk "$_src" 2>/dev/null | "$BB" cut -f1)
  case "$_kb" in ''|*[!0-9]*) _kb=0 ;; esac
  if [ "$_kb" -gt $((BACKUP_MAX_MB * 1024)) ] && [ "$FORCE" != 1 ]; then
    return 2
  fi
  bk_init || return 1
  _safe=$(printf '%s' "$_src" | "$BB" sed 's|^/||; s|/|__|g')
  "$BB" cp -a "$_src" "$BACKUP_ROOT/$_safe" 2>/dev/null || "$BB" cp -r "$_src" "$BACKUP_ROOT/$_safe" 2>/dev/null
  if [ -e "$BACKUP_ROOT/$_safe" ]; then
    printf '%s\t%s\n' "$_src" "$BACKUP_ROOT/$_safe" >> "$BACKUP_ROOT/manifest.tsv"
    return 0
  fi
  return 1
}

# 删除：先 guard，再备份，再删，最后复核
DEL_OK=0
DEL_FREE_KB=0
do_rm() {
  _t=$1
  [ -e "$_t" ] || return 0
  if ! guard_path "$_t"; then
    o "   [跳过·保护] $_t"
    log "SKIP-GUARD $_t"
    return 1
  fi
  case "$_t" in
    /data/data/*|/data/user/0/*|/data/user_de/0/*|/data/media/0/Android/*)
      _wpkg=$(printf '%s' "$_t" | "$BB" sed 's|^/data/data/||; s|^/data/user/0/||; s|^/data/user_de/0/||; s|^/data/media/0/Android/[^/]*/||; s|/.*||')
      if [ -n "$_wpkg" ] && in_whitelist "$_wpkg"; then
        o "   [跳过·白名单] $_t"
        log "SKIP-WHITELIST $_t"
        return 1
      fi
      ;;
  esac
  _kb=$("$BB" du -sk "$_t" 2>/dev/null | "$BB" cut -f1)
  case "$_kb" in ''|*[!0-9]*) _kb=0 ;; esac
  if [ "$DRYRUN" = 1 ]; then
    o "   [dry] rm -rf $_t  ($(kb2human "$_kb"))"
    DEL_OK=$((DEL_OK + 1))
    DEL_FREE_KB=$((DEL_FREE_KB + _kb))
    return 0
  fi
  bk_path "$_t"
  case $? in
    2) o "   [跳过·备份超限] $_t ($(kb2human "$_kb")) —— 加 --force 可在不备份的情况下删除"; log "SKIP-BIG $_t"; return 1 ;;
    1) warn "备份失败，已跳过：$_t"; log "SKIP-BACKUP-FAIL $_t"; return 1 ;;
  esac
  "$BB" rm -rf "$_t" 2>/dev/null
  if [ -e "$_t" ]; then
    o "   [失败] $_t"
    log "FAIL $_t"
    return 1
  fi
  o "   [已删] $_t  ($(kb2human "$_kb"))"
  log "DEL $_t kb=$_kb"
  DEL_OK=$((DEL_OK + 1))
  DEL_FREE_KB=$((DEL_FREE_KB + _kb))
  return 0
}

# 通配批量删除：逐个展开，套用 do_rm
do_rm_glob() {
  for _f in $1; do
    [ -e "$_f" ] || continue
    do_rm "$_f"
  done
}
