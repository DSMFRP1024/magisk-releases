#!/system/bin/sh
# customize.sh —— 安装时执行（只在 Magisk 安装阶段跑，不做任何清理动作）

SKIPUNZIP=1

ui_print "- TraceCleaner 安装中"

unzip -o "$ZIPFILE" 'module.prop' -d "$MODPATH" >/dev/null 2>&1
unzip -o "$ZIPFILE" 'bin/*' 'lib/*' 'conf/*' 'README.md' 'uninstall.sh' -d "$MODPATH" >/dev/null 2>&1

set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm_recursive "$MODPATH/bin" 0 0 0755 0755
set_perm "$MODPATH/bin/tc" 0 0 0755

mkdir -p /data/adb/tracecleaner/log /data/adb/tracecleaner/backup /sdcard/TraceCleaner
chmod 700 /data/adb/tracecleaner /data/adb/tracecleaner/log /data/adb/tracecleaner/backup

# 首次安装才铺默认配置，升级不覆盖用户改过的白名单
if [ ! -f "$MODPATH/conf/whitelist.conf" ]; then
  cat > "$MODPATH/conf/whitelist.conf" <<'EOF'
# 白名单：这些包的数据目录/缓存永不被清理（一行一个包名，# 注释）
com.tencent.mm
com.tencent.mobileqq
com.android.systemui
com.miui.home
EOF
fi

ui_print "- 安装完成（模块不做任何开机自动清理）"
ui_print "- 用法：su -c 'sh $MODPATH/bin/tc scan'"
ui_print "- 清理默认是预演，必须加 --confirm"
