#!/system/bin/sh
# uninstall.sh —— 卸载时保留备份（不删 /data/adb/tracecleaner，方便回滚取证）
# 本模块没有修改任何系统属性/规则，无需还原任何状态。
rm -rf "$MODPATH/bin" "$MODPATH/lib" "$MODPATH/conf" "$MODPATH/module.prop" 2>/dev/null
