#!/bin/sh
# Magisk 模块『操作』按钮：启动 WebUI 服务并打开浏览器
MODDIR=${0%/*}
# ★ 归一化成绝对路径（原因见 bin/webui.sh）：Magisk 可能以 ./action.sh 执行。
_mgsd=${0%/*}; [ "$_mgsd" = "$0" ] && _mgsd=.
MODDIR=$(cd "$_mgsd" 2>/dev/null && pwd) || MODDIR=$_mgsd

export PATH=/data/adb/magisk:/system/bin:/system/xbin

BB=""
for _c in /data/adb/magisk/busybox /data/adb/ksu/bin/busybox /data/adb/ap/bin/busybox \
          /data/adb/modules/busybox-ndk/system/bin/busybox /system/xbin/busybox /system/bin/busybox; do
  if [ -x "$_c" ]; then BB=$_c; break; fi
done
if [ -z "$BB" ]; then command -v busybox >/dev/null 2>&1 && BB=$(command -v busybox); fi
if [ -z "$BB" ]; then BB=/data/adb/magisk/busybox; fi

$BB sh $MODDIR/bin/webui.sh start
$BB sh $MODDIR/bin/webui.sh open
echo ""
$BB sh $MODDIR/bin/ctl.sh brief
