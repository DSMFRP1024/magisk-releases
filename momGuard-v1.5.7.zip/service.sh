#!/system/bin/sh
# ============================================================
# momGuard 开机启动：拉起守护进程（可选：自启 WebUI 服务）
# ============================================================
MODDIR=${0%/*}
# ★ 归一化成绝对路径：Magisk 执行模块脚本时 $0 可能形如 `./service.sh`，
#   此时 ${0%/*} = `.`，会让下游（webui.sh 起 httpd）拿到相对 webroot 路径，
#   导致 pkill 匹配串对不上、httpd 杀不掉。统一绝对化。
_mgsd=${0%/*}; [ "$_mgsd" = "$0" ] && _mgsd=.
MODDIR=$(cd "$_mgsd" 2>/dev/null && pwd) || MODDIR=$_mgsd
MG=/data/adb/momguard

export PATH=/data/adb/magisk:/system/bin:/system/xbin

# ---------- busybox 定位 ----------
BB=""
for _c in /data/adb/magisk/busybox /data/adb/ksu/bin/busybox /data/adb/ap/bin/busybox \
          /data/adb/modules/busybox-ndk/system/bin/busybox /system/xbin/busybox /system/bin/busybox; do
  if [ -x "$_c" ]; then BB=$_c; break; fi
done
if [ -z "$BB" ]; then command -v busybox >/dev/null 2>&1 && BB=$(command -v busybox); fi
if [ -z "$BB" ]; then BB=/data/adb/magisk/busybox; fi

mkdir -p $MG/log $MG/state $MG/run
[ -f $MG/config.conf ] || cp -f $MODDIR/bin/config.default $MG/config.conf

# 后台等待开机完成，避免与系统启动抢占资源
(
  i=0
  while [ "$(getprop sys.boot_completed)" != "1" ] && [ $i -lt 150 ]; do
    $BB sleep 2
    i=$((i + 1))
  done
  $BB sleep 5

  # 记录守护启动时间（先删除旧值，避免多行累积）
  $BB sed -i '/^guard_started=/d' $MG/state/stats.conf 2>/dev/null
  printf 'guard_started=%s\n' "$($BB date +%s)" >> $MG/state/stats.conf

  # 启动守护进程（先清理可能残留的旧实例，避免重复运行）
  $BB pkill -f "momguard/bin/guard.sh" 2>/dev/null
  rm -f $MG/run/guard.pid
  $BB sleep 1
  $BB sh $MODDIR/bin/guard.sh >> $MG/log/guard.out 2>&1 &

  # 可选：开机自启 WebUI 服务
  if $BB grep -qE '^webui_autostart=1' $MG/config.conf 2>/dev/null; then
    $BB sh $MODDIR/bin/webui.sh start >> $MG/log/webui.out 2>&1
  fi
) &
