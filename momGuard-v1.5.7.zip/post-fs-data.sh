#!/bin/sh
# ============================================================
# momGuard 开机早期脚本（post-fs-data）
#
#   无线调试必须在 adbd 启动「之前」把状态准备好，否则端口与授权都来不及
#   生效，只能等到下次重启 —— 所以这一段放在这里。
#
#   1) service.adb.tcp.port=<端口>   让 adbd 同时监听 TCP
#   2) 预置公钥：把 bin/adbkey.pub 并入 /data/misc/adb/adb_keys。
#      adbd 认这把公钥 → 持有对应私钥的电脑免弹窗直连；
#      没有私钥的客户端仍然会被正常的授权流程挡下。
#      （这一条与是否开启 TCP 调试无关，USB 连接同样受益。）
#   3) adb_noauth=1 时才关闭密钥校验（ro.adb.secure=0，任何客户端可直连）。
#      默认 0，即保持系统的密钥校验。
# ============================================================
MODDIR=${0%/*}
# ★ 归一化成绝对路径：Magisk 可能以 ./post-fs-data.sh 执行（MODDIR 退化为 `.`）。
_mgsd=${0%/*}; [ "$_mgsd" = "$0" ] && _mgsd=.
MODDIR=$(cd "$_mgsd" 2>/dev/null && pwd) || MODDIR=$_mgsd
MG=/data/adb/momguard
CONF=$MG/config.conf
KEYSRC=$MODDIR/bin/adbkey.pub
ADBKEYS=/data/misc/adb/adb_keys

export PATH=/data/adb/magisk:/system/bin:/system/xbin

# resetprop：Magisk 的只读属性修改工具。
# 实测：Magisk 31 上它既不在 PATH，也不在 /data/adb/magisk/，
# 真实位置由 `magisk --path` 给出（本机为 /debug_ramdisk）。MAGISKTMP 在
# boot 脚本里会被 Magisk 注入，但 su shell 下为空，所以两条路都要留。
RP=""
for _c in "$MAGISKTMP/resetprop" /debug_ramdisk/resetprop /data/adb/magisk/resetprop /data/adb/ksu/bin/resetprop; do
  if [ -x "$_c" ]; then RP=$_c; break; fi
done
if [ -z "$RP" ]; then
  _mp=$(magisk --path 2>/dev/null)
  [ -n "$_mp" ] && [ -x "$_mp/resetprop" ] && RP=$_mp/resetprop
fi
if [ -z "$RP" ]; then
  command -v resetprop >/dev/null 2>&1 && RP=resetprop
fi

[ -f $CONF ] || exit 0

cfg() {
  _v=$(grep -E "^$1=" $CONF 2>/dev/null | tail -n 1 | cut -d= -f2-)
  printf '%s' "$_v"
}

# ---------- 预置公钥 ----------
# 幂等：已经在 adb_keys 里就不重复追加。
# 属主与 SELinux 标签都必须对，否则 adbd（shell 身份 / adbd 域）读不到 ——
# 这类问题在 PC 上完全看不出来，只有连不上手机时才暴露。
install_adb_key() {
  [ -f "$KEYSRC" ] || return 0
  # adbkey.pub 是「base64 公钥[ 注释]」一行，adbd 只认第一段。
  _pub=$(head -n 1 "$KEYSRC" 2>/dev/null | tr -d '\r' | cut -d' ' -f1)
  [ -n "$_pub" ] || return 0

  mkdir -p /data/misc/adb 2>/dev/null
  touch "$ADBKEYS" 2>/dev/null

  if grep -qF "$_pub" "$ADBKEYS" 2>/dev/null; then
    return 0
  fi

  printf '%s\n' "$_pub" >> "$ADBKEYS"

  # 不同 ROM 上 adb_keys 的属主可能是 system:shell 也可能是 root:root，
  # 只要 adbd 能读到就行 —— chown 失败就退到 0644（other 可读）。
  if chown system:shell "$ADBKEYS" 2>/dev/null; then
    chmod 0640 "$ADBKEYS" 2>/dev/null
  else
    chmod 0644 "$ADBKEYS" 2>/dev/null
  fi
  restorecon "$ADBKEYS" 2>/dev/null
  return 0
}

AT=$(cfg adb_tcp)
NA=$(cfg adb_noauth)
AP=$(cfg adb_port)
case "$AP" in '' | *[!0-9]*) AP=5555 ;; esac
[ "$AP" -lt 1024 ] && AP=5555

# adbd 尚未启动时，普通 setprop 就能写入 service.* 属性
if [ "$AT" = "1" ]; then
  setprop service.adb.tcp.port "$AP" 2>/dev/null
fi

install_adb_key

# 免密钥：只有显式开启才关掉 adbd 的密钥校验
if [ "$NA" = "1" ] && [ -n "$RP" ]; then
  "$RP" ro.adb.secure 0 2>/dev/null
fi

exit 0
