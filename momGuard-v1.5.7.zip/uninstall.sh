#!/bin/sh
# ============================================================
# momGuard 卸载
#
# 必须还原的一项：
#   - no_install_apps 用户限制 → 关掉。v1.1.0 起「安装管控」已不再使用它
#     （改用包名基线），但 v1.0.0 设置过、或用户手工设过的话，不还原会让
#     系统永久拒绝安装任何应用，卸载后连 APK 都装不回来。
#
# 刻意不还原的三项（都是内存态，重启自然消失）：
#   - ro.adb.secure / service.adb.tcp.port：本次开机的属性，模块目录被移除后
#     下次开机回到系统默认值。
#   - iptables 的 MG_ADB 链：内存态，重启即清空。
#   - 预置进 /data/misc/adb/adb_keys 的公钥：它只让 adb 免弹窗，留着无害；
#     删掉反而使下次连接重新弹授权框，没有清理的必要。
# ============================================================
MODDIR=${0%/*}
# ★ 归一化成绝对路径：Magisk 可能以 ./uninstall.sh 执行（MODDIR 退化为 `.`），
#   那样下面按 $MODDIR/webroot 的 pkill 会与真实 httpd 命令行对不上 → 杀不干净。
_mgsd=${0%/*}; [ "$_mgsd" = "$0" ] && _mgsd=.
MODDIR=$(cd "$_mgsd" 2>/dev/null && pwd) || MODDIR=$_mgsd

export PATH=/data/adb/magisk:/system/bin:/system/xbin

BB=""
for _c in /data/adb/magisk/busybox /data/adb/ksu/bin/busybox /data/adb/ap/bin/busybox \
          /data/adb/modules/busybox-ndk/system/bin/busybox /system/xbin/busybox /system/bin/busybox; do
  if [ -x "$_c" ]; then BB=$_c; break; fi
done
if [ -z "$BB" ]; then command -v busybox >/dev/null 2>&1 && BB=$(command -v busybox); fi
if [ -z "$BB" ]; then BB=/data/adb/magisk/busybox; fi

# 放行应用安装（最重要的一步）
pm set-user-restriction --user 0 no_install_apps 0 >/dev/null 2>&1

# 停止守护进程与 WebUI 服务
$BB pkill -f "momguard/bin/guard.sh" 2>/dev/null
$BB pkill -f "momguard/bin/webui.sh" 2>/dev/null

# 按 webroot 路径匹配，不按端口：端口被改过的话按端口根本杀不掉。
# 也不能用宽泛的 "httpd -p 127.0.0.1:" —— 那会把别人的 WebUI 一起杀了。
# ⚠️ 匹配串里 -h 前面隔着 `-p <端口>`，所以必须用 `.*` 而不是写死的 " -h "，
#    否则永远匹配不到，httpd 会继续服务却看起来「已清理」。
$BB pkill -f "httpd .*-h $MODDIR/webroot" 2>/dev/null
$BB pkill -f "httpd .*-h \./webroot" 2>/dev/null
$BB pkill -f "[m]omguard/webroot" 2>/dev/null

# 清理运行时文件（保留 config.conf 与日志，便于重装后延续设置）
rm -f /data/adb/momguard/run/guard.pid
rm -f /data/adb/momguard/run/webui.hb
rm -f /data/adb/momguard/run/inst_fail.txt
# 基线必须删掉：留着的话重装后会把「卸载期间新装的应用」当成新装给卸了
rm -f /data/adb/momguard/state/pkg_baseline.txt
