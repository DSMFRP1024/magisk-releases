#!/bin/sh
# ============================================================
# momGuard 模块安装脚本（由 Magisk 安装器 source 执行）
# 可用变量：MODPATH / API / ARCH / IS64BIT / MAGISK_VER_CODE
#
# 本模块由原 AutoKeep 与 AppGuard 合并而来，安装时做两件事：
#   1) 首次安装：把旧模块配置目录里的设置导入新配置（用户不必重配）
#   2) 退役旧模块：disable + remove，并把它们的进程停掉
#      —— 不停掉的话会有多份守护进程同时改同一批系统状态
#         （iptables 规则重复下发、微信被反复拦、日志互相刷）
# ============================================================

ui_print "*******************************"
ui_print " momGuard 自动管家与管控"
ui_print "*******************************"

MG=/data/adb/momguard
OLD1=/data/adb/autokeep
OLD2=/data/adb/appguard

MBB=/data/adb/magisk/busybox
[ -x "$MBB" ] || MBB=busybox

# 与 bin/ctl.sh 的 KEYS 保持一致：只有这些键会被导入
KEYS="vol_ring_on vol_ring vol_music_on vol_music vol_alarm_on vol_alarm vol_notif_on vol_notif vol_voice_on vol_voice vol_mode ring_normal ring_dnd wifi_keep wifi_reconnect adb_tcp adb_port adb_noauth adb_allow nfc_auto nfc_minutes install_block wechat_guard wechat_block_finder wechat_block_misc wechat_mode wechat_cooldown wechat_keepalive usage_track usage_limit usage_keep_days limit_action toast_on webui_autostart webui_port webui_idle_timeout ui_pass debug_trace mp_guard mp_quickapp mp_wx mp_alipay mp_byte mp_baidu mp_default mp_action mp_toast web_guard web_default web_fresh cell_keep cell_sim hub_on hub_url hub_token loc_report loc_interval dev_tag"

# ---------- 基础权限 ----------
set_perm_recursive $MODPATH 0 0 0755 0644

for f in customize.sh post-fs-data.sh service.sh action.sh uninstall.sh \
         bin/guard.sh bin/ctl.sh bin/webui.sh webroot/cgi-bin/api; do
  [ -f "$MODPATH/$f" ] && set_perm "$MODPATH/$f" 0 0 0755
done

# ---------- 持久化目录 ----------
mkdir -p $MG/log $MG/state $MG/run

FRESH=0
if [ ! -f $MG/config.conf ]; then
  FRESH=1
  cp -f $MODPATH/bin/config.default $MG/config.conf
  set_perm $MG/config.conf 0 0 0600
fi
chmod 0700 $MG $MG/log $MG/state $MG/run 2>/dev/null

# ---------- 从旧模块导入设置 ----------
# 逐键搬运：只认新模块认识的键，值原样搬过来。
# 用 `|` 作 sed 分隔符（adb_allow 的值里有点和斜杠，用 / 会破坏替换表达式）。
import_cfg() {
  _old="$1"
  _tag="$2"
  [ -f "$_old" ] || return 0
  _n=0
  while IFS='=' read -r _k _v; do
    case "$_k" in '' | '#'*) continue ;; esac
    case " $KEYS " in *" $_k "*) ;; *) continue ;; esac
    [ -n "$_v" ] || continue
    if $MBB grep -qE "^$_k=" "$MG/config.conf" 2>/dev/null; then
      $MBB sed -i "s|^$_k=.*|$_k=$_v|" "$MG/config.conf" 2>/dev/null
    else
      printf '%s=%s\n' "$_k" "$_v" >> "$MG/config.conf"
    fi
    _n=$((_n + 1))
  done < "$_old"
  if [ "$_n" -gt 0 ]; then
    ui_print "- 已从 $_tag 迁移 $_n 项设置"
  fi
  return 0
}

if [ "$FRESH" = "1" ]; then
  ui_print "- 首次安装：正在导入旧模块设置…"
  import_cfg "$OLD1/config.conf" "AutoKeep"
  import_cfg "$OLD2/config.conf" "AppGuard"
  $MBB sed -i '/^$/d' "$MG/config.conf" 2>/dev/null
fi

# ---------- 数据迁移：小程序登记表（v1.3.7） ----------
# v1.3.6 把 AppBrandPluginUI 这个**整类容器**叫成了「微信小店/卡包」，而它同时也承载
# 「城市服务」等页面（真机实测同一组件），名字会误导用户、还会因含「小店」被自动归入
# 购物类。这里把登记表里已有的那一行**就地改名**（保留打开次数），分类改成 other。
# 幂等：改完就不再命中；表不存在 / 已经是新名时零动作。
ML=$MG/state/miniapp.list
if [ -f "$ML" ] && $MBB grep -q '微信小店/卡包' "$ML" 2>/dev/null; then
  $MBB awk -F'\t' 'BEGIN{OFS="\t"}
    { if ($5 == "微信小店/卡包") { $3 = "other"; $5 = "微信内置页" } print }' \
    "$ML" > "$ML.tmp" 2>/dev/null && $MBB mv -f "$ML.tmp" "$ML"
  set_perm "$ML" 0 0 0600
  ui_print "- 登记表迁移：微信小店/卡包 → 微信内置页（同一个整类容器）"
fi

# ---------- 退役旧模块 ----------
retire() {
  _id="$1"
  _d=/data/adb/modules/$_id
  [ -d "$_d" ] || return 0
  [ "$_id" = "momguard" ] && return 0

  # 立即停进程：disable 只影响下次开机，管不住当前正在跑的实例
  $MBB pkill -f "$_id/bin/guard.sh" 2>/dev/null
  $MBB pkill -f "$_id/bin/webui.sh" 2>/dev/null
  # ⚠️ 必须用 `.*`：真实命令行是 `busybox httpd -p 127.0.0.1:端口 -h <dir>`，
  #    `-h` 前面隔着 `-p <端口>`，写死的 "httpd -h ..." 永远匹配不到。
  $MBB pkill -f "httpd .*-h $_d/webroot" 2>/dev/null

  # disable：立刻在 Magisk 里标记停用
  # remove ：下次开机时由 Magisk 执行其 uninstall.sh 并删除模块目录
  $MBB touch "$_d/disable" 2>/dev/null
  $MBB touch "$_d/remove" 2>/dev/null
  ui_print "- 已退役旧模块 $_id（立即停用，重启后由 Magisk 移除）"
  return 0
}

retire autokeep
retire appguard

ui_print "- 检测到 Android API: $API"
ui_print "- 配置目录: $MG"
ui_print "- 默认启用：铃声常满 / WiFi 常开 / 无线调试 5555 / NFC 5 分钟自动关"
ui_print "- 默认启用：只允许已装应用升级（新装自动卸载） / 拦截微信视频号与小程序"
ui_print "- 打开界面：Magisk 模块卡片右下角『操作』按钮，界面内分三个页签"
ui_print "- 无线调试需要重启手机后完全生效"
ui_print "- adb 保持密钥校验；已预置本机公钥（免弹窗），并限制只有指定网段可连"
