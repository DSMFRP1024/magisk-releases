#!/system/bin/sh
# service.sh —— Magisk late_start 阶段：开机自启 WebUI
# 关闭自启：touch /data/adb/modules/trace_cleaner/web/disabled 后重启
# 端口在 6789 被占时会顺延尝试 6789-6808

MODDIR=${MODDIR:-/data/adb/modules/trace_cleaner}
DATADIR=/data/adb/tracecleaner
BB=/data/adb/magisk/busybox
[ -x "$BB" ] || BB=/data/adb/ksu/bin/busybox
[ -x "$BB" ] || BB=/data/adb/ap/bin/busybox
[ -x "$BB" ] || exit 0

[ -f "$MODDIR/web/disabled" ] && exit 0
[ -x "$MODDIR/bin/tc" ] || exit 0
mkdir -p "$DATADIR/log" 2>/dev/null

i=0
while [ $i -lt 10 ]; do
  sh "$MODDIR/bin/tc" web start $((6789 + i)) >> "$DATADIR/log/web.log" 2>&1 && exit 0
  i=$((i + 1))
done
exit 0
