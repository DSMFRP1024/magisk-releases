#!/system/bin/sh
# _common.sh —— CGI 公共函数（被 cgi-bin/* source；本身不是 CGI，勿加执行位）
#
# busybox httpd 约定：
#   URL /cgi-bin/<name> → 执行 webroot/cgi-bin/<name>（须可执行、有 shebang）
#   请求头转成 HTTP_<NAME> 环境变量（X-TC-Token → HTTP_X_TC_TOKEN）
#   POST body 走 stdin，字节数在 CONTENT_LENGTH
#   CGI  stdout = HTTP 响应（先头部、空行、再 body）；stderr 进 httpd 错误日志

MODDIR=${TC_MODDIR:-/data/adb/modules/trace_cleaner}
DATADIR=${TC_DATADIR:-/data/adb/tracecleaner}
OUTDIR=${TC_OUTDIR:-/sdcard/TraceCleaner}
WEBDIR=$DATADIR/web
TOKEN_FILE=$WEBDIR/token
export MODDIR DATADIR OUTDIR WEBDIR

PATH=/data/adb/magisk/bin:/data/adb/ksu/bin:/data/adb/ap/bin:/system/bin:/system/xbin:/vendor/bin:$PATH
export PATH LC_ALL=C
BB=/data/adb/magisk/busybox
[ -x "$BB" ] || BB=/data/adb/ksu/bin/busybox
[ -x "$BB" ] || BB=/data/adb/ap/bin/busybox
[ -x "$BB" ] || BB=busybox
export BB

# ---------------- HTTP 响应 ----------------
hdr() { printf 'Status: %s\r\nContent-Type: %s\r\nCache-Control: no-store\r\n\r\n' "$1" "$2"; }
json_ok() { hdr "200 OK" "application/json"; printf '%s' "$1"; }
json_err() { hdr "${2:-400 Bad Request}" "application/json"; printf '{"ok":false,"error":"%s"}' "$1"; }
text_ok() { hdr "200 OK" "text/plain; charset=utf-8"; cat; }

# ---------------- 令牌 ----------------
# 位置：$DATADIR/web/token（0600）。启动时随机生成，可用 tc web token 重roll。
TOKEN=$("$BB" tr -d '\n\r ' < "$TOKEN_FILE" 2>/dev/null)

get_token() {
  _t=$HTTP_X_TC_TOKEN
  [ -n "$_t" ] || _t=$(printf '%s' "$QUERY_STRING" | "$BB" sed -n 's/.*[?&]token=\([A-Za-z0-9]\{1,64\}\).*/\1/p')
  printf '%s' "$_t"
}

require_auth() {
  if [ -z "$TOKEN" ]; then json_err "服务未初始化令牌" "500 Internal Server Error"; return 1; fi
  _g=$(get_token)
  if [ -z "$_g" ] || [ "$_g" != "$TOKEN" ]; then
    json_err "令牌无效或缺失（请求头 X-TC-Token）" "401 Unauthorized"; return 1
  fi
  return 0
}

# ---------------- POST body ----------------
# body 只能读一次：先统一收进 $BODY，后续解析都用 $BODY
BODY=
BODY_READ=0
read_body() {
  if [ "$BODY_READ" = 0 ] && [ "${CONTENT_LENGTH:-0}" -gt 0 ] 2>/dev/null; then
    BODY=$("$BB" head -c "$CONTENT_LENGTH")
    BODY_READ=1
  fi
  printf '%s' "$BODY"
}

# 从 body 取 "key":"value" 或 "key":123 / true
body_str() { printf '%s' "$BODY" | "$BB" sed -n "s/.*\"$1\":\"\([^\"]\{0,64\}\)\".*/\1/p"; }
body_int() { printf '%s' "$BODY" | "$BB" sed -n "s/.*\"$1\":\([0-9]\{1,4\}\).*/\1/p"; }
body_bool() {
  _v=$(printf '%s' "$BODY" | "$BB" sed -n "s/.*\"$1\":\(true\|false\).*/\1/p")
  [ "$_v" = true ] && printf '1' || printf '0'
}

# ---------------- JSON 转义 ----------------
# 单行
jesc() { printf '%s' "$1" | "$BB" tr -d '\n\r' | "$BB" sed -e 's/[\\"]/\\&/g'; }
# 整个文件（保留换行 → \n）
jesc_file() {
  "$BB" awk '{gsub(/\\/,"\\\\"); gsub(/"/,"\\\""); gsub(/\t/,"\\t"); printf "%s\\n",$0}' "$1" \
    | "$BB" sed '$s/\\n$//'
}

# ---------------- 任务互斥 ----------------
# job_running 来自 lib/util.sh（与 tc 命令行共用同一套判定）
. "$MODDIR/lib/util.sh" 2>/dev/null
