#!/system/bin/sh
# action.sh —— 模块页的「操作」按钮（Magisk / KernelSU / APatch / MMRL 通用）
#
# 作用：一键把 WebUI 拉起来，并直接用手机浏览器打开（带上令牌，无需手输）。
# 这是「模块详情页里没有按钮」的正解：管理器只在模块根目录存在 action.sh 时显示按钮。

MODDIR=${0%/*}
case "$MODDIR" in /*) ;; *) MODDIR=$PWD/$MODDIR ;; esac

BB=/data/adb/magisk/busybox
[ -x "$BB" ] || BB=/data/adb/ksu/bin/busybox
[ -x "$BB" ] || BB=/data/adb/ap/bin/busybox
[ -x "$BB" ] || BB=busybox

DATADIR=/data/adb/tracecleaner
TOKEN_FILE=$DATADIR/web/token
PORT_FILE=$DATADIR/web/port

echo "======== TraceCleaner ========"

# 1) 起服务（已在跑就跳过；端口按 6789-6808 顺延）
i=0
while [ $i -lt 10 ]; do
  if sh "$MODDIR/bin/tc" web start $((6789 + i)) >/dev/null 2>&1; then break; fi
  i=$((i + 1))
done

port=$("$BB" tr -d '\r\n ' < "$PORT_FILE" 2>/dev/null)
case "$port" in ''|*[!0-9]*) port=6789 ;; esac
token=$("$BB" tr -d '\r\n ' < "$TOKEN_FILE" 2>/dev/null)

url="http://127.0.0.1:$port/?token=$token"

echo ""
echo "WebUI  : $url"
echo "令牌   : $token"
echo ""

# 2) 直接拉起手机浏览器（带 token 参数，页面自动登录）
am start --user 0 -a android.intent.action.VIEW -d "$url" >/dev/null 2>&1 \
  && echo "已在浏览器打开。" \
  || echo "没打开浏览器的话，请手动复制上面的地址。"

echo ""
echo "常用命令（终端里执行）："
echo "  sh $MODDIR/bin/tc scan            # 只读扫描"
echo "  sh $MODDIR/bin/tc clean --level 2 # 预演，不删任何东西"
echo "  sh $MODDIR/bin/tc update          # 检查更新"
echo ""
echo "关闭开机自启：touch $MODDIR/web/disabled 后重启"
echo "本按钮只起服务并开页面，不会自动清理任何东西。"
