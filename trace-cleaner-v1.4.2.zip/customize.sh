#!/system/bin/sh
# customize.sh —— 安装时执行（只在 Magisk 安装阶段跑，不做任何清理动作）

SKIPUNZIP=1

ui_print "- TraceCleaner 安装中"

unzip -o "$ZIPFILE" 'module.prop' -d "$MODPATH" >/dev/null 2>&1
unzip -o "$ZIPFILE" 'bin/*' 'lib/*' 'conf/*' 'web/*' 'webroot/*' 'README.md' \
  'uninstall.sh' 'service.sh' 'action.sh' -d "$MODPATH" >/dev/null 2>&1

set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm_recursive "$MODPATH/bin" 0 0 0755 0755
set_perm "$MODPATH/bin/tc" 0 0 0755
set_perm "$MODPATH/service.sh" 0 0 0755
# action.sh = 模块页「操作」按钮，必须可执行
set_perm "$MODPATH/action.sh" 0 0 0755
# CGI 必须可执行（busybox httpd 只执行有执行位的文件），页面本体 0644
set_perm_recursive "$MODPATH/web/cgi-bin" 0 0 0755 0755
set_perm "$MODPATH/web/index.html" 0 0 0644
set_perm "$MODPATH/webroot/index.html" 0 0 0644

# 浏览器版同一份页面：httpd 的根是 web/，复制一份进去才能用 http://<ip>:6789/ksu.html
cp -f "$MODPATH/webroot/index.html" "$MODPATH/web/ksu.html" 2>/dev/null
chmod 0644 "$MODPATH/web/ksu.html" 2>/dev/null

mkdir -p /data/adb/tracecleaner/log /data/adb/tracecleaner/backup /sdcard/TraceCleaner
chmod 700 /data/adb/tracecleaner /data/adb/tracecleaner/log /data/adb/tracecleaner/backup

# 首次安装才铺默认配置，升级不覆盖用户改过的白名单
if [ ! -f "$MODPATH/conf/whitelist.conf" ]; then
  cat > "$MODPATH/conf/whitelist.conf" <<'EOF'
# 白名单：这些包的数据目录/缓存永不被清理（一行一个包名，# 注释）
com.tencent.mm
com.tencent.mobileqq
com.android.systemui
com.miui.home
EOF
fi

ui_print "- 安装完成（模块不做任何开机自动清理）"
ui_print "- 入口①  模块详情页的「操作」按钮：起 WebUI + 手机浏览器直接打开"
ui_print "- 入口②  KernelSU / APatch / MMRL 的 WebUI：点模块的「打开」"
ui_print "- 入口③  命令行：su -c 'sh $MODPATH/bin/tc scan'"
ui_print "- 清理默认是预演，必须加 --confirm"
