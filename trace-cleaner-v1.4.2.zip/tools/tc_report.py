#!/usr/bin/env python3
"""tc_report.py —— 把 TraceCleaner 的 scan-*.json 渲染成可搜索/排序的 HTML 报告。

用法：
    python tc_report.py scan-20261022-193209.json
    python tc_report.py scan.json -o report.html --names names.json

names.json（可选）：{"com.tencent.mm": "微信", ...} 用于把包名换成中文名。
"""
import argparse
import json
import os
import sys

TEMPLATE = r"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>TraceCleaner 扫描报告 __TIME__</title>
<style>
  :root{
    --bg:#0e131f; --panel:#161d2c; --panel2:#1b2436; --line:#26314a;
    --tx:#e6ecf7; --tx2:#9aa8bf; --accent:#4f9cf9;
    --ok:#3fb950; --warn:#e0a020; --danger:#e05a5a; --l4:#a371f7;
  }
  *{box-sizing:border-box}
  body{margin:0;background:var(--bg);color:var(--tx);
       font:14px/1.55 -apple-system,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif}
  .wrap{max-width:1240px;margin:0 auto;padding:28px 20px 60px}
  h1{font-size:22px;margin:0 0 4px;font-weight:650;letter-spacing:.3px}
  .sub{color:var(--tx2);font-size:13px;margin-bottom:22px}
  .sub b{color:var(--tx)}
  .kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:24px}
  .kpi{background:var(--panel);border:1px solid var(--line);border-radius:10px;padding:14px 16px}
  .kpi .n{font-size:26px;font-weight:680;line-height:1.1}
  .kpi .l{color:var(--tx2);font-size:12px;margin-top:4px}
  .kpi.warn .n{color:var(--warn)} .kpi.danger .n{color:var(--danger)} .kpi.ok .n{color:var(--ok)}
  .bar{display:flex;gap:18px;flex-wrap:wrap;align-items:center;margin-bottom:14px}
  .tabs{display:flex;gap:6px;flex-wrap:wrap}
  .tab{background:var(--panel);border:1px solid var(--line);color:var(--tx2);
       padding:7px 13px;border-radius:8px;cursor:pointer;font-size:13px;user-select:none}
  .tab:hover{color:var(--tx);border-color:#33425f}
  .tab.on{background:rgba(79,156,249,.16);border-color:rgba(79,156,249,.5);color:#bcd8ff}
  input[type=search]{flex:1;min-width:200px;background:var(--panel);border:1px solid var(--line);
       color:var(--tx);border-radius:8px;padding:8px 12px;font-size:13px;outline:none}
  input[type=search]:focus{border-color:rgba(79,156,249,.55)}
  .panel{background:var(--panel);border:1px solid var(--line);border-radius:12px;overflow:hidden}
  .cnt{padding:9px 14px;border-bottom:1px solid var(--line);color:var(--tx2);font-size:12px;
       background:var(--panel2)}
  table{width:100%;border-collapse:collapse}
  th,td{text-align:left;padding:8px 12px;border-bottom:1px solid rgba(38,49,74,.6);
        vertical-align:top;font-size:13px}
  th{position:sticky;top:0;background:var(--panel2);color:var(--tx2);font-weight:600;
     font-size:12px;cursor:pointer;white-space:nowrap;z-index:2}
  th:hover{color:var(--tx)}
  th .ar{opacity:.45;font-size:10px;margin-left:3px}
  tbody tr:hover{background:rgba(79,156,249,.06)}
  td.mono{font-family:ui-monospace,Consolas,"Courier New",monospace;font-size:12.5px}
  .dim{color:var(--tx2)}
  .okc{color:var(--ok)}
  .tag{display:inline-block;padding:1px 7px;border-radius:6px;font-size:11px;line-height:1.7}
  .t-sys{background:rgba(154,168,191,.14);color:#9aa8bf}
  .t-3rd{background:rgba(79,156,249,.16);color:#8fc0ff}
  .t-pre{background:rgba(224,160,32,.15);color:#e0a020}
  .r-L1{color:var(--ok)} .r-L2{color:var(--warn)} .r-L3{color:var(--danger)}
  .r-L4{color:var(--l4)} .r-NO{color:var(--tx2)}
  .empty{padding:26px;text-align:center;color:var(--tx2)}
  .foot{margin-top:26px;color:var(--tx2);font-size:12px;line-height:1.9}
  .foot code{background:var(--panel);padding:1px 6px;border-radius:5px;color:#bcd8ff}
</style>
</head>
<body>
<div class="wrap">
  <h1>TraceCleaner 痕迹扫描报告</h1>
  <div class="sub">
    设备 <b>__MODEL__</b>（__DEVICE__）　Android <b>__ANDROID__</b> SDK __SDK__　构建 <b>__BUILD__</b>
    　·　生成于 <b>__TIME__</b>　·　模块 __MODULE__
  </div>

  <div class="kpis">
    <div class="kpi"><div class="n">__K_INST__</div><div class="l">已安装（第三方 __K_3RD__）</div></div>
    <div class="kpi __K_GONE_CLS__"><div class="n">__K_GONE__</div><div class="l">已卸载但留有记录</div></div>
    <div class="kpi __K_RES_CLS__"><div class="n">__K_RES__</div><div class="l">残留路径（__K_RESMB__ MB）</div></div>
    <div class="kpi __K_ORP_CLS__"><div class="n">__K_ORP__</div><div class="l">孤儿目录</div></div>
    <div class="kpi"><div class="n">__K_SRC__</div><div class="l">历史记录来源命中</div></div>
    <div class="kpi __K_APP_CLS__"><div class="n">__K_APP__</div><div class="l">应用清单缓存</div></div>
    <div class="kpi __K_AD_CLS__"><div class="n">__K_AD__</div><div class="l">应用数据快照（__K_ADPKG__ 个应用）</div></div>
  </div>

  <div class="bar">
    <div class="tabs" id="tabs"></div>
    <input type="search" id="q" placeholder="搜索包名 / 路径 / 说明…">
  </div>

  <div class="panel">
    <div class="cnt" id="cnt"></div>
    <div style="overflow:auto;max-height:70vh">
      <table>
        <thead><tr id="th"></tr></thead>
        <tbody id="tb"></tbody>
      </table>
    </div>
  </div>

  <div class="foot">
    <div>· 数据来源：设备端 <code>tc scan</code>（只读），未经任何删除操作。</div>
    <div>· 「预装」标记 = 首次安装时间落在 2015 年之前（PM 写入的 build 基准时间，非真实安装时间）。</div>
    <div>· 「已卸载」仅覆盖 <code>pm list packages -u</code> 仍记得的包；真正的卸载时间戳系统不保存。</div>
    <div>· 清理：<code>tc clean --level 1|2|3</code> 先预演，确认后加 <code>--confirm</code>。</div>
  </div>
</div>

<script>
const DATA = __DATA__;

const VIEWS = {
  installed: {
    label: '已安装 (' + DATA.stats.installed + ')',
    cols: (DATA._names ? [['name','应用名']] : []).concat([
      ['pkg','包名'],['kind','类型'],['first','首次安装'],['last','最后更新'],
      ['ver','版本'],['installer','安装器']]),
    rows: DATA.installed.map(r => ({
      name: r.name || '', pkg: r.pkg, kind: r.kind, first: r.pre ? '预装' : r.first,
      last: r.last, ver: r.ver, installer: r.installer || '',
      _kind: r.kind, _pre: r.pre
    }))
  },
  gone: {
    label: '已卸载 (' + DATA.stats.gone + ')',
    cols: [['pkg','包名'],['_res','残留']],
    rows: DATA.gone.map(p => {
      const hit = DATA.residual.filter(r => r.pkg === p);
      return { pkg: p, _res: hit.length ? hit.map(h => h.path + ' (' + h.kb + ' KB)').join('<br>') : '无残留目录' };
    })
  },
  orphan: {
    label: '孤儿目录 (' + DATA.stats.orphan + ')',
    cols: [['path','路径']],
    rows: DATA.orphan.map(p => ({ path: p }))
  },
  sources: {
    label: '历史来源 (' + DATA.sources.length + ')',
    cols: [['risk','风险'],['path','路径'],['info','大小'],['mtime','最近修改'],['label','内容']],
    rows: DATA.sources.map(s => ({ risk: s.risk, path: s.path, info: s.info, mtime: s.mtime, label: s.label }))
  },
  applist: {
    label: '清单缓存 (' + DATA.applist.length + ')',
    cols: [['pkg','所属应用'],['kb','KB'],['path','文件']],
    rows: DATA.applist.map(a => ({ pkg: a.pkg, kb: a.kb, path: a.path }))
  },
  appdata: {
    label: '应用数据快照 (' + ((DATA.appdata || []).filter(a => a.level === 'strong').length) + ')',
    cols: [['pkg','所属应用'],['hits','命中包名'],['size','大小'],
           ['cls','分类'],['can','能否清理'],['path','文件']],
    rows: (DATA.appdata || []).filter(a => a.level === 'strong').map(a => ({
      pkg: a.owner,
      hits: a.hits,
      size: (a.bytes / 1024).toFixed(0) + ' KB',
      cls: a.cls,
      can: a.cls === 'cache' ? '可清（会重建）'
         : a.cls === 'prefs' ? '需 --appdata=prefs'
         : a.cls === 'tool'  ? '需 --appdata=prefs'
         : '需 --appdata=db',
      path: a.path,
      _cls: a.cls, _hits: a.hits
    }))
  }
};

let cur = 'installed', q = '', sortKey = null, sortAsc = false;

function esc(s) {
  return String(s == null ? '' : s).replace(/[&<>"']/g,
    c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function cell(row, key) {
  const v = row[key];
  if (key === 'kind') {
    const cls = v === '3rd' ? 't-3rd' : 't-sys';
    const txt = v === '3rd' ? '第三方' : '系统';
    return '<span class="tag ' + cls + '">' + txt + '</span>';
  }
  if (key === 'first' && row._pre) return '<span class="tag t-pre">预装</span>';
  if (key === 'cls') {
    const m = { cache: 't-3rd', prefs: 't-pre', tool: 't-pre', appdb: 't-sys' };
    return '<span class="tag ' + (m[v] || 't-sys') + '">' + esc(v) + '</span>';
  }
  if (key === 'can') return '<span class="' + (String(v).indexOf('可清') === 0 ? 'okc' : 'dim') + '">' + esc(v) + '</span>';
  if (key === 'hits') return '<b>' + esc(v) + '</b>';
  if (key === 'risk') return '<span class="r-' + esc(v) + '">' + esc(v) + '</span>';
  if (key === '_res') return '<span class="dim">' + (v || '') + '</span>';
  if (key === 'pkg' || key === 'path' || key === 'installer') return '<span class="mono">' + esc(v) + '</span>';
  return esc(v);
}

function render() {
  const view = VIEWS[cur];
  let rows = view.rows.filter(r => {
    if (!q) return true;
    const s = Object.keys(r).map(k => r[k]).join(' ').toLowerCase();
    return s.indexOf(q.toLowerCase()) >= 0;
  });
  if (sortKey) {
    rows = rows.slice().sort((a, b) => {
      const x = String(a[sortKey] == null ? '' : a[sortKey]);
      const y = String(b[sortKey] == null ? '' : b[sortKey]);
      return sortAsc ? (x > y ? 1 : x < y ? -1 : 0) : (x < y ? 1 : x > y ? -1 : 0);
    });
  }
  document.getElementById('th').innerHTML = view.cols.map(([k, t]) =>
    '<th data-k="' + k + '">' + t + (sortKey === k ? '<span class="ar">' + (sortAsc ? '▲' : '▼') + '</span>' : '') + '</th>'
  ).join('');
  document.getElementById('tb').innerHTML = rows.length
    ? rows.map(r => '<tr>' + view.cols.map(([k]) => '<td>' + cell(r, k) + '</td>').join('') + '</tr>').join('')
    : '<tr><td colspan="' + view.cols.length + '" class="empty">没有匹配的记录</td></tr>';
  document.getElementById('cnt').textContent =
    view.label + '　显示 ' + rows.length + ' / ' + view.rows.length + ' 条';
  document.querySelectorAll('#th th').forEach(th => {
    th.onclick = () => {
      const k = th.dataset.k;
      if (sortKey === k) sortAsc = !sortAsc; else { sortKey = k; sortAsc = false; }
      render();
    };
  });
}

function init() {
  document.getElementById('tabs').innerHTML = Object.keys(VIEWS).map(k =>
    '<div class="tab' + (k === cur ? ' on' : '') + '" data-k="' + k + '">' + VIEWS[k].label + '</div>'
  ).join('');
  document.querySelectorAll('.tab').forEach(t => {
    t.onclick = () => {
      cur = t.dataset.k; sortKey = null;
      document.querySelectorAll('.tab').forEach(x => x.classList.toggle('on', x === t));
      render();
    };
  });
  document.getElementById('q').oninput = e => { q = e.target.value.trim(); render(); };
  render();
}
init();
</script>
</body>
</html>
"""


def human_kb(kb):
    try:
        kb = int(kb)
    except Exception:
        kb = 0
    if kb >= 1048576:
        return "%.1f GB" % (kb / 1048576.0)
    if kb >= 1024:
        return "%d MB" % (kb // 1024)
    return "%d KB" % kb


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("json_path")
    ap.add_argument("-o", "--out", default=None)
    ap.add_argument("--names", default=None, help="可选：包名→中文名 的 JSON")
    a = ap.parse_args()

    data = json.load(open(a.json_path, encoding="utf-8"))
    if a.names and os.path.exists(a.names):
        names = json.load(open(a.names, encoding="utf-8"))
        for r in data.get("installed", []):
            r["name"] = names.get(r["pkg"], "")
        data["_names"] = True

    meta = data.get("meta", {})
    stats = data.get("stats", {})
    residual_mb = int(sum(int(r.get("kb", 0)) for r in data.get("residual", [])) / 1024)
    _ad = [x for x in data.get("appdata", []) if x.get("level") == "strong"]
    ad_strong = len(_ad)
    ad_pkgs = len(set(x.get("owner", "") for x in _ad))

    def cls(n, danger=1):
        return "danger" if n >= danger else "ok"

    html = (TEMPLATE
            .replace("__TIME__", meta.get("time", ""))
            .replace("__MODEL__", meta.get("model", ""))
            .replace("__DEVICE__", meta.get("device", ""))
            .replace("__ANDROID__", meta.get("android", ""))
            .replace("__SDK__", meta.get("sdk", ""))
            .replace("__BUILD__", meta.get("build", ""))
            .replace("__MODULE__", meta.get("module", ""))
            .replace("__K_INST__", str(stats.get("installed", 0)))
            .replace("__K_3RD__", str(stats.get("third", 0)))
            .replace("__K_GONE__", str(stats.get("gone", 0)))
            .replace("__K_GONE_CLS__", cls(stats.get("gone", 0)))
            .replace("__K_RES__", str(stats.get("residual", 0)))
            .replace("__K_RESMB__", str(residual_mb))
            .replace("__K_RES_CLS__", cls(stats.get("residual", 0)))
            .replace("__K_ORP__", str(stats.get("orphan", 0)))
            .replace("__K_ORP_CLS__", cls(stats.get("orphan", 0)))
            .replace("__K_SRC__", str(len(data.get("sources", []))))
            .replace("__K_APP__", str(len(data.get("applist", []))))
            .replace("__K_APP_CLS__", cls(len(data.get("applist", [])), 1))
            .replace("__K_AD__", str(ad_strong))
            .replace("__K_ADPKG__", str(ad_pkgs))
            .replace("__K_AD_CLS__", cls(ad_strong, 1))
            .replace("__DATA__", json.dumps(data, ensure_ascii=False)))

    out = a.out or os.path.splitext(a.json_path)[0] + ".html"
    open(out, "w", encoding="utf-8", newline="\n").write(html)

    print("报告已生成：%s" % out)
    print("  已安装 %s（第三方 %s）｜已卸载 %s｜残留 %s｜孤儿 %s｜来源 %s｜清单缓存 %s｜应用数据快照 %s(%s 应用)" % (
        stats.get("installed", 0), stats.get("third", 0), stats.get("gone", 0),
        stats.get("residual", 0), stats.get("orphan", 0),
        len(data.get("sources", [])), len(data.get("applist", [])), ad_strong, ad_pkgs))


if __name__ == "__main__":
    main()
