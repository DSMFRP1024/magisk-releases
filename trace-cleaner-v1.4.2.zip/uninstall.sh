#!/system/bin/sh
# uninstall.sh —— 卸载时保留备份（不删 /data/adb/tracecleaner，方便回滚取证）
# 本模块没有修改任何系统属性/规则，无需还原任何状态。

# 停掉 WebUI
if [ -f /data/adb/tracecleaner/web/httpd.pid ]; then
  BB=/data/adb/magisk/busybox
  [ -x "$BB" ] || BB=/data/adb/ksu/bin/busybox
  [ -x "$BB" ] || BB=/data/adb/ap/bin/busybox
  [ -x "$BB" ] || BB=busybox
  "$BB" start-stop-daemon -K -p /data/adb/tracecleaner/web/httpd.pid 2>/dev/null
fi

rm -rf "$MODPATH/bin" "$MODPATH/lib" "$MODPATH/conf" "$MODPATH/web" \
       "$MODPATH/module.prop" "$MODPATH/service.sh" 2>/dev/null
