# scan.sh —— 只读扫描：枚举"装过什么"的全部可取证来源
# 输出：$OUT（人读文本）、$OUTDIR/scan-<ts>.json（机器读）、$TMP 下的中间 TSV

scan_all() {
  TMP=${TMP:-$DATADIR/tmp}
  mkdir -p "$TMP" "$OUTDIR" || die "无法创建目录 $DATADIR / $OUTDIR"
  STAMP=$(ts_name)
  OUT="$OUTDIR/scan-$STAMP.txt"
  : > "$OUT"

  sec_head
  sec_installed
  sec_gone
  sec_orphan
  sec_sources
  sec_applist
  sec_appdata
  sec_summary

  build_json
  # 不留全量 dumpsys 缓存（4 MB 的"应用清单"本身就是要避免的痕迹）
  "$BB" rm -f "$TMP/dumpsys.txt"
  o ""
  o "报告已写入：$OUT"
  o "结构化数据：$OUTDIR/scan-$STAMP.json"
  o "提示：清理前请先用 clean 的 dry-run 预览（不加 --confirm 即为预览）。"
}

# ---------------------------------------------------------------- 1
sec_head() {
  o "=================================================================="
  o " TraceCleaner 痕迹扫描报告"
  o "=================================================================="
  o " 生成时间 : $(ts_now)"
  o " 设备     : $(getprop ro.product.model) / $(getprop ro.product.device)"
  o " 系统     : Android $(getprop ro.build.version.release)  SDK $(getprop ro.build.version.sdk)  $(getprop ro.miui.ui.version.name)"
  o " 构建版本 : $(getprop ro.build.version.incremental)"
  o " 内核     : $(uname -r)"
  o " Magisk   : $(magisk -v 2>/dev/null)"
  o " 模块版本 : $(grep '^version=' "$MODDIR/module.prop" 2>/dev/null | cut -d= -f2)"
  o ""
}

# ---------------------------------------------------------------- 2
sec_installed() {
  o "------------------------------------------------------------------"
  o " [1] 当前已安装应用（系统包管理器权威记录）"
  o "------------------------------------------------------------------"

  pm list packages 2>/dev/null | "$BB" sed 's/^package://' | "$BB" sort > "$TMP/inst.txt"
  pm list packages -3 2>/dev/null | "$BB" sed 's/^package://' | "$BB" sort > "$TMP/third.txt"
  pm list packages -u 2>/dev/null | "$BB" sed 's/^package://' | "$BB" sort > "$TMP/instu.txt"

  if [ ! -s "$TMP/dumpsys.txt" ] || [ "$SCAN_REFRESH" = 1 ]; then
    dumpsys package > "$TMP/dumpsys.txt" 2>/dev/null
  fi

  # 解析：包名 / 首次安装 / 最后更新 / 版本 / 安装位置 / 安装器
  # ★ 坑：MIUI/AOSP 的 firstInstallTime / lastUpdateTime 缩进是 6 个空格（挂在 "User 0:" 下面），
  #   不是 4 个 —— 按 4 空格匹配会全部落空，而且字段变成空串后 read/sort 会把后面的列"顶上来"，
  #   看上去就像"时间取到了"，实际取到的是 lastUpdateTime。
  "$BB" awk '
    function flush() {
      if (pkg != "" && !(pkg in done)) {
        done[pkg] = 1
        printf "%s\t%s\t%s\t%s\t%s\t%s\n", pkg, fit, lut, ver, loc, ins
      }
    }
    /^  Package \[/ {
      flush()
      pkg = $0
      sub(/^  Package \[/, "", pkg)
      sub(/\].*/, "", pkg)
      fit = ""; lut = ""; ver = ""; loc = ""; ins = ""
      next
    }
    /^[ \t]+firstInstallTime=/ {
      if (fit == "") { v = $0; sub(/^[ \t]*firstInstallTime=/, "", v); fit = v }
      next
    }
    /^[ \t]+lastUpdateTime=/ {
      if (lut == "") { v = $0; sub(/^[ \t]*lastUpdateTime=/, "", v); lut = v }
      next
    }
    /^[ \t]+installerPackageName=/ {
      if (ins == "") { v = $0; sub(/^[ \t]*installerPackageName=/, "", v); ins = v }
      next
    }
    /^    versionName=/ { v = $0; sub(/^    versionName=/, "", v); ver = v; next }
    /^    codePath=/    { v = $0; sub(/^    codePath=/, "", v);    loc = v; next }
    END { flush() }
  ' "$TMP/dumpsys.txt" > "$TMP/pkginfo.tsv"

  # 标注系统/第三方
  "$BB" awk -F'\t' '
    NR == FNR { t[$1] = 1; next }
    {
      kind = ($1 in t) ? "3rd" : "sys"
      printf "%s\t%s\t%s\t%s\t%s\t%s\t%s\n", $1, kind, $2, $3, $4, $5, $6
    }
  ' "$TMP/third.txt" "$TMP/pkginfo.tsv" > "$TMP/inst_full.tsv"

  CNT_ALL=$(wc -l < "$TMP/inst.txt" | tr -d ' ')
  CNT_3RD=$(wc -l < "$TMP/third.txt" | tr -d ' ')
  CNT_SYS=$((CNT_ALL - CNT_3RD))

  o " 合计 $CNT_ALL 个（第三方 $CNT_3RD / 系统 $CNT_SYS）"
  o " 明细见 ${OUTDIR}/scan-${STAMP}-installed.tsv"
  cp "$TMP/inst_full.tsv" "$OUTDIR/scan-$STAMP-installed.tsv" 2>/dev/null
  o ""

  # 最近安装的 10 个（第三方）：抽成「无空格数字键 + 全字段」，避免含空格的时间列参与排序
  o " 最近安装的 10 个（第三方）："
  "$BB" awk -F'\t' '$2 == "3rd" {
      k = $3; gsub(/[- :]/, "", k)
      if (k == "" || k < "2015") k = "0"
      printf "%s\t%s\t%s\t%s\t%s\t%s\t%s\n", k, $1, $3, $4, $5, $6, $7
    }' "$TMP/inst_full.tsv" | "$BB" sort -k1,1r > "$TMP/third_sorted.tsv"
  "$BB" head -n 10 "$TMP/third_sorted.tsv" | "$BB" awk -F'\t' '
    { d = $3; if (d == "0") d = "(出厂预装)"
      printf "   %-19s  %-42s  %s\n", d, $2, $5 }'
  o ""
}

# ---------------------------------------------------------------- 3
sec_gone() {
  o "------------------------------------------------------------------"
  o " [2] 已卸载但仍有记录/残留的包（pm list packages -u 差集）"
  o "------------------------------------------------------------------"

  "$BB" comm -23 "$TMP/instu.txt" "$TMP/inst.txt" > "$TMP/gone.txt"
  CNT_GONE=$(wc -l < "$TMP/gone.txt" | tr -d ' ')
  o " 共 $CNT_GONE 个"

  : > "$TMP/resid.tsv"
  while IFS= read -r p; do
    [ -z "$p" ] && continue
    for d in "/data/data/$p" "/data/user/0/$p" "/data/user_de/0/$p" \
             "/data/misc/profiles/cur/0/$p" "/data/misc/profiles/ref/$p" \
             "/data/media/0/Android/data/$p" "/data/media/0/Android/obb/$p"; do
      [ -e "$d" ] || continue
      kb=$("$BB" du -sk "$d" 2>/dev/null | "$BB" cut -f1)
      case "$kb" in ''|*[!0-9]*) kb=0 ;; esac
      printf '%s\t%s\t%s\n' "$p" "$d" "$kb" >> "$TMP/resid.tsv"
    done
  done < "$TMP/gone.txt"

  CNT_RESID=$(wc -l < "$TMP/resid.tsv" | tr -d ' ')
  if [ "$CNT_RESID" -eq 0 ]; then
    o " 未发现残留数据目录（卸载清理得很干净）"
  else
    FREE=$("$BB" awk -F'\t' '{s+=$3} END{print s+0}' "$TMP/resid.tsv")
    o " 共有 $CNT_RESID 个残留路径，合计 $((FREE / 1024)) MB"
    o ""
    o " 包名                                         大小      路径"
    "$BB" sort -t'	' -k3,3nr "$TMP/resid.tsv" | "$BB" head -n 40 | while IFS='	' read -r p d kb; do
      o "  $(printf '%-42s' "$p") $(printf '%-9s' "$(kb2human "$kb")") $d"
    done
    [ "$CNT_RESID" -gt 40 ] && o "  ... 其余 $((CNT_RESID - 40)) 条见 CSV"
    cp "$TMP/resid.tsv" "$OUTDIR/scan-$STAMP-residual.tsv" 2>/dev/null
  fi
  o ""
}

# ---------------------------------------------------------------- 4
sec_orphan() {
  o "------------------------------------------------------------------"
  o " [3] 孤儿目录（有数据目录，但包管理器里连 -u 都查不到）"
  o "------------------------------------------------------------------"

  : > "$TMP/orphan.txt"
  ls /data/data 2>/dev/null | "$BB" sort > "$TMP/dd.txt"
  "$BB" comm -23 "$TMP/dd.txt" "$TMP/instu.txt" > "$TMP/orphan_dd.txt"
  while IFS= read -r p; do
    case "$p" in *.*) ;; *) continue ;; esac      # 包名必含点
    printf '/data/data/%s\n' "$p" >> "$TMP/orphan.txt"
  done < "$TMP/orphan_dd.txt"

  ls /data/media/0/Android/data 2>/dev/null | "$BB" sort > "$TMP/de.txt"
  "$BB" comm -23 "$TMP/de.txt" "$TMP/instu.txt" > "$TMP/orphan_de.txt"
  while IFS= read -r p; do
    case "$p" in *.*) ;; *) continue ;; esac
    printf '/data/media/0/Android/data/%s\n' "$p" >> "$TMP/orphan.txt"
  done < "$TMP/orphan_de.txt"

  CNT_ORPHAN=$(wc -l < "$TMP/orphan.txt" | tr -d ' ')
  o " 共 $CNT_ORPHAN 个"
  if [ "$CNT_ORPHAN" -gt 0 ]; then
    while IFS= read -r d; do
      kb=$("$BB" du -sk "$d" 2>/dev/null | "$BB" cut -f1)
      case "$kb" in ''|*[!0-9]*) kb=0 ;; esac
      o "   $(printf '%-9s' "$(kb2human "$kb")") $d"
    done < "$TMP/orphan.txt"
  fi
  o ""
}

# ---------------------------------------------------------------- 5
sec_sources() {
  o "------------------------------------------------------------------"
  o " [4] 历史记录来源清单（能反推「装过什么」的库/文件）"
  o "------------------------------------------------------------------"
  o " 风险列：L1=日志统计(可重建)  L3=历史库(删了就没)  NO=系统关键(勿动)"
  : > "$TMP/src.tsv"

  cat > "$TMP/sources.conf" <<'EOF'
/data/data/com.xiaomi.market/databases/market_2.db|小米应用商店·事件流水 h_b(i装/d下/u卸/c检查/a激活/e曝光)|L3
/data/data/com.coolapk.market/databases/download.db|酷安·下载记录(官方名+版本+时刻)|L3
/data/data/com.coolapk.market/databases/download_database.db|酷安·下载记录(备用名)|L3
/data/data/com.miui.securitycenter/files/appmanager/appmanager_installer_pkg|安全中心·安装来源(JSON)|L3
/data/data/com.miui.securitycenter/databases/month_report.db|安全中心·月报行为(json,近一月)|L3
/data/data/com.xiaomi.misettings/databases/screen-time-database|设置·屏幕时间(~90天逐应用时长)|L3
/data/system/package-usage.list|PackageManager·包首次/最后使用毫秒时间戳|NO
/data/system/package-dex-usage.list|PackageManager·dex 使用统计|NO
/data/system/package-dcl.list|PackageManager·DCL 记录|NO
/data/system/packages.xml|PackageManager·主数据库(ABX 二进制)|NO
/data/system/packages.list|PackageManager·uid 映射|NO
/data/system/usagestats/0|使用统计(按天)|L1
/data/system/netstats|网络流量统计(按 uid/包)|L1
/data/system/procstats|进程统计|L1
/data/system/dropbox|崩溃/系统事件日志|L1
/data/system/notification_log.db|通知历史|L1
/data/system/app_idle_stats.xml|应用闲置统计|L1
/data/system/job/jobs.xml|JobScheduler 任务(含包名)|L1
/data/system_ce/0/recent_tasks|最近任务(含包名)|L1
/data/system/users/0/runtime-permissions.xml|运行时权限授予记录(含包名)|NO
/data/system/appops.xml|AppOps 记录(含包名)|NO
/data/system/role.xml|角色分配(含包名)|NO
/data/system/users/0/package-restrictions.xml|包限制(含包名)|NO
/data/adb/lspd/config/modules_config.db|LSPosed·模块启用配置|L4
/data/adb/modules|Magisk 模块清单|NO
/data/local/tmp|临时文件(常留 apk/脚本)|L1
/data/anr|ANR 日志(含包名)|L1
/data/tombstones|Native 崩溃(含包名)|L1
/data/log|厂商日志目录|L1
/sdcard/Download|下载目录(可能留 apk)|L2
/sdcard/MIUI/debug_log|MIUI 调试日志|L1
EOF

  while IFS='|' read -r path label risk; do
    [ -z "$path" ] && continue
    if [ -e "$path" ]; then
      if [ -d "$path" ]; then
        kb=$("$BB" du -sk "$path" 2>/dev/null | "$BB" cut -f1)
        n=$(ls "$path" 2>/dev/null | wc -l | tr -d ' ')
        info="$(kb2human "${kb:-0}") / ${n} 项"
      else
        kb=$(stat -c %s "$path" 2>/dev/null)
        info="$(kb2human $(( ${kb:-0} / 1024 )))"
      fi
      mt=$(stat -c %y "$path" 2>/dev/null | cut -c1-16)
      printf '%s\t%s\t%s\t%s\t%s\n' "$path" "$risk" "$info" "$mt" "$label" >> "$TMP/src.tsv"
      o " [有] $(printf '%-5s' "$risk") $(printf '%-10s' "$info") $(printf '%-16s' "$mt") $path"
      o "        └ $label"
    else
      o " [无] $(printf '%-5s' "$risk") $path"
    fi
  done < "$TMP/sources.conf"
  o ""
}

# ---------------------------------------------------------------- 6
# 收集"疑似应用清单缓存"（scan 与 clean 共用，避免 clean 依赖上一次 scan 的产物）
collect_applist() {
  : > "$TMP/applist.tsv"
  for pat in '*applist*' '*app_list*' '*AppList*' '*installed_app*' '*installedapp*' \
             '*installed_packages*' '*app_info*' '*appinfo*' '*packages.json' '*apps.json' \
             '*app_usage*' '*applist.json'; do
    $BB find /data/data -maxdepth 4 -type f -iname "$pat" -size -4096k 2>/dev/null
  done | "$BB" sort -u > "$TMP/applist_raw.txt"

  [ -s "$TMP/applist_raw.txt" ] || return 0
  while IFS= read -r f; do
    kb=$(stat -c %s "$f" 2>/dev/null)
    pkg=$(printf '%s' "$f" | "$BB" cut -d/ -f4)
    printf '%s\t%s\t%s\n' "$f" "$pkg" "$(( ${kb:-0} / 1024 + 1 ))" >> "$TMP/applist.tsv"
  done < "$TMP/applist_raw.txt"
}

sec_applist() {
  o "------------------------------------------------------------------"
  o " [5] 可能被用来「拉应用列表」的位置（第三方缓存 / 系统枚举入口）"
  o "------------------------------------------------------------------"

  collect_applist

  if [ -s "$TMP/applist.tsv" ]; then
    o " 发现 $(wc -l < "$TMP/applist.tsv" | tr -d ' ') 个疑似应用清单缓存文件"
    o ""
    o " 大小     所属应用                            文件"
    "$BB" sort -t'	' -k3,3nr "$TMP/applist.tsv" | "$BB" head -n 30 | while IFS='	' read -r f pkg kb; do
      o " $(printf '%-8s' "$(kb2human "$kb")") $(printf '%-35s' "$pkg") $f"
    done
    cp "$TMP/applist.tsv" "$OUTDIR/scan-$STAMP-applist.tsv" 2>/dev/null
  else
    o " 未发现按名字可识别的应用清单缓存"
  fi

  o ""
  o " 系统侧固定枚举入口（这些不能删，删了系统起不来，只能理解其存在）："
  for p in /data/system/packages.xml /data/system/packages.list /data/system/users/0/runtime-permissions.xml \
           /data/system/appops.xml /data/system/role.xml /data/system/package_cache \
           /data/system/users/0/package-restrictions.xml /data/system/shortcut*; do
    [ -e "$p" ] && o "   · $p"
  done
  o ""
  o " 说明：任何拿到 QUERY_ALL_PACKAGES 或已有 root 的程序都能实时向 PackageManager 查询已安装列表，"
  o "       这不是「缓存」，删文件删不掉。真正的「隐藏」需要 Xposed 级方案（如 Hide MyApplist / Hail）。"
  o "       本模块能做的是：清掉「历史快照」与「使用痕迹」，让「装过什么」无从反推。"
  o ""
}

# ---------------------------------------------------------------- 6
# 其他应用数据里存的安装记录（内容级判定，见 lib/appdata.sh）
sec_appdata() {
  o "------------------------------------------------------------------"
  o " [6] 其他软件自己的数据里存的「应用清单」（内容级匹配）"
  o "------------------------------------------------------------------"
  o " 做法：拿全部已装包名当特征串，逐个搜第三方应用的 databases/shared_prefs/files"
  o ""
  ad_report
}

# ---------------------------------------------------------------- 7
sec_summary() {
  o "------------------------------------------------------------------"
  o " [7] 汇总"
  o "------------------------------------------------------------------"
  o " 已安装            : $CNT_ALL（第三方 $CNT_3RD）"
  o " 已卸载但有记录    : $CNT_GONE"
  o " 残留路径          : ${CNT_RESID:-0}"
  o " 孤儿目录          : ${CNT_ORPHAN:-0}"
  o " 历史来源命中      : $(wc -l < "$TMP/src.tsv" 2>/dev/null | tr -d ' ')"
  o " 应用清单缓存      : $(wc -l < "$TMP/applist.tsv" 2>/dev/null | tr -d ' ')"
  o " 应用数据快照      : ${AD_STRONG:-0} 个文件 / ${AD_APPS:-0} 个应用（阈值 $AD_MIN_HITS 个包名）"
  o ""
}

# ---------------------------------------------------------------- JSON
build_json() {
  : > "$TMP/body.json"

  printf '{"meta":{"time":"%s","model":"%s","device":"%s","android":"%s","sdk":"%s","build":"%s","module":"%s"},' \
    "$(ts_now)" "$(getprop ro.product.model)" "$(getprop ro.product.device)" \
    "$(getprop ro.build.version.release)" "$(getprop ro.build.version.sdk)" \
    "$(getprop ro.build.version.incremental)" \
    "$(grep '^version=' "$MODDIR/module.prop" 2>/dev/null | cut -d= -f2)" >> "$TMP/body.json"

  printf '"stats":{"installed":%s,"third":%s,"gone":%s,"residual":%s,"orphan":%s},' \
    "${CNT_ALL:-0}" "${CNT_3RD:-0}" "${CNT_GONE:-0}" "${CNT_RESID:-0}" "${CNT_ORPHAN:-0}" >> "$TMP/body.json"

  printf '"installed":[' >> "$TMP/body.json"
  "$BB" awk -F'\t' '
    function sep() { if (first) { first = 0; return "" } return "," }
    BEGIN { first = 1 }
    {
      gsub(/\\/, "\\\\", $1); gsub(/"/, "\\\"", $1)
      gsub(/\\/, "\\\\", $5); gsub(/"/, "\\\"", $5)
      gsub(/\\/, "\\\\", $6); gsub(/"/, "\\\"", $6)
      gsub(/\\/, "\\\\", $7); gsub(/"/, "\\\"", $7)
      p = 0
      if ($3 ~ /^1970/ || $3 ~ /^200[0-9]/) p = 1
      if ($3 != "" && $3 < "2015") p = 1
      printf "%s{\"pkg\":\"%s\",\"kind\":\"%s\",\"first\":\"%s\",\"last\":\"%s\",\"ver\":\"%s\",\"path\":\"%s\",\"installer\":\"%s\",\"pre\":%d}", \
             sep(), $1, $2, $3, $4, $5, $6, $7, p
    }' "$TMP/inst_full.tsv" >> "$TMP/body.json"
  printf '],' >> "$TMP/body.json"

  printf '"gone":[' >> "$TMP/body.json"
  "$BB" awk '
    function sep() { if (first) { first = 0; return "" } return "," }
    BEGIN { first = 1 }
    { printf "%s\"%s\"", sep(), $0 }' "$TMP/gone.txt" >> "$TMP/body.json"
  printf '],' >> "$TMP/body.json"

  printf '"residual":[' >> "$TMP/body.json"
  "$BB" awk -F'\t' '
    function sep() { if (first) { first = 0; return "" } return "," }
    BEGIN { first = 1 }
    { printf "%s{\"pkg\":\"%s\",\"path\":\"%s\",\"kb\":%s}", sep(), $1, $2, $3 }' \
    "$TMP/resid.tsv" >> "$TMP/body.json"
  printf '],' >> "$TMP/body.json"

  printf '"orphan":[' >> "$TMP/body.json"
  "$BB" awk '
    function sep() { if (first) { first = 0; return "" } return "," }
    BEGIN { first = 1 }
    { printf "%s\"%s\"", sep(), $0 }' "$TMP/orphan.txt" >> "$TMP/body.json"
  printf '],' >> "$TMP/body.json"

  printf '"sources":[' >> "$TMP/body.json"
  "$BB" awk -F'\t' '
    function sep() { if (first) { first = 0; return "" } return "," }
    BEGIN { first = 1 }
    { printf "%s{\"path\":\"%s\",\"risk\":\"%s\",\"info\":\"%s\",\"mtime\":\"%s\",\"label\":\"%s\"}", sep(), $1, $2, $3, $4, $5 }' \
    "$TMP/src.tsv" >> "$TMP/body.json"
  printf '],' >> "$TMP/body.json"

  printf '"applist":[' >> "$TMP/body.json"
  "$BB" awk -F'\t' '
    function sep() { if (first) { first = 0; return "" } return "," }
    BEGIN { first = 1 }
    { printf "%s{\"path\":\"%s\",\"pkg\":\"%s\",\"kb\":%s}", sep(), $1, $2, $3 }' \
    "$TMP/applist.tsv" >> "$TMP/body.json"
  printf '],' >> "$TMP/body.json"

  printf '"appdata":[' >> "$TMP/body.json"
  "$BB" awk -F'\t' -v th="$AD_MIN_HITS" '
    function sep() { if (first) { first = 0; return "" } return "," }
    BEGIN { first = 1 }
    {
      n = $1 + 0
      st = "weak"
      if (n >= th) st = "strong"
      gsub(/\\/, "\\\\", $5); gsub(/"/, "\\\"", $5)
      printf "%s{\"hits\":%d,\"bytes\":%s,\"owner\":\"%s\",\"cls\":\"%s\",\"path\":\"%s\",\"level\":\"%s\"}", \
             sep(), n, $2, $3, $4, $5, st
    }' "$TMP/ad.tsv" >> "$TMP/body.json"
  printf ']}' >> "$TMP/body.json"

  # 注意：不能用 mv 往 /sdcard 搬 —— busybox mv 会尝试 setfilecon，
  # 而 FUSE 挂载不支持，报 "Operation not supported on transport endpoint"（文件其实已生成，但报错吓人）
  "$BB" cat "$TMP/body.json" > "$OUTDIR/scan-$STAMP.json"
}
