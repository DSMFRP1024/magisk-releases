# appdata.sh —— 「其他应用数据里的安装记录」检测与分级清理
#
# 背景：Android 的 PackageManager 只保存「当前」已安装集合，卸载即抹除。
#       但很多应用（清理类、应用商店、推送 SDK、管理工具）会把当时扫到的
#       应用清单写进自己的数据库 / 偏好文件，而且卸载时不清理。
#       这些「第三方侧快照」是事后反推「装过什么」的主要证据来源。
#
# 判定：拿全部已装包名当特征串做多模式匹配，同一文件命中 >= AD_MIN_HITS
#       个不同包名 ⇒ 判定该文件存了应用清单（单个包名偶现属正常，如 deeplink 配置）。
#
# 分级（决定能不能删）：
#   cache  扫描缓存（pkgcache/pkgquery/junk/clearpath/applist*）→ 删了会重建，安全
#   prefs  shared_prefs 里的偏好文件        → 删了该应用丢设置，需 --force
#   tool   应用管理工具的主库（apps.db）     → 删了工具丢全部记录，需 --force
#   appdb  其他应用的主数据库               → 删整库代价大，需 --appdata=db

AD_MIN_HITS=${AD_MIN_HITS:-8}
AD_WEAK_HITS=${AD_WEAK_HITS:-5}

# 生成匹配模式：包名长度 > 8，避免 "com.a.b" 这类短串误命中
ad_patterns() {
  : > "$TMP/ad_pat.txt"
  "$BB" awk 'length($0) > 8' "$TMP/inst.txt" 2>/dev/null \
    | "$BB" grep -v -x -e 'io.github.muntashirakon.AppManager' \
    | "$BB" sort -u > "$TMP/ad_pat.txt" 2>/dev/null
  "$BB" wc -l < "$TMP/ad_pat.txt" | "$BB" tr -d ' '
}

# 分类
ad_class() {
  case "$1" in
    */pkgcache*|*/pkgquery*|*/pkg_cache*|*/junk*.db|*/clearpath*|*/applist*|*/app_list*|*/installed_app*|*/installedapp*)
      printf 'cache' ;;
    */shared_prefs/*)
      printf 'prefs' ;;
    */databases/apps.db|*/databases/apps_*.db)
      printf 'tool' ;;
    *)
      printf 'appdb' ;;
  esac
}

# 扫描：结果写入 $TMP/ad.tsv
#   列：hits  大小  所属应用  分类  路径  样本包名
ad_scan() {
  [ -f "$TMP/inst.txt" ] || return 0
  np=$(ad_patterns)
  [ "${np:-0}" -gt 0 ] || return 0

  # 第三方应用目录（系统应用存清单属系统功能，不算「其他软件」）
  : > "$TMP/ad_dirs.txt"
  while IFS= read -r p; do
    [ -n "$p" ] || continue
    [ -d "/data/data/$p" ] && printf '%s\n' "$p" >> "$TMP/ad_dirs.txt"
  done < "$TMP/third.txt"

  # 候选文件：一次扫全 /data/data（深度 3），再按第三方包名过滤。
  # ★ 不能让 xargs 把路径追加到 find 末尾 —— busybox find 要求路径在表达式之前，
  #   写成 "find -maxdepth 3 ... /path" 会报 "find: unrecognized: /path"。
  # ★ busybox find 也不认 -size -4M（报 invalid number），必须 -size -4096k。
  : > "$TMP/ad_cand.txt"
  "$BB" find /data/data -maxdepth 3 -type f -size -4096k \
    \( -path '*/databases/*' -o -path '*/shared_prefs/*' -o -path '*/files/*' \) \
    \( -name '*.db' -o -name '*.xml' -o -name '*.json' -o -name '*.dat' \
       -o -name '*.txt' -o -name '*.cfg' -o -name '*.ini' -o -name '*.conf' \
       -o -name '*.prefs' -o -name '*.xml.bak' \) 2>/dev/null \
    | "$BB" awk -F/ 'NR == FNR { t[$1] = 1; next } { if ($4 in t) print }' \
        "$TMP/ad_dirs.txt" - > "$TMP/ad_cand.txt"
  "$BB" sort -u "$TMP/ad_cand.txt" > "$TMP/ad_cand2.txt" 2>/dev/null
  "$BB" cat "$TMP/ad_cand2.txt" > "$TMP/ad_cand.txt"

  # 一次批量匹配：输出 "路径:匹配串"，再按路径聚合唯一匹配数
  : > "$TMP/ad_raw.txt"
  "$BB" xargs "$BB" grep -o -H -F -f "$TMP/ad_pat.txt" \
    < "$TMP/ad_cand.txt" > "$TMP/ad_raw.txt" 2>/dev/null

  "$BB" awk '
    {
      i = index($0, ":")
      if (i < 2) next
      f = substr($0, 1, i - 1)
      m = substr($0, i + 1)
      if (m == "") next
      if (!((f, m) in S)) { S[f, m] = 1; C[f] = C[f] + 1 }
    }
    END { for (f in C) printf "%d\t%s\n", C[f], f }
  ' "$TMP/ad_raw.txt" | "$BB" sort -rn > "$TMP/ad_cnt.txt"

  # 补大小 / 归属 / 分类
  : > "$TMP/ad.tsv"
  while IFS='	' read -r n f; do
    case "$n" in ''|*[!0-9]*) continue ;; esac
    [ -f "$f" ] || continue
    sz=$(stat -c %s "$f" 2>/dev/null)
    case "$sz" in ''|*[!0-9]*) sz=0 ;; esac
    owner=$(printf '%s' "$f" | "$BB" cut -d/ -f4)
    cls=$(ad_class "$f")
    printf '%s\t%s\t%s\t%s\t%s\n' "$n" "$sz" "$owner" "$cls" "$f" >> "$TMP/ad.tsv"
  done < "$TMP/ad_cnt.txt"
}

# 供 scan 段调用：只读展示
ad_report() {
  ad_scan
  AD_TOTAL=$("$BB" wc -l < "$TMP/ad.tsv" 2>/dev/null | "$BB" tr -d ' ')
  case "$AD_TOTAL" in ''|*[!0-9]*) AD_TOTAL=0 ;; esac
  AD_STRONG=0
  AD_APPS=0
  if [ "$AD_TOTAL" -gt 0 ]; then
    AD_STRONG=$("$BB" awk -F'	' -v t="$AD_MIN_HITS" '$1 >= t' "$TMP/ad.tsv" | "$BB" wc -l | "$BB" tr -d ' ')
    AD_APPS=$("$BB" awk -F'	' -v t="$AD_MIN_HITS" '$1 >= t {print $3}' "$TMP/ad.tsv" | "$BB" sort -u | "$BB" wc -l | "$BB" tr -d ' ')
  fi

  o " 判定阈值：同一文件命中 >= ${AD_MIN_HITS} 个不同包名（弱证据 ${AD_WEAK_HITS}-$((AD_MIN_HITS - 1)) 个只列不判）"
  o " 命中文件 $AD_TOTAL 个｜其中达到阈值的 $AD_STRONG 个，分布在 $AD_APPS 个应用"
  o ""
  if [ "$AD_STRONG" -gt 0 ]; then
    o " 命中  大小      应用                                    分类   文件"
    "$BB" awk -F'	' -v t="$AD_MIN_HITS" '$1 >= t' "$TMP/ad.tsv" \
      | "$BB" sort -t'	' -k1,1nr | "$BB" head -n 40 \
      | while IFS='	' read -r n sz owner cls f; do
          o " $(printf '%-5s' "$n") $(printf '%-9s' "$(kb2human $(( sz / 1024 + 1 )))") $(printf '%-40s' "$owner") $(printf '%-6s' "$cls") $f"
        done
    o ""
    o " 分类含义："
    o "   cache = 扫描缓存（pkgcache/pkgquery/junk/clearpath/applist*），删了会重建 → 可清"
    o "   prefs = shared_prefs 偏好文件，删了该应用丢设置        → 需 --force"
    o "   tool  = 应用管理工具主库（apps.db），删了工具丢记录     → 需 --force"
    o "   appdb = 其他应用主数据库，删整库代价大                → 需 --appdata=db"
  else
    o " 未发现达到阈值的应用清单快照"
  fi

  cp "$TMP/ad.tsv" "$OUTDIR/scan-$STAMP-appdata.tsv" 2>/dev/null
  o ""
  o " 说明：清掉这些只是抹掉「第三方侧的历史快照」。有 QUERY_ALL_PACKAGES 权限的应用"
  o "       随时可以重新扫一遍并再写回去，要根治得限制其权限（AppOps 的 GET_TASKS /"
  o "       QUERY_ALL_PACKAGES，或用 Hide MyApplist 之类方案）。"
  o ""
}

# 供 clean 段调用：按级别删
#   MODE=cache 只清 cache 类；MODE=prefs 加 prefs/tool；MODE=db 全清
ad_clean() {
  MODE=$1
  ad_scan
  cnt=0
  if [ ! -s "$TMP/ad.tsv" ]; then
    o "   （无）"
    o ""
    return 0
  fi
  while IFS='	' read -r n sz owner cls f; do
    case "$n" in ''|*[!0-9]*) continue ;; esac
    [ "$n" -ge "$AD_MIN_HITS" ] || continue
    case "$cls" in
      cache)
        do_rm "$f" ;;
      prefs|tool)
        case "$MODE" in
          prefs|db) do_rm "$f" ;;
          *) o "   [跳过·需 --appdata=prefs] $f ($(kb2human $(( sz / 1024 + 1 ))))" ;;
        esac ;;
      appdb)
        case "$MODE" in
          db) do_rm "$f" ;;
          *) o "   [跳过·需 --appdata=db] $f ($(kb2human $(( sz / 1024 + 1 ))))" ;;
        esac ;;
    esac
  done < "$TMP/ad.tsv"
  o ""
}
