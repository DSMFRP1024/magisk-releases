# json.sh —— 纯 JSON 操作层（无 HTTP 头）
#
# 两个消费方共用同一套实现：
#   ① KernelSU / APatch / MMRL 的 WebUI：页面用 ksu.exec 执行 `tc json <op>`
#   ② 浏览器（tc web start 的 httpd）：cgi-bin/json 转调 `tc json <op>`
#
# 约定：每个 op 只往 stdout 打一行 JSON，不打印任何日志（日志一律进文件）
#   status | scan-start | result | clean-start <clean 参数> | job
#   update-start | check-update | run-clean（内部）| run-update（内部）

J_WEB=$DATADIR/web

jstr() { printf '%s' "$1" | "$BB" tr -d '\r\n' | "$BB" sed -e 's/\\/\\\\/g' -e 's/"/\\"/g'; }
jbool() { case "$1" in true|1|yes) printf 'true' ;; *) printf 'false' ;; esac; }
jnum() { case "$1" in ''|*[!0-9-]*) printf '0' ;; *) printf '%s' "$1" ;; esac; }

# 文件内容 → JSON 字符串（保留换行；与 cgi-bin/_common.sh 的 jesc_file 同算法）
jfile() {
  if [ ! -s "$1" ]; then printf ''; return 0; fi
  "$BB" awk '{gsub(/\\/,"\\\\"); gsub(/"/,"\\\""); gsub(/\t/,"\\t"); printf "%s\\n",$0}' "$1" \
    | "$BB" sed '$s/\\n$//'
}

# 单行错误
jerr() { printf '{"ok":false,"error":"%s"}' "$(jstr "$1")"; }

j_rootname() {
  if [ -x /data/adb/ksu/bin/busybox ] || [ -d /data/adb/ksu ]; then printf 'KernelSU'
  elif [ -d /data/adb/ap ]; then printf 'APatch'
  else printf 'Magisk'; fi
}

j_lastscan() { "$BB" ls -t "$OUTDIR"/scan-*.json 2>/dev/null | "$BB" head -n 1; }

# ---------------------------------------------------------------- status
j_status() {
  _ver=$("$BB" grep '^version=' "$MODDIR/module.prop" 2>/dev/null | "$BB" cut -d= -f2)
  _port=$("$BB" cat "$J_WEB/port" 2>/dev/null)
  case "$_port" in ''|*[!0-9]*) _port=6789 ;; esac

  _w=false; job_running "$J_WEB/httpd.pid"  && _w=true
  _s=false; job_running "$J_WEB/scan.pid"   && _s=true
  _c=false; job_running "$J_WEB/clean.pid"  && _c=true
  _u=false; job_running "$J_WEB/update.pid" && _u=true

  _f=$(j_lastscan)
  _ft=
  [ -n "$_f" ] && _ft=$("$BB" stat -c %y "$_f" 2>/dev/null | "$BB" cut -c1-19)

  printf '{"ok":true,"module":"%s","model":"%s","android":"%s","sdk":"%s","root":"%s","web":{"running":%s,"port":%s},"scan":{"running":%s,"last":"%s"},"clean":{"running":%s},"update":{"running":%s}}' \
    "$(jstr "$_ver")" \
    "$(jstr "$(getprop ro.product.model)")" \
    "$(jstr "$(getprop ro.build.version.release)")" \
    "$(jstr "$(getprop ro.build.version.sdk)")" \
    "$(j_rootname)" \
    "$(jbool "$_w")" "$(jnum "$_port")" \
    "$(jbool "$_s")" "$(jstr "$_ft")" \
    "$(jbool "$_c")" "$(jbool "$_u")"
}

# ---------------------------------------------------------------- 扫描
# 后台跑（内容级扫描约 1~2 分钟），页面轮询 job
j_scan_start() {
  if job_running "$J_WEB/scan.pid"; then
    printf '{"ok":false,"msg":"扫描已在进行，请稍候"}'; return 0
  fi
  if job_running "$J_WEB/clean.pid"; then
    printf '{"ok":false,"msg":"清理任务正在进行，暂不能扫描"}'; return 0
  fi
  mkdir -p "$J_WEB" 2>/dev/null
  : > "$J_WEB/scan.log"
  "$BB" setsid sh "$MODDIR/bin/tc" scan >> "$J_WEB/scan.log" 2>&1 < /dev/null &
  printf '%s\n' "$!" > "$J_WEB/scan.pid"
  printf '{"ok":true,"msg":"扫描已启动，完成后自动刷新"}'
}

j_result() {
  _f=$(j_lastscan)
  if [ -z "$_f" ] || [ ! -s "$_f" ]; then
    jerr "还没有扫描结果，先点「开始扫描」"; return 0
  fi
  "$BB" cat "$_f"
}

# ---------------------------------------------------------------- 清理
# 参数与 tc clean 完全一致；默认预演，加 --confirm 才真删
j_clean_start() {
  if job_running "$J_WEB/scan.pid"; then
    printf '{"ok":false,"msg":"扫描任务正在进行，暂不能清理"}'; return 0
  fi
  if job_running "$J_WEB/clean.pid"; then
    printf '{"ok":false,"msg":"清理已在进行，请稍候"}'; return 0
  fi
  mkdir -p "$J_WEB" 2>/dev/null
  : > "$J_WEB/clean.out"
  rm -f "$J_WEB/clean.rc"
  # 用独立进程组跑，页面断开也不影响；rc 由 run-clean 落盘
  "$BB" setsid sh "$MODDIR/bin/tc" json run-clean "$@" >> "$J_WEB/clean.out" 2>&1 < /dev/null &
  printf '%s\n' "$!" > "$J_WEB/clean.pid"
  printf '{"ok":true,"msg":"清理已启动"}'
}

# 内部：同步执行 clean 并记录退出码（不直接给页面用）
j_run_clean() {
  sh "$MODDIR/bin/tc" clean "$@"
  printf '%s\n' "$?" > "$J_WEB/clean.rc"
  return 0
}

# ---------------------------------------------------------------- 更新
j_update_start() {
  if job_running "$J_WEB/update.pid"; then
    printf '{"ok":false,"msg":"已有安装任务在跑"}'; return 0
  fi
  mkdir -p "$J_WEB" 2>/dev/null
  : > "$J_WEB/update.out"
  rm -f "$J_WEB/update.rc"
  "$BB" setsid sh "$MODDIR/bin/tc" json run-update >> "$J_WEB/update.out" 2>&1 < /dev/null &
  printf '%s\n' "$!" > "$J_WEB/update.pid"
  printf '{"ok":true,"msg":"开始下载并安装"}'
}

j_run_update() {
  sh "$MODDIR/bin/tc" update install
  printf '%s\n' "$?" > "$J_WEB/update.rc"
  return 0
}

j_check_update() {
  if upd_check; then
    upd_json
  else
    jerr "$UPD_ERR"
  fi
}

# ---------------------------------------------------------------- 轮询
j_job() {
  _s=false; job_running "$J_WEB/scan.pid"   && _s=true
  _c=false; job_running "$J_WEB/clean.pid"  && _c=true
  _u=false; job_running "$J_WEB/update.pid" && _u=true

  _rc=0
  [ -s "$J_WEB/clean.rc" ] && _rc=$(jnum "$("$BB" cat "$J_WEB/clean.rc" 2>/dev/null)")
  _urc=0
  [ -s "$J_WEB/update.rc" ] && _urc=$(jnum "$("$BB" cat "$J_WEB/update.rc" 2>/dev/null)")

  _items=0
  [ -s "$J_WEB/clean.out" ] && _items=$("$BB" grep -E -c '\[(dry|已删)\]' "$J_WEB/clean.out" 2>/dev/null)
  _items=$(jnum "$_items")
  _sum=$("$BB" grep '合计' "$J_WEB/clean.out" 2>/dev/null | "$BB" tail -n 1 | "$BB" tr -d '\r\n')

  # 只回传尾部：清理明细可能上万行，手机 WebView 里塞满会卡
  _cp=$J_WEB/.clean.tail; _sp=$J_WEB/.scan.tail; _up=$J_WEB/.upd.tail
  "$BB" tail -c 45000 "$J_WEB/clean.out"  2>/dev/null > "$_cp"
  "$BB" tail -c 20000 "$J_WEB/scan.log"   2>/dev/null > "$_sp"
  "$BB" tail -c 20000 "$J_WEB/update.out" 2>/dev/null > "$_up"

  printf '{"ok":true,"scan":{"running":%s,"log":"%s"},"clean":{"running":%s,"rc":%s,"items":%s,"summary":"%s","output":"%s"},"update":{"running":%s,"rc":%s,"log":"%s"}}' \
    "$(jbool "$_s")" "$(jfile "$_sp")" \
    "$(jbool "$_c")" "$_rc" "$_items" "$(jstr "$_sum")" "$(jfile "$_cp")" \
    "$(jbool "$_u")" "$_urc" "$(jfile "$_up")"
}

# ---------------------------------------------------------------- 分发
j_main() {
  mkdir -p "$J_WEB" 2>/dev/null
  case "$1" in
    status)       j_status ;;
    scan-start)   j_scan_start ;;
    result)       j_result ;;
    clean-start)  shift; j_clean_start "$@" ;;
    run-clean)    shift; j_run_clean "$@" ;;
    update-start) j_update_start ;;
    run-update)   j_run_update ;;
    check-update) j_check_update ;;
    job)          j_job ;;
    '')           jerr "缺少操作名：status|scan-start|result|clean-start|job|update-start|check-update" ;;
    *)            jerr "未知操作：$1" ;;
  esac
  printf '\n'
}
