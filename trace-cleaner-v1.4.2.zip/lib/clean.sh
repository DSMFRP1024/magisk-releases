# clean.sh —— 分级清理
# L1 日志/统计（系统会重建）
# L2 卸载残留 + 孤儿目录（含 sdcard 侧）
# L3 历史库整库（删了不可恢复，靠备份）
# L4 LSPosed 模块配置（需 --xposed）

clean_main() {
  LEVEL=1
  CONFIRM=0
  DO_BACKUP=1
  FORCE=0
  XP=0
  WANT_APK=0
  ALLOW_INSTALLED=0
  ALLOW_APPDATA=0
  APPDATA_MODE=none

  while [ $# -gt 0 ]; do
    case "$1" in
      --level) LEVEL=$2; shift 2 ;;
      --level=*) LEVEL=${1#*=}; shift ;;
      --confirm|-y) CONFIRM=1; shift ;;
      --no-backup) DO_BACKUP=0; shift ;;
      --force) FORCE=1; shift ;;
      --xposed) XP=1; shift ;;
      --apks) WANT_APK=1; shift ;;
      --appdata) APPDATA_MODE=cache; shift ;;
      --appdata=*) APPDATA_MODE=${1#*=}; shift ;;
      *) die "未知参数：$1（用 tc help 查看用法）" ;;
    esac
  done
  case "$LEVEL" in 1|2|3) ;; *) die "--level 只能是 1 / 2 / 3" ;; esac
  case "$APPDATA_MODE" in
    none|cache|prefs|db) ;;
    *) die "--appdata 只能是 cache / prefs / db" ;;
  esac

  TMP=$DATADIR/tmp
  mkdir -p "$TMP" "$DATADIR/log" "$OUTDIR" || die "无法创建 $DATADIR"
  STAMP=$(ts_name)

  if [ "$CONFIRM" = 1 ]; then DRYRUN=0; else DRYRUN=1; fi
  [ "$APPDATA_MODE" = none ] || ALLOW_APPDATA=1
  export ALLOW_APPDATA ALLOW_INSTALLED

  # 建立基线：已安装集合
  pm list packages 2>/dev/null | "$BB" sed 's/^package://' | "$BB" sort > "$TMP/inst.txt"
  pm list packages -u 2>/dev/null | "$BB" sed 's/^package://' | "$BB" sort > "$TMP/instu.txt"
  "$BB" comm -23 "$TMP/instu.txt" "$TMP/inst.txt" > "$TMP/gone.txt"

  OUT="$OUTDIR/clean-$STAMP.txt"
  : > "$OUT"

  o "=================================================================="
  o " TraceCleaner 清理 $([ "$DRYRUN" = 1 ] && echo '（预演 / DRY-RUN，不会真的删）' || echo '（执行模式）')"
  o " 级别 : L$LEVEL$([ "$XP" = 1 ] && echo ' + LSPosed')$([ "$APPDATA_MODE" != none ] && echo " + appdata=$APPDATA_MODE")"
  o " 时间 : $(ts_now)"
  o " 备份 : $([ "$DO_BACKUP" = 1 ] && echo "开启 → $DATADIR/backup/" || echo '关闭（--no-backup）')"
  o "=================================================================="
  o ""

  l1_plan
  [ "$LEVEL" -ge 2 ] && l2_plan
  [ "$LEVEL" -ge 3 ] && l3_plan
  [ "$XP" = 1 ] && l4_plan

  o ""
  o "------------------------------------------------------------------"
  o " 合计：$DEL_OK 项，约 $(kb2human "$DEL_FREE_KB")"

  if [ "$DRYRUN" = 1 ]; then
    _x=
    if [ "$XP" = 1 ]; then _x="$_x --xposed"; fi
    if [ "$APPDATA_MODE" != none ]; then _x="$_x --appdata=$APPDATA_MODE"; fi
    if [ "$FORCE" = 1 ]; then _x="$_x --force"; fi
    o ""
    o " 以上为预演结果，未做任何改动。"
    o " 确认无误后执行："
    o "   su -c 'sh $MODDIR/bin/tc clean --level $LEVEL$_x --confirm'"
  else
    o ""
    o " 清理完成。建议重启一次，让系统重建被删的统计/日志库："
    o "   su -c reboot"
    o " 备份目录：${BACKUP_ROOT:-无（未产生备份）}"
    o ""
    o " 复核："
    o "   su -c 'sh $MODDIR/bin/tc verify'"
  fi
  log "clean level=$LEVEL dryrun=$DRYRUN confirm=$CONFIRM items=$DEL_OK kb=$DEL_FREE_KB"
  o ""
  o " 报告：$OUT"
}

# ------------------------------------------------------------ L1
l1_plan() {
  o "------------------------------------------------------------------"
  o " [L1] 日志与使用统计（系统会自动重建，风险低）"
  o "------------------------------------------------------------------"

  do_rm_glob "/data/system/usagestats/0/daily/*"
  do_rm_glob "/data/system/usagestats/0/*.bin"
  do_rm_glob "/data/system/usagestats/0/*.xml"
  do_rm_glob "/data/system/usagestats/*.bin"
  do_rm_glob "/data/system/netstats/*"
  do_rm_glob "/data/system/procstats/*"
  do_rm_glob "/data/system/dropbox/*"
  do_rm_glob "/data/system/notification_log.db*"
  do_rm_glob "/data/system/app_idle_stats.xml"
  do_rm_glob "/data/system/job/jobs.xml"
  do_rm_glob "/data/system_ce/0/recent_tasks/*"
  do_rm_glob "/data/system_ce/0/recent_images/*"
  do_rm_glob "/data/anr/*"
  do_rm_glob "/data/tombstones/*"
  do_rm_glob "/data/log/*"

  # 临时文件（保留白名单与正在用的脚本）
  for f in /data/local/tmp/*; do
    [ -e "$f" ] || continue
    b=${f##*/}
    case "$b" in
      tc_*|_tc*) continue ;;
    esac
    do_rm "$f"
  done

  if [ "$DRYRUN" = 1 ]; then
    o "   [dry] logcat -b all -c  （清空全部日志缓冲区）"
  else
    logcat -b all -c 2>/dev/null && o "   [已删] logcat 全部缓冲区" || o "   [跳过] logcat 缓冲区清空失败"
  fi
  o ""
}

# ------------------------------------------------------------ L2
l2_plan() {
  o "------------------------------------------------------------------"
  o " [L2] 卸载残留 + 孤儿目录（删掉后 pm list -u 应不再有它）"
  o "------------------------------------------------------------------"

  : > "$TMP/resid.tsv"
  while IFS= read -r p; do
    [ -z "$p" ] && continue
    if in_whitelist "$p"; then
      o "   [跳过·白名单] $p"
      continue
    fi
    for d in "/data/data/$p" "/data/user/0/$p" "/data/user_de/0/$p" \
             "/data/misc/profiles/cur/0/$p" "/data/misc/profiles/ref/$p" \
             "/data/media/0/Android/data/$p" "/data/media/0/Android/obb/$p"; do
      [ -e "$d" ] || continue
      do_rm "$d"
    done
    # dalvik-cache 里的 dex/vdex
    for f in /data/dalvik-cache/*/"$p"@*; do
      [ -e "$f" ] || continue
      do_rm "$f"
    done
    # /data/app 下残留目录（正常卸载不会留，但异常卸载会）
    for f in /data/app/*/"$p"-*; do
      [ -e "$f" ] || continue
      do_rm "$f"
    done
    # package_cache
    for f in /data/system/package_cache/*/"$p"*; do
      [ -e "$f" ] || continue
      do_rm "$f"
    done
  done < "$TMP/gone.txt"

  # 孤儿数据目录
  : > "$TMP/orphan.txt"
  ls /data/data 2>/dev/null | "$BB" sort > "$TMP/dd.txt"
  "$BB" comm -23 "$TMP/dd.txt" "$TMP/instu.txt" > "$TMP/orphan_dd.txt"
  while IFS= read -r p; do
    case "$p" in *.*) ;; *) continue ;; esac
    printf '/data/data/%s\n' "$p" >> "$TMP/orphan.txt"
  done < "$TMP/orphan_dd.txt"
  ls /data/media/0/Android/data 2>/dev/null | "$BB" sort > "$TMP/de.txt"
  "$BB" comm -23 "$TMP/de.txt" "$TMP/instu.txt" > "$TMP/orphan_de.txt"
  while IFS= read -r p; do
    case "$p" in *.*) ;; *) continue ;; esac
    printf '/data/media/0/Android/data/%s\n' "$p" >> "$TMP/orphan.txt"
  done < "$TMP/orphan_de.txt"

  if [ -s "$TMP/orphan.txt" ]; then
    o ""
    o " 孤儿目录："
    while IFS= read -r d; do
      do_rm "$d"
    done < "$TMP/orphan.txt"
  fi

  if [ "$WANT_APK" = 1 ]; then
    o ""
    o " Download 下的安装包（--apks 显式要求才删）："
    for f in /sdcard/Download/*.apk /sdcard/Download/*.apks /sdcard/Download/*.xapk /sdcard/Download/*.apkm; do
      [ -e "$f" ] || continue
      do_rm "$f"
    done
  fi
  o ""
}

# ------------------------------------------------------------ L3
l3_plan() {
  o "------------------------------------------------------------------"
  o " [L3] 历史库（删除后应用内历史清空，不可恢复，靠备份兜底）"
  o "------------------------------------------------------------------"

  do_rm_glob "/data/data/com.xiaomi.market/databases/market_2.db"
  do_rm_glob "/data/data/com.xiaomi.market/databases/market_2.db-wal"
  do_rm_glob "/data/data/com.xiaomi.market/databases/market_2.db-shm"
  do_rm_glob "/data/data/com.xiaomi.market/databases/market_2.db-journal"

  do_rm_glob "/data/data/com.coolapk.market/databases/download.db"
  do_rm_glob "/data/data/com.coolapk.market/databases/download.db-wal"
  do_rm_glob "/data/data/com.coolapk.market/databases/download.db-shm"
  do_rm_glob "/data/data/com.coolapk.market/databases/download_database.db*"

  do_rm "/data/data/com.miui.securitycenter/files/appmanager/appmanager_installer_pkg"
  do_rm_glob "/data/data/com.miui.securitycenter/databases/month_report.db"
  do_rm_glob "/data/data/com.miui.securitycenter/databases/month_report.db-wal"
  do_rm_glob "/data/data/com.miui.securitycenter/databases/month_report.db-shm"

  do_rm_glob "/data/data/com.xiaomi.misettings/databases/screen-time-database"
  do_rm_glob "/data/data/com.xiaomi.misettings/databases/screen-time-database-wal"
  do_rm_glob "/data/data/com.xiaomi.misettings/databases/screen-time-database-shm"

  # 第三方「应用清单」缓存：默认只清 cache/ 下的，files/ 需 --force
  o ""
  o " 应用清单缓存（按文件名识别）："
  collect_applist
  if [ -s "$TMP/applist.tsv" ]; then
    while IFS='	' read -r f pkg kb; do
      case "$f" in
        */cache/*) do_rm "$f" ;;
        *)
          if [ "$FORCE" = 1 ]; then do_rm "$f"; else o "   [跳过·非 cache] $f （--force 才会删）"; fi
          ;;
      esac
    done < "$TMP/applist.tsv"
  else
    o "   （无）"
  fi
  o ""

  # 其他软件数据里的「安装记录」（内容级识别）
  o " 其他软件数据里的安装记录（内容级识别）："
  case "$APPDATA_MODE" in
    none) o "   [不处理] 需显式加 --appdata / --appdata=prefs / --appdata=db" ;;
    *)    ad_clean "$APPDATA_MODE" ;;
  esac
  o ""
}

# ------------------------------------------------------------ L4
l4_plan() {
  o "------------------------------------------------------------------"
  o " [L4] LSPosed 模块配置（删了 Xposed 模块的启用状态全部丢失）"
  o "------------------------------------------------------------------"
  do_rm_glob "/data/adb/lspd/config/modules_config.db"
  do_rm_glob "/data/adb/lspd/config/modules_config.db-wal"
  do_rm_glob "/data/adb/lspd/config/modules_config.db-shm"
  o ""
}

# ------------------------------------------------------------ verify
verify_main() {
  TMP=$DATADIR/tmp
  mkdir -p "$TMP"
  OUT="$OUTDIR/verify-$(ts_name).txt"
  : > "$OUT"

  pm list packages 2>/dev/null | "$BB" sed 's/^package://' | "$BB" sort > "$TMP/inst.txt"
  pm list packages -u 2>/dev/null | "$BB" sed 's/^package://' | "$BB" sort > "$TMP/instu.txt"
  "$BB" comm -23 "$TMP/instu.txt" "$TMP/inst.txt" > "$TMP/gone.txt"

  o "------------------------------------------------------------------"
  o " 清理后复核  $(ts_now)"
  o "------------------------------------------------------------------"
  o " 已安装            : $(wc -l < "$TMP/inst.txt" | tr -d ' ')"
  o " 已卸载(-u 差集)   : $(wc -l < "$TMP/gone.txt" | tr -d ' ')"
  o ""

  n=0
  while IFS= read -r p; do
    [ -z "$p" ] && continue
    for d in "/data/data/$p" "/data/user_de/0/$p" "/data/media/0/Android/data/$p"; do
      [ -e "$d" ] && { o " [仍存在] $d"; n=$((n + 1)); }
    done
  done < "$TMP/gone.txt"
  [ "$n" -eq 0 ] && o " [通过] 已卸载包的 data / Android-data 目录已无残留"

  o ""
  for p in /data/data/com.xiaomi.market/databases/market_2.db \
           /data/data/com.coolapk.market/databases/download.db \
           /data/system/notification_log.db \
           /data/system/app_idle_stats.xml; do
    if [ -e "$p" ]; then
      o " [存在] $p"
    else
      o " [已清] $p"
    fi
  done
  o ""

  for d in /data/system/usagestats/0/daily /data/system/netstats /data/system/procstats /data/system/dropbox; do
    if [ -d "$d" ]; then
      o " [$(printf '%s' "$d")] 剩余 $(ls "$d" 2>/dev/null | wc -l | tr -d ' ') 项"
    fi
  done
  o ""
  o " 提示：UsageStats / NetStats 由系统服务持有内存副本，重启后才会真正清空并重建。"
  o " 报告：$OUT"
}

# ------------------------------------------------------------ export
export_main() {
  TMP=$DATADIR/tmp
  DST=${1:-$OUTDIR/export}
  mkdir -p "$DST" || die "无法创建 $DST"
  o "------------------------------------------------------------------"
  o " 导出历史库（供 PC 端离线解析）"
  o "------------------------------------------------------------------"
  n=0
  for p in /data/data/com.xiaomi.market/databases/market_2.db \
           /data/data/com.xiaomi.market/databases/market_2.db-wal \
           /data/data/com.coolapk.market/databases/download.db \
           /data/data/com.coolapk.market/databases/download_database.db \
           /data/data/com.miui.securitycenter/databases/month_report.db \
           /data/data/com.miui.securitycenter/files/appmanager/appmanager_installer_pkg \
           /data/data/com.xiaomi.misettings/databases/screen-time-database \
           /data/adb/lspd/config/modules_config.db \
           /data/system/package-usage.list \
           /data/system/package-dex-usage.list \
           /data/system/appops.xml \
           /data/system/role.xml; do
    [ -e "$p" ] || continue
    b=$(printf '%s' "$p" | "$BB" sed 's|^/||; s|/|__|g')
    "$BB" cp -f "$p" "$DST/$b" 2>/dev/null && { o " [导出] $b"; n=$((n + 1)); }
  done
  o ""
  o " 共 $n 个文件 → $DST"
  o " 拉回电脑：adb pull $DST ./tc-export"
}
