#!/bin/sh
# ============================================================
# smsGateway 模块安装脚本（由 Magisk 安装器 source 执行）
#
# 只做三件事：设权限 / 建持久化目录 / 首次写入默认配置。
# ★★ 已存在的 config.conf **绝不覆盖** —— 里面有用户的 hub 地址、令牌、webhook。
#    升级时新增的配置键由 bin/smsd.sh 的 add_new_keys() 幂等补齐。
# ============================================================

ui_print "*******************************"
ui_print "   smsGateway 短信网关"
ui_print "*******************************"

SG=/data/adb/smsgateway

MBB=/data/adb/magisk/busybox
[ -x "$MBB" ] || MBB=busybox

set_perm_recursive $MODPATH 0 0 0755 0644
for f in action.sh customize.sh service.sh uninstall.sh bin/smsd.sh bin/ctl.sh bin/webui.sh webroot/cgi-bin/api; do
  [ -f "$MODPATH/$f" ] && set_perm "$MODPATH/$f" 0 0 0755
done
[ -f "$MODPATH/bin/mgsms.dex" ] && set_perm "$MODPATH/bin/mgsms.dex" 0 0 0644

mkdir -p $SG/log $SG/state $SG/run
chmod 0700 $SG $SG/log $SG/state $SG/run 2>/dev/null

if [ ! -f $SG/config.conf ]; then
  cp -f $MODPATH/bin/config.default $SG/config.conf
  set_perm $SG/config.conf 0 0 0600
  ui_print "- 已写入默认配置：$SG/config.conf"
  ui_print "- ★ 还需两步才能真正工作："
  ui_print "    1) 填 hub_url / hub_token（或 webhooks）"
  ui_print "    2) 重启手机（或手动跑 bin/smsd.sh）"
else
  ui_print "- 保留已有配置：$SG/config.conf（不会覆盖）"
fi

# dex 缺失时明确告警：没有它就完全不能收发
if [ ! -f "$MODPATH/bin/mgsms.dex" ]; then
  ui_print "!! 模块包里缺少 bin/mgsms.dex —— 收发短信功能不可用（打包脚本漏了 dex）"
fi

ui_print "- 数据目录: $SG"
ui_print "- 查看状态: su -c 'sh $MODPATH/bin/ctl.sh status'"
ui_print "- 配置文件: $SG/config.conf"
ui_print "- 手机端 WebUI: 点 Magisk 模块卡片上的「操作」按钮即可打开（action.sh）"

rm -rf "$MODPATH/源码"
rm -rf "$MODPATH/工具"
rm -rf "$MODPATH/.work"
