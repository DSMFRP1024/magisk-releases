#!/system/bin/sh
# ============================================================
# smsGateway 卸载脚本
#
# ★ 故意**不删** /data/adb/smsgateway：里面是用户的配置（hub 地址、令牌、
#   webhook）和 last_id。重装模块时直接沿用，不必重配。
#   要彻底清干净，手动 `rm -rf /data/adb/smsgateway`。
# ============================================================
export PATH=/data/adb/magisk:/system/bin:/system/xbin

BB=""
for _c in /data/adb/magisk/busybox /data/adb/ksu/bin/busybox /data/adb/ap/bin/busybox \
          /system/xbin/busybox /system/bin/busybox; do
  if [ -x "$_c" ]; then BB=$_c; break; fi
done
[ -n "$BB" ] || BB=busybox

$BB pkill -f "smsgateway/bin/smsd.sh" 2>/dev/null
# WebUI 的 httpd 也要收掉：按 webroot 路径匹配（端口是配置项，按端口杀会漏）
$BB pkill -f "[s]msgateway/webroot" 2>/dev/null
rm -f /data/adb/smsgateway/run/smsd.pid /data/adb/smsgateway/run/stop /data/adb/smsgateway/run/webui.hb
exit 0
