#!/system/bin/sh
# ============================================================
# Magisk 模块卡片上的「操作」按钮（Magisk 执行本文件并把输出显示在弹窗里）
#
#   点一下 = 确保手机端 WebUI 在跑 + 直接拉起浏览器
#
# ★★★ 为什么非要这个文件：Magisk 没有 KernelSU / APatch 那种
#   「webroot 一键打开」机制。模块界面上的入口**只有 action.sh** 这一条路
#   （Magisk 26+ 认 action.sh，卡片上才出现「操作」按钮）。
#   webroot/ 目录只是给 KSU/APatch 用的，装完 Magisk 里什么都不显示 ——
#   这就是之前"手机端 WebUI 明明做了却找不到入口"的真正原因。
#
# ★ 别加 set -e：任何一个步骤失败都要继续往下走，把兜底提示打出来，
#   否则按钮会只弹一个失败而不告诉你地址。
# ============================================================
export PATH=/data/adb/magisk:/system/bin:/system/xbin

# action.sh 由 Magisk 以模块目录为 cwd 执行，$0 是绝对路径；
# 但刷完还没重启时模块可能在 modules_update/ 下，两级都兜一下。
MODDIR=${0%/*}
[ -d "$MODDIR/bin" ] || MODDIR=/data/adb/modules/smsgateway
[ -d "$MODDIR/bin" ] || MODDIR=/data/adb/modules_update/smsgateway

echo "smsGateway 手机端 WebUI"
echo "--------------------------------"

# 1) 确保 httpd 在跑（已在跑就只刷新心跳，不会重复起进程）
sh "$MODDIR/bin/webui.sh" start

URL=$(sh "$MODDIR/bin/webui.sh" url 2>/dev/null)
case "$URL" in
  http*) ;;
  *) URL="http://127.0.0.1:8790/" ;;
esac
echo "地址: $URL"

# 2) 拉浏览器。root 直接 am start 在个别 ROM 上会被拒，失败再按 user 0 试一次。
_out=$(am start -a android.intent.action.VIEW -d "$URL" 2>&1)
case "$_out" in
  *Error* | *Exception* | *Permission*)
    am start --user 0 -a android.intent.action.VIEW -d "$URL" >/dev/null 2>&1 || true
    ;;
esac

# 3) 兜底提示：浏览器没弹出来也能照着敲
echo ""
echo "浏览器没自动弹出就手动打开上面的地址。"
echo "从电脑看：先 adb forward tcp:8790 tcp:8790，再开 http://127.0.0.1:8790/"
echo "关掉按钮：su -c 'sh $MODDIR/bin/webui.sh stop'"
