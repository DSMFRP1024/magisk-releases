#!/system/bin/sh
# ============================================================
# smsGateway 开机启动：等开机完成后拉起 bin/smsd.sh
#
# ★ 为什么要等 boot_completed：telephony provider 的库要等开机后才
#   会建好/可读，太早启动会得到「找不到 mmssms.db」，第一轮就记一条错误日志。
# ============================================================
MODDIR=${0%/*}
_sd=${0%/*}; [ "$_sd" = "$0" ] && _sd=.
MODDIR=$(cd "$_sd" 2>/dev/null && pwd) || MODDIR=$_sd

SG=/data/adb/smsgateway
export PATH=/data/adb/magisk:/system/bin:/system/xbin

BB=""
for _c in /data/adb/magisk/busybox /data/adb/ksu/bin/busybox /data/adb/ap/bin/busybox \
          /data/adb/modules/busybox-ndk/system/bin/busybox /system/xbin/busybox /system/bin/busybox; do
  if [ -x "$_c" ]; then BB=$_c; break; fi
done
[ -n "$BB" ] || BB=busybox

mkdir -p $SG/log $SG/state $SG/run
[ -f $SG/config.conf ] || cp -f $MODDIR/bin/config.default $SG/config.conf

(
  i=0
  while [ "$(getprop sys.boot_completed)" != "1" ] && [ $i -lt 150 ]; do
    $BB sleep 2
    i=$((i + 1))
  done
  # 再等一会儿：让 telephony provider 把库建好
  $BB sleep 8

  # 清残留实例（重启后旧 pid 文件没意义）
  $BB pkill -f "smsgateway/bin/smsd.sh" 2>/dev/null
  rm -f $SG/run/smsd.pid $SG/run/stop
  $BB sleep 1

  $BB sh $MODDIR/bin/smsd.sh >> $SG/log/smsd.out 2>&1 &

  # 手机端 WebUI（busybox httpd，仅 127.0.0.1）。webui=0 时不起。
  _w=$($BB grep -E '^webui=' $SG/config.conf 2>/dev/null | $BB tail -n 1 | $BB cut -d= -f2-)
  case "$_w" in
    0) : ;;
    *) $BB sh $MODDIR/bin/webui.sh start >> $SG/log/webui.log 2>&1 ;;
  esac
) &
