/* momGuard WebUI 前端（原 AutoKeep + AppGuard 两套前端合并为三页签）
   两种传输方式：
     - HTTP：由模块内置 busybox httpd 提供，走 /cgi-bin/api
     - 桥接：若被 KernelSU / WebUI X / 原生 WebUI 宿主打开，则直接执行 ctl.sh
*/
(function () {
  'use strict';

  var MODDIR = '/data/adb/modules/momguard';
  var BRIDGE = null;
  var TIMER = null;
  var REMAIN = 0;
  var TAB_KEY = 'momguard.tab';
  var TABS = ['keep', 'guard', 'usage', 'svc'];

  var VOLS = ['ring', 'music', 'alarm', 'notif', 'voice'];
  var VOL_LABEL = { ring: '铃声', music: '媒体', alarm: '闹钟', notif: '通知', voice: '通话' };

  /* 使用统计 / 时长管控的本地状态 */
  var PKGS = [];            // 已装第三方应用（成员选择器、单应用下拉用）
  var PKG_SIG = '';         // 上面这份列表的指纹，避免每 5 秒白重生一次下拉
  var LIMITS = [];          // 规则表本地副本 [{t:'app'|'group', n, m, a:[]}]
  var LIMITS_ACTION = 'home';
  var LIMIT_SIG = '';       // 最近一次由服务端应用过的规则指纹
  var LIMIT_DIRTY = false;  // 用户改过但还没保存，这期间轮询不许覆盖他的编辑
  var RULE_KIND = 'app';    // 新增规则的类型：app=单个应用 group=分组
  var MEMBER_SEL = {};      // 新建分组时勾选的成员
  var EDIT_INDEX = -1;      // >=0 表示正在编辑第几条已有规则（改完就地替换，不新增）
  var PASS = '';            // 访问密码的 SHA-256（只存内存，不写 cookie/localStorage，刷新即失）
  var AUTH_LOCK = false;    // true = 正卡在密码闸门，轮询暂时挂起

  /* 小程序管控（宿主 + 小程序名）的本地状态 */
  var MP_ITEMS = [];        // [{h:宿主, p:策略'-'|'allow'|'deny', c:分类, k:次数, n:名称}]
  var MP_SIG = '';          // 最近一次由服务端应用过的登记表指纹
  var MP_DIRTY = false;     // 用户改过但还没保存，这期间轮询不许覆盖
  var MP_FILTER = 'all';    // 列表筛选：all / shop / none
  var MP_DEFAULT = 'deny';  // 服务端下发的默认策略（deny=白名单 / allow=黑名单）
  var MP_ACTION = 'back';

  /* 微信网页（域名）管控的本地状态 */
  var WEB_ITEMS = [];       // [{d:域名, p:'allow'|'deny', n:显示名}]
  var WEB_DIRTY = false;    // 用户改过但还没保存，这期间轮询不许覆盖
  var WEB_SIG = '';         // 最近一次由服务端应用过的名单指纹

  /* 小程序宿主 / 分类的中文名。分类用于给列表打标，购物类单独区分（用户要求）。 */
  var MP_HOST = { wechat: '微信', alipay: '支付宝', bytedance: '头条/抖音',
                  baidu: '百度', quickapp: '系统快应用', other: '其它' };
  var MP_CAT = { shop: '购物', drama: '短剧', video: '视频', tool: '工具', other: '其它' };
  var MP_CAT_CLS = { shop: 'shop', drama: 'drama', video: 'video', tool: 'tool', other: '' };

  /* 桌面 / 系统组件不能被限额：它们不是「可玩的应用」。
     更实际的原因是处置动作默认就是「回桌面」—— 桌面本来就在前台，
     命中后按 HOME 还是桌面，下一轮又命中，手机就会一直在桌面上打转
     （真机实测：日志里每分钟一条 LIMIT，桌面无限自踢）。
     守护进程那边也有一层同样的豁免，这里是第一道，让用户根本选不到。 */
  var PKG_DENY = ['com.miui.home', 'com.miui.newhome', 'com.android.systemui',
                  'com.google.android.apps.nexuslauncher'];
  function pkgAllowed(p) {
    p = String(p || '');
    if (!p) return false;
    if (p.indexOf('launcher') >= 0) return false;
    for (var i = 0; i < PKG_DENY.length; i++) { if (p === PKG_DENY[i]) return false; }
    return true;
  }

  /* 包名 → 中文名。
     设备上没有能直接拿到应用显示名的命令（`pm list packages` 只有包名，
     `pm dump` 只给 labelRes 资源号，解析 APK 太重），所以内置一份常见应用的
     映射表：先精确匹配，再按前缀匹配，都没有就原样显示包名。
     想补充自己的应用，直接在这里加一行 ['包名前缀', '显示名'] 即可。 */
  var APPNAME = [
    ['com.tencent.mm', '微信'], ['com.tencent.wework', '企业微信'],
    ['com.tencent.mobileqq', 'QQ'], ['com.tencent.tim', 'TIM'], ['com.tencent.qqlite', 'QQ轻聊版'],
    ['com.tencent.qqlive', '腾讯视频'], ['com.tencent.qqmusic', 'QQ音乐'],
    ['com.tencent.news', '腾讯新闻'], ['com.tencent.mtt', 'QQ浏览器'],
    ['com.tencent.tmgp.sgame', '王者荣耀'], ['com.tencent.tmgp.pubgmhd', '和平精英'],
    ['com.tencent.tmgp', '腾讯游戏'], ['com.tencent.jkchess', '金铲铲之战'],
    ['com.tencent.ig', 'PUBG Mobile'], ['com.tencent.KiHan', '穿越火线'],
    ['com.tencent.weishi', '微视'], ['com.tencent.qqmail', 'QQ邮箱'],
    ['com.ss.android.article.news', '今日头条'], ['com.ss.android.article.lite', '头条极速版'],
    ['com.ss.android.article.video', '西瓜视频'], ['com.ss.android.ugc.aweme.lite', '抖音极速版'],
    ['com.ss.android.ugc.aweme', '抖音'], ['com.ss.android.ugc.live', '抖音火山版'],
    ['com.ss.android.auto', '懂车帝'], ['com.ss.android.medialearning', '开言英语'],
    ['com.dragon.read', '番茄免费小说'], ['com.phoenix.read', '番茄小说'],
    ['com.smile.gifmaker', '快手'], ['com.kuaishou.nebula', '快手极速版'],
    ['com.xingin.xhs', '小红书'], ['tv.danmaku.bili', '哔哩哔哩'],
    ['com.zhihu.android', '知乎'], ['com.sina.weibo', '微博'],
    ['com.eg.android.AlipayGphone', '支付宝'], ['com.antfortune.wealth', '蚂蚁财富'],
    ['com.taobao.taobao', '淘宝'], ['com.tmall.wireless', '天猫'],
    ['com.taobao.idlefish', '闲鱼'], ['com.jingdong.app.mall', '京东'],
    ['com.xunmeng.pinduoduo', '拼多多'], ['com.achievo.vipshop', '唯品会'],
    ['com.sankuai.meituan', '美团'], ['me.ele', '饿了么'],
    ['com.sdu.didi.psnger', '滴滴出行'], ['com.autonavi.minimap', '高德地图'],
    ['com.baidu.BaiduMap', '百度地图'], ['com.baidu.searchbox', '百度'],
    ['com.baidu.netdisk', '百度网盘'], ['com.netease.cloudmusic', '网易云音乐'],
    ['com.netease.newsreader.activity', '网易新闻'],
    ['com.qiyi.video', '爱奇艺'], ['com.youku.phone', '优酷'],
    ['com.hunantv.imgo.activity', '芒果TV'], ['com.ting.mp3.android', '喜马拉雅'],
    ['com.alibaba.android.rimet', '钉钉'], ['com.larus.nova', '豆包'],
    ['com.openai.chatgpt', 'ChatGPT'], ['com.microsoft.emmx', 'Edge'],
    ['com.android.chrome', 'Chrome'], ['com.quark.browser', '夸克'],
    ['com.UCMobile', 'UC浏览器'], ['com.qihoo.browser', '360浏览器'],
    ['com.unionpay', '云闪付'], ['com.icbc', '工商银行'],
    ['com.chinamworld.main', '建设银行'], ['com.hexin.plat.android', '同花顺'],
    ['com.xiaomi.smarthome', '米家'], ['com.miui.voiceassist', '小爱同学'],
    ['com.android.settings', '系统设置'], ['com.miui.home', '桌面'],
    ['com.miui.newhome', '桌面·负一屏'], ['com.android.systemui', '系统界面'],
    ['com.android.mms', '短信'], ['com.android.contacts', '联系人'],
    ['com.android.dialer', '拨号'], ['com.miui.gallery', '相册'],
    ['com.android.camera', '相机'], ['com.android.deskclock', '时钟'],
    ['com.miui.calculator', '计算器'], ['com.android.calendar', '日历'],
    ['com.miui.weather2', '天气'], ['com.xiaomi.market', '应用商店'],
    ['com.miui.video', '小米视频'], ['com.miui.player', '音乐'],
    ['com.miui.notes', '笔记'], ['com.miui.screenrecorder', '屏幕录制'],
    ['com.android.thememanager', '主题壁纸'], ['com.miui.securitycenter', '安全中心'],
    ['com.android.vending', 'Google Play'], ['com.google.android.youtube', 'YouTube'],
    ['com.topjohnwu.magisk', 'Magisk 管理器'], ['com.termux', 'Termux'],
    ['com.xiaomi.account', '小米帐号'], ['com.xiaomi.vipaccount', '小米社区'],
    ['com.aurora.cleanup', '垃圾清理'], ['com.milink.service', '小米互传'],
    ['cn.wps.moffice', 'WPS Office'], ['com.microsoft.office', 'Office'],
    ['com.youdao.dict', '有道词典'], ['com.sohu.inputmethod.sogou', '搜狗输入法']
  ];

  function appName(pkg) {
    var exact = '', pref = '';
    for (var i = 0; i < APPNAME.length; i++) {
      if (pkg === APPNAME[i][0]) { exact = APPNAME[i][1]; break; }
      if (!pref && pkg.indexOf(APPNAME[i][0]) === 0) pref = APPNAME[i][1];
    }
    return exact || pref || '';
  }

  /* Android 待机桶：5=豁免（最优）10=活跃 20=常用 30=较常用 40=很少用 45=受限 50=从不 */
  function bucketName(b) {
    var M = { '5': '已豁免', '10': '活跃', '20': '常用', '30': '较常用', '40': '很少用', '45': '受限', '50': '从不' };
    return M[String(b)] || (b ? ('#' + b) : '');
  }

  function $(s) { return document.querySelector(s); }
  function byId(s) { return document.getElementById(s); }

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (m) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m];
    });
  }

  /* ---------- 访问密码（SHA-256，纯 JS 实现）----------
     为什么不用 crypto.subtle：WebUI 常被宿主 WebView 以 file:// / 非安全源打开，
     subtle 只在安全上下文（https / localhost）可用，桥接模式下多半是 undefined。
     为什么手机上只存哈希：密码的 SHA-256 由浏览器算好后随请求带上，
     config.conf 里从头到尾不出现明文。 */

  function utf8bytes(str) {
    var out = [], i, c;
    for (i = 0; i < str.length; i++) {
      c = str.codePointAt(i);
      if (c > 0xffff) i++;                       // 代理对整体消费
      if (c < 0x80) out.push(c);
      else if (c < 0x800) out.push(0xc0 | (c >> 6), 0x80 | (c & 63));
      else if (c < 0x10000) out.push(0xe0 | (c >> 12), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63));
      else out.push(0xf0 | (c >> 18), 0x80 | ((c >> 12) & 63), 0x80 | ((c >> 6) & 63), 0x80 | (c & 63));
    }
    return out;
  }

  function rotr(x, n) { return (x >>> n) | (x << (32 - n)); }

  var SHA256_K = [
    0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2
  ];

  function sha256hex(text) {
    var bytes = utf8bytes(String(text)), H = [
      0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a,
      0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19
    ], w = new Array(64), i, j;
    var len = bytes.length;
    bytes.push(0x80);
    while (bytes.length % 64 !== 56) bytes.push(0);
    var hi = Math.floor(len / 0x20000000), lo = (len << 3) >>> 0;
    bytes.push((hi >>> 24) & 255, (hi >>> 16) & 255, (hi >>> 8) & 255, hi & 255,
               (lo >>> 24) & 255, (lo >>> 16) & 255, (lo >>> 8) & 255, lo & 255);

    for (i = 0; i < bytes.length; i += 64) {
      for (j = 0; j < 16; j++) {
        w[j] = ((bytes[i + 4 * j] << 24) | (bytes[i + 4 * j + 1] << 16) |
                (bytes[i + 4 * j + 2] << 8) | bytes[i + 4 * j + 3]) | 0;
      }
      for (j = 16; j < 64; j++) {
        var s0 = rotr(w[j - 15], 7) ^ rotr(w[j - 15], 18) ^ (w[j - 15] >>> 3);
        var s1 = rotr(w[j - 2], 17) ^ rotr(w[j - 2], 19) ^ (w[j - 2] >>> 10);
        w[j] = (w[j - 16] + s0 + w[j - 7] + s1) | 0;
      }
      var a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
      for (j = 0; j < 64; j++) {
        var S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
        var ch = (e & f) ^ (~e & g);
        var t1 = (h + S1 + ch + SHA256_K[j] + w[j]) | 0;
        var S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
        var maj = (a & b) ^ (a & c) ^ (b & c);
        var t2 = (S0 + maj) | 0;
        h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
      }
      H[0] = (H[0] + a) | 0; H[1] = (H[1] + b) | 0; H[2] = (H[2] + c) | 0; H[3] = (H[3] + d) | 0;
      H[4] = (H[4] + e) | 0; H[5] = (H[5] + f) | 0; H[6] = (H[6] + g) | 0; H[7] = (H[7] + h) | 0;
    }
    var out = '';
    for (i = 0; i < 8; i++) out += ('00000000' + ((H[i] >>> 0).toString(16))).slice(-8);
    return out;
  }

  /* ---------- 传输层 ---------- */
  function detectBridge() {
    try {
      if (window.ksu && typeof window.ksu.exec === 'function') return 'ksu';
      if (window.webui && typeof window.webui.exec === 'function') return 'webui';
      if (window.magisk && typeof window.magisk.exec === 'function') return 'magisk';
    } catch (e) { /* ignore */ }
    return null;
  }

  function shellRun(cmd) {
    var host = BRIDGE === 'webui' ? window.webui : (BRIDGE === 'ksu' ? window.ksu : window.magisk);
    return Promise.resolve(host.exec(cmd)).catch(function () { return null; }).then(function (r) {
      if (r == null) return '';
      if (typeof r === 'string') return r;
      if (typeof r.stdout === 'string') return r.stdout;
      return String(r);
    });
  }

  function api(cmd, key, value) {
    if (BRIDGE) {
      /* 桥接模式同样要过密码闸门：auth-wrap 先核对哈希再分发（不认 cookie，
         每次调用都带；PASS 只在内存里，页面刷新后必须重新输入） */
      var c = 'sh ' + MODDIR + '/bin/ctl.sh auth-wrap ' + PASS + ' ' + cmd;
      if (key) c += ' ' + key;
      if (value != null) c += ' ' + value;
      return shellRun(c).then(function (out) {
        var m = String(out).match(/\{[\s\S]*\}/);
        try { return JSON.parse(m ? m[0] : out); } catch (e) { return { ok: false, msg: '输出解析失败' }; }
      });
    }
    var p = new URLSearchParams({ cmd: cmd });
    if (key) p.set('key', key);
    if (value != null) p.set('value', value);
    p.set('p', PASS);
    return fetch('/cgi-bin/api?' + p.toString(), { cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .catch(function () { return { ok: false, msg: '无法连接模块服务' }; });
  }

  /* POST 原始请求体（不走 multipart）：
     - APK 上传：body 直接是 File 对象，只有 xhr 才拿得到进度事件
     - 规则表：body 是一小段纯文本（分组名是中文，走 GET 会被 cgi 的字符过滤吃掉）
     只有经 127.0.0.1 的 HTTP 通道支持；宿主桥接（KSU / WebUI X）下没有这条链路。 */
  function postRaw(url, body, onProgress) {
    return new Promise(function (resolve, reject) {
      if (BRIDGE) { reject(new Error('宿主桥接模式不支持，请用浏览器打开 127.0.0.1 页面')); return; }
      url += (url.indexOf('?') >= 0 ? '&' : '?') + 'p=' + PASS;   // 密码闸门：POST 也要带
      var x = new XMLHttpRequest();
      x.open('POST', url, true);
      x.setRequestHeader('Content-Type', 'application/octet-stream');
      if (onProgress && x.upload) {
        x.upload.onprogress = function (e) {
          if (e.lengthComputable) onProgress(e.loaded / e.total);
        };
      }
      x.onload = function () {
        var d = null;
        try { d = JSON.parse(x.responseText); } catch (e) { d = null; }
        if (d) resolve(d);
        else reject(new Error('服务返回异常（HTTP ' + x.status + '）'));
      };
      x.onerror = function () { reject(new Error('网络中断，传输失败')); };
      x.send(body);
    });
  }

  /* ---------- 提示 ---------- */
  var toastTimer = null;
  function toast(msg) {
    var t = byId('toast');
    if (!t) return;
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.remove('show'); }, 1900);
  }

  /* ---------- 访问密码闸门 ----------
     进入页面第一件事就是用 api('json') 探测：手机上设了密码而请求没带对
     （或没带），服务端回 {"ok":false,"auth":1}，这里弹全屏闸门拦住页面。
     密码哈希只放在 JS 变量里 —— 不写 cookie、不写 localStorage，
     「不认 cookie」是双向的：服务端不认，前端也不留。 */
  function showGate(msg) {
    AUTH_LOCK = true;
    var g = byId('gate');
    if (!g) return;
    var m = byId('gate_msg');
    if (m) m.textContent = msg || '';
    g.classList.add('show');
    setTimeout(function () { var i = byId('gate_pass'); if (i) i.focus(); }, 60);
  }

  function hideGate() {
    AUTH_LOCK = false;
    var g = byId('gate');
    if (g) g.classList.remove('show');
    var i = byId('gate_pass');
    if (i) i.value = '';
  }

  function tryGate() {
    var inp = byId('gate_pass');
    var v = String((inp && inp.value) || '');
    if (!v) { var m = byId('gate_msg'); if (m) m.textContent = '请输入访问密码'; return; }
    PASS = sha256hex(v);
    api('json').then(function (d) {
      if (d && d.ok !== false && d.auth !== 1) {
        hideGate();
        toast('已进入控制台');
        refresh();
        loadAdbkey();
      } else {
        PASS = '';
        var m = byId('gate_msg');
        if (m) m.textContent = '密码不对，再试一次';
      }
    });
  }

  /* 复制文本到剪贴板：clipboard API 需要安全上下文（127.0.0.1 满足，
     宿主 WebView 不一定），失败降级 execCommand */
  function legacyCopy(text) {
    try {
      var ta = document.createElement('textarea');
      ta.value = text;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      var ok = document.execCommand('copy');
      document.body.removeChild(ta);
      return ok;
    } catch (e) { return false; }
  }

  function copyText(text, okMsg) {
    if (!text) { toast('还没有内容可复制'); return; }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(
        function () { toast(okMsg || '已复制到剪贴板'); },
        function () { if (legacyCopy(text)) toast(okMsg || '已复制到剪贴板'); else toast('复制失败，请手动选择复制'); });
    } else if (legacyCopy(text)) {
      toast(okMsg || '已复制到剪贴板');
    } else {
      toast('复制失败，请手动选择复制');
    }
  }

  /* ---------- 内置 adb 白名单公钥（复制 / 下载） ---------- */
  var ADBKEY_TXT = '';
  var ADBKEY_NOTE = '';
  var S_ADBKEY_IN = false;   // 内置公钥是否已并入系统 adb_keys（来自 json 的 status）

  function apiRaw(cmd) {
    if (BRIDGE) return shellRun('cat ' + MODDIR + '/bin/adbkey.pub');
    return fetch('/cgi-bin/api?cmd=' + cmd + '&p=' + PASS, { cache: 'no-store' })
      .then(function (r) { return r.text(); })
      .catch(function () { return ''; })
      .then(function (txt) {
        /* 闸门没过时服务端回的是 JSON 错误体，不能当成公钥文本 */
        if (String(txt || '').trim().charAt(0) === '{') return '';
        return txt;
      });
  }

  function loadAdbkey() {
    apiRaw('adbkey').then(function (txt) {
      ADBKEY_TXT = String(txt || '').replace(/\s+$/, '');
      var parts = ADBKEY_TXT.split(/\s+/);
      ADBKEY_NOTE = parts.length > 1 ? parts[parts.length - 1] : '';
      renderAdbkey();
    });
  }

  function renderAdbkey() {
    var d = byId('d_adbkey');
    if (!d) return;
    if (!ADBKEY_TXT) { d.textContent = '模块里没有内置公钥（bin/adbkey.pub 缺失）'; return; }
    d.innerHTML = '<b>' + esc(ADBKEY_TXT.slice(0, 14)) + '…</b>' +
      (ADBKEY_NOTE ? ' · ' + esc(ADBKEY_NOTE) : '') +
      '<br>已并入系统授权：' + (S_ADBKEY_IN ? '是' : '否（重启后生效）');
  }

  function downloadAdbkey() {
    if (!ADBKEY_TXT) { toast('还没有读到公钥'); return; }
    var blob = new Blob([ADBKEY_TXT], { type: 'application/octet-stream' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'momguard-adbkey.pub';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(a.href); }, 3000);
  }


  /* ---------- 页签 ---------- */
  function showTab(name) {
    if (TABS.indexOf(name) < 0) name = 'keep';
    Array.prototype.forEach.call(document.querySelectorAll('#tabs .tab'), function (b) {
      b.classList.toggle('on', b.getAttribute('data-tab') === name);
    });
    TABS.forEach(function (n) {
      var p = byId('panel_' + n);
      if (!p) return;
      if (n === name) p.removeAttribute('hidden');
      else p.setAttribute('hidden', '');
    });
    try { localStorage.setItem(TAB_KEY, name); } catch (e) { /* 隐私模式下忽略 */ }
    window.scrollTo(0, 0);
  }

  function initTabs() {
    Array.prototype.forEach.call(document.querySelectorAll('#tabs .tab'), function (b) {
      b.addEventListener('click', function () { showTab(b.getAttribute('data-tab')); });
    });
    var want = 'keep';
    try { var s = localStorage.getItem(TAB_KEY); if (s) want = s; } catch (e) { /* ignore */ }
    var m = String(location.search).match(/[?&]tab=([a-z]+)/);
    if (m) want = m[1];
    showTab(want);
  }

  /* ---------- 渲染 ---------- */
  function setSwitch(el, on) {
    if (!el) return;
    el.classList.toggle('on', !!on);
    el.setAttribute('aria-checked', on ? 'true' : 'false');
  }

  function setSubsDisabled(sel, off) {
    var box = $(sel);
    if (!box) return;
    Array.prototype.forEach.call(box.querySelectorAll('.row'), function (r) {
      if (off) r.setAttribute('disabled', '');
      else r.removeAttribute('disabled');
    });
  }

  function pill(cls, text) { return '<span class="pill ' + cls + '">' + esc(text) + '</span>'; }

  function fmtSec(s) {
    s = parseInt(s, 10) || 0;
    if (s <= 0) return '—';
    var m = Math.floor(s / 60), r = s % 60;
    return m + ' 分 ' + (r < 10 ? '0' + r : r) + ' 秒';
  }

  function fmtTime(ts) {
    var n = parseInt(ts, 10);
    if (!n) return '—';
    var dt = new Date(n * 1000);
    var z = function (x) { return x < 10 ? '0' + x : '' + x; };
    return dt.getFullYear() + '-' + z(dt.getMonth() + 1) + '-' + z(dt.getDate()) +
      ' ' + z(dt.getHours()) + ':' + z(dt.getMinutes());
  }

  /* 秒 → 紧凑时长（表格里只占一列，越短越好） */
  function fmtDur(sec) {
    sec = parseInt(sec, 10) || 0;
    if (sec <= 0) return '0 分';
    if (sec >= 3600) {
      var h = Math.floor(sec / 3600), m = Math.round((sec % 3600) / 60);
      return h + ' 时' + (m ? ' ' + m + ' 分' : '');
    }
    if (sec >= 60) return Math.floor(sec / 60) + ' 分';
    return sec + ' 秒';
  }

  function fmtSize(n) {
    n = parseInt(n, 10) || 0;
    if (n >= 1048576) return (n / 1048576).toFixed(1) + ' MiB';
    if (n >= 1024) return (n / 1024).toFixed(0) + ' KiB';
    return n + ' B';
  }

  /* 本地时钟 hh:mm:ss —— 保存回执里带上，好让用户确认「这次点的真的生效了」 */
  function hmNow() {
    var d = new Date(), z = function (x) { return x < 10 ? '0' + x : '' + x; };
    return z(d.getHours()) + ':' + z(d.getMinutes()) + ':' + z(d.getSeconds());
  }

  /* 前台组件名 → 可读文案：com.tencent.mm/.ui.LauncherUI → 微信（com.tencent.mm） */
  function appLabel(comp) {
    var pkg = String(comp || '').split('/')[0];
    if (!pkg) return '—';
    var nm = appName(pkg);
    return nm ? (nm + '（' + pkg + '）') : pkg;
  }

  function renderLogs(list) {
    var box = byId('logs');
    if (!box) return;
    if (!list || !list.length) {
      box.innerHTML = '<div class="empty">暂无记录</div>';
      return;
    }
    var html = '';
    for (var i = list.length - 1; i >= 0; i--) {
      var q = String(list[i]).split('|');
      var tm = q[0] || '', kd = q[1] || '', det = q[2] || '', comp = q[3] || '';
      html += '<div class="log"><span class="k ' + esc(kd) + '">' + esc(kd) + '</span>' +
        '<div class="b"><div class="t">' + esc(det) + '</div>' +
        '<div class="m">' + esc(tm) + (comp ? ' · ' + esc(comp) : '') + '</div></div></div>';
    }
    box.innerHTML = html;
  }

  /* ================= 今日使用时长 ================= */
  /* 命中某个包的「最严规则」：分组与单应用同时命中取更小的那条，
     与 guard.sh 的 limit_for() 完全同一套语义，界面上的高亮才不会跟实际处置打架。
     返回 {m:分钟, scope:[参与合计的包名]}；scope 为空数组＝单应用规则（只算它自己），
     非空＝分组规则（用量按组内合计算，整组一起算超时）。 */
  function bestRuleFor(pkg) {
    var best = null;
    LIMITS.forEach(function (r) {
      var v = parseInt(r.m, 10) || 0;
      if (v < 1) return;
      var hit = (r.t === 'app') ? (r.n === pkg) : ((r.a || []).indexOf(pkg) >= 0);
      if (!hit) return;
      if (!best || v < best.m) {
        best = { m: v, scope: (r.t === 'group') ? (r.a || []).slice() : [] };
      }
    });
    return best;
  }

  /* ---------- 使用时长：今天 / 历史 ----------
     USAGE_DAY='' 表示看今天（走正常的 5 秒刷新）；否则是某个历史归档日期，
     此时由本页自己拉一次数据渲染，并**不再自动刷新**（历史不会变）。
     历史视图下**不按今天的限额判超时** —— 那会显示成「已超时」，是误导。 */
  var USAGE_DAY = '';
  var USAGE_TODAY = '';

  function renderUsage(u, hist) {
    var box = byId('usage_list');
    if (!box) return;
    u = u || {};
    var apps = u.apps || [];
    var total = 0, maxSec = 1;
    var secOf = {};                       // 包名 -> 当日秒数（分组求合计时要用）
    apps.forEach(function (a) {
      var s = parseInt(a.s, 10) || 0;
      secOf[a.p || ''] = s;
      total += s;
      if (s > maxSec) maxSec = s;
    });

    var src = u.src === 'sys' ? 'sys' : 'mg';
    var srcTxt = src === 'sys' ? '系统使用记录（导入）' : '守护进程实时观测';

    var info = byId('usage_info');
    if (info) {
      info.textContent = apps.length
        ? ('统计时间 ' + (u.hm || '—') + ' · ' + (u.day || '') +
           ' · 来源 ' + srcTxt + ' · ' + apps.length +
           ' 个应用 · 合计 ' + fmtDur(total))
        : '这一天没有记录。';
    }
    var tag = byId('tag_usage');
    if (tag) tag.textContent = (u.day || '—') + (apps.length ? ' · ' + apps.length + ' 个' : '');

    var note = byId('usage_src_note');
    if (note) {
      note.textContent = hist
        ? ('历史 ' + (u.day || '') + '（' + srcTxt + '）· 不参与今日限额判定')
        : '今天 · 守护进程实时统计';
    }

    if (!apps.length) { box.innerHTML = '<div class="empty">暂无记录</div>'; return; }

    var html = '';
    apps.forEach(function (a) {
      var pkg = a.p || '';
      var sec = parseInt(a.s, 10) || 0;
      var rule = hist ? null : bestRuleFor(pkg);   // 历史不按今天的规则判超时
      var cap = rule ? rule.m : 0;                 // 分钟
      var grouped = !!(rule && rule.scope.length);
      var used = sec;                              // 判超时用的用量
      if (grouped) {
        used = 0;
        rule.scope.forEach(function (p) { used += secOf[p] || 0; });
      }
      var over = !hist && cap > 0 && used >= cap * 60;
      var pct = cap > 0 ? Math.min(100, used / (cap * 60) * 100) : (sec / maxSec * 100);
      var nm = appName(pkg);
      var sub = nm ? pkg : '';
      if (grouped) {
        // 分组规则：这一条的超时是按**整组合计**算的，标出来免得用户以为是单个应用的时长
        sub = (sub ? sub + ' · ' : '') + '分组合计 ' + fmtDur(used) + ' / ' + cap + ' 分';
      }
      html += '<div class="urow' + (over ? ' over' : '') + '">' +
        '<div class="nm"><div class="n">' + esc(nm || pkg) +
        (over ? ' · 已超时' : '') + (grouped ? ' · 分组' : '') + '</div>' +
        (sub ? '<div class="p">' + esc(sub) + '</div>' : '') + '</div>' +
        '<div class="bar' + (over ? ' over' : '') + '"><i style="width:' + pct.toFixed(0) + '%"></i></div>' +
        '<div class="sec">' + esc(fmtDur(sec)) + '</div></div>';
    });
    box.innerHTML = html;
  }

  /* 拉日期列表填进下拉：今天 + 所有归档（后端已按日期倒序排好） */
  function loadUsageDays() {
    var sel = byId('usage_daysel');
    if (!sel) return;
    api('usage-days').then(function (r) {
      if (!r || r.ok === false) return;
      USAGE_TODAY = r.today || USAGE_TODAY;
      var days = r.days || [];
      var html = '';
      days.forEach(function (d) {
        var lbl = (d.d === USAGE_TODAY) ? ('今天（' + d.d + '）') : d.d;
        if (d.src === 'sys') lbl += ' · 系统记录';
        html += '<option value="' + esc(d.d) + '">' + esc(lbl) + '</option>';
      });
      if (!html && USAGE_TODAY) {
        html = '<option value="' + esc(USAGE_TODAY) + '">今天（' + esc(USAGE_TODAY) + '）</option>';
      }
      sel.innerHTML = html;
      if (USAGE_DAY) sel.value = USAGE_DAY;
      else if (USAGE_TODAY) sel.value = USAGE_TODAY;
    });
  }

  /* 切到某个历史日期：自己拉一次并渲染，之后不再跟着 5 秒轮询刷新 */
  function showUsageDay(v) {
    USAGE_DAY = v;
    api('usage-day', v).then(function (r) {
      if (!r || r.ok === false) {
        toast((r && r.msg) || '读取失败');
        USAGE_DAY = '';
        var sel = byId('usage_daysel');
        if (sel) sel.value = USAGE_TODAY;
        refresh();
        return;
      }
      renderUsage(r.usage, true);
    });
  }

  /* ================= 时长管控：规则编辑器 ================= */
  function limitRowHtml(r, i) {
    var isG = r.t === 'group';
    var name, sub = '';
    if (isG) {
      name = r.n || '未命名';
      var mem = (r.a || []).map(function (p) { return appName(p) || p; });
      sub = mem.length
        ? ('成员：' + mem.slice(0, 6).join('、') + (mem.length > 6 ? ' 等 ' + mem.length + ' 个' : ''))
        : '（没有成员，这条不会生效）';
      var bad = (r.a || []).filter(function (p) { return !pkgAllowed(p); }).length;
      if (bad) sub += '；其中 ' + bad + ' 个是桌面/系统组件，会被忽略';
    } else {
      name = appName(r.n) || r.n;
      sub = appName(r.n) ? r.n : '';
      if (!pkgAllowed(r.n)) {
        name = '⚠️ ' + name;
        sub = (sub ? sub + ' · ' : '') + '桌面/系统组件，守护进程会跳过，建议删除';
      }
    }
    return '<div class="lrule' + (i === EDIT_INDEX ? ' editing' : '') + '" data-i="' + i + '">' +
      '<span class="bd' + (isG ? ' g' : '') + '">' + (isG ? '分组' : '应用') + '</span>' +
      '<div class="nm"><div class="n">' + esc(name) + '</div>' +
      (sub ? '<div class="p">' + esc(sub) + '</div>' : '') + '</div>' +
      '<input class="num" type="number" min="0" max="1440" inputmode="numeric" value="' + (r.m || 0) +
      '" data-role="min" aria-label="每日上限分钟">' +
      '<button class="edit" data-role="edit" aria-label="编辑这条规则">编辑</button>' +
      '<button class="del" data-role="del" aria-label="删除这条规则">×</button>' +
      '</div>';
  }

  function renderLimitRows() {
    var box = byId('limits_list');
    if (!box) return;
    if (EDIT_INDEX >= LIMITS.length) EDIT_INDEX = -1;   // 被编辑的那条没了（删掉/重读）→ 退出编辑态
    if (!LIMITS.length) {
      box.innerHTML = '<div class="empty">还没有规则，用下面「新增一条规则」添加</div>';
      updateEditUi();
      return;
    }
    var html = '';
    LIMITS.forEach(function (r, i) { html += limitRowHtml(r, i); });
    box.innerHTML = html;
    updateEditUi();
  }

  function updateLimitTag() {
    var tag = byId('tag_limit');
    if (tag) tag.textContent = LIMITS.length ? (LIMITS.length + ' 条规则') : '未设定';
  }

  /* 保存前把输入框里的值收回本地模型（用户可能没 blur 就点了保存） */
  function syncLimitInputs() {
    Array.prototype.forEach.call(document.querySelectorAll('#limits_list .lrule'), function (row) {
      var i = parseInt(row.getAttribute('data-i'), 10);
      var inp = row.querySelector('[data-role="min"]');
      if (i < 0 || !inp || !LIMITS[i]) return;
      var v = parseInt(inp.value, 10);
      if (isNaN(v) || v < 0) v = 0;
      if (v > 1440) v = 1440;
      LIMITS[i].m = v;
    });
  }

  function fillPkgSelect() {
    var sel = byId('rule_app');
    if (!sel) return;
    var cur = sel.value;
    var html = '', n = 0;
    PKGS.forEach(function (p) {
      if (!pkgAllowed(p)) return;            // 桌面/系统组件不给选
      n++;
      var nm = appName(p);
      html += '<option value="' + esc(p) + '">' + esc(nm ? (nm + '（' + p + '）') : p) + '</option>';
    });
    if (!n) html = '<option value="">（还没取到可用应用，稍后自动出现）</option>';
    sel.innerHTML = html;
    if (cur) { try { sel.value = cur; } catch (e) { /* 选项已不存在，忽略 */ } }
  }

  function renderMemberList() {
    var box = byId('rule_group_members');
    if (!box) return;
    var fe = byId('rule_group_filter');
    var q = String((fe && fe.value) || '').trim().toLowerCase();
    var html = '', n = 0;
    PKGS.forEach(function (p) {
      if (!pkgAllowed(p)) return;            // 桌面/系统组件不进成员列表
      var nm = appName(p);
      var hit = !q || (p.toLowerCase().indexOf(q) >= 0) ||
                (nm && nm.toLowerCase().indexOf(q) >= 0);
      if (!hit || n >= 250) return;
      n++;
      html += '<label class="pickrow">' +
        '<input type="checkbox" data-pkg="' + esc(p) + '"' + (MEMBER_SEL[p] ? ' checked' : '') + '>' +
        '<span class="n">' + esc(nm || p) + '</span>' +
        (nm ? '<span class="p">' + esc(p) + '</span>' : '') + '</label>';
    });
    box.innerHTML = html || '<div class="empty">没有匹配的应用</div>';
  }

  function setRuleKind(k) {
    RULE_KIND = (k === 'group') ? 'group' : 'app';
    var seg = byId('seg_rule_kind');
    if (seg) Array.prototype.forEach.call(seg.querySelectorAll('button'), function (b) {
      b.classList.toggle('on', b.getAttribute('data-v') === RULE_KIND);
    });
    var ab = byId('rule_app_box'), gb = byId('rule_group_box');
    if (ab) { if (RULE_KIND === 'app') ab.removeAttribute('hidden'); else ab.setAttribute('hidden', ''); }
    if (gb) { if (RULE_KIND === 'group') gb.removeAttribute('hidden'); else gb.setAttribute('hidden', ''); }
  }

  function renderLimitAction() {
    var seg = byId('seg_limit_action');
    if (!seg) return;
    Array.prototype.forEach.call(seg.querySelectorAll('button'), function (b) {
      b.classList.toggle('on', b.getAttribute('data-v') === LIMITS_ACTION);
    });
  }

  /* ---- 编辑已有规则（含分组）----
     规则行只有一个「分钟」输入框可以直接改；要改**分组的成员或名字**就必须把
     整条规则回填到下面的表单里。旧版没有这个入口，已经建好的分组就只能删掉重加，
     这正是用户反馈的「不能编辑已经配置过的分组」。 */
  function updateEditUi() {
    var add = byId('btn_rule_add');
    var can = byId('btn_rule_cancel');
    var editing = EDIT_INDEX >= 0 && !!LIMITS[EDIT_INDEX];
    if (add) add.textContent = editing ? '保存修改' : '添加';
    if (can) can.style.display = editing ? '' : 'none';
    var lab = byId('rule_add_title');
    if (lab) {
      lab.textContent = editing
        ? ('正在编辑第 ' + (EDIT_INDEX + 1) + ' 条规则 —— 改完点「保存修改」，或点「取消编辑」')
        : '新增一条规则';
    }
    var rows = document.querySelectorAll('#limits_list .lrule');
    Array.prototype.forEach.call(rows, function (row) {
      var i = parseInt(row.getAttribute('data-i'), 10);
      row.classList.toggle('editing', editing && i === EDIT_INDEX);
    });
  }

  /* 把第 i 条规则（含分组成员）回填到编辑表单，之后「保存修改」会就地替换 */
  function startEdit(i) {
    var r = LIMITS[i];
    if (!r) return;
    syncLimitInputs();                       // 先把别的行改过的分钟收回本地模型
    EDIT_INDEX = i;
    var ne = byId('rule_group_name'), gf = byId('rule_group_filter'), sel = byId('rule_app');
    if (r.t === 'group') {
      setRuleKind('group');
      if (ne) ne.value = r.n || '';
      if (gf) gf.value = '';
      MEMBER_SEL = {};
      (r.a || []).forEach(function (p) { MEMBER_SEL[p] = true; });
      renderMemberList();
    } else {
      setRuleKind('app');
      if (sel) { fillPkgSelect(); try { sel.value = r.n; } catch (e) { /* 该包已不在列表里 */ } }
    }
    var me = byId('rule_minutes');
    if (me) me.value = (parseInt(r.m, 10) || 0);
    updateEditUi();
    var ed = byId('limit_editor');
    if (ed && ed.scrollIntoView) ed.scrollIntoView({ block: 'nearest' });
    toast('正在编辑第 ' + (i + 1) + ' 条，改完点「保存修改」');
  }

  /* 退出编辑态并把表单清回「新增」的样子 */
  function cancelEdit() {
    EDIT_INDEX = -1;
    setRuleKind('app');
    fillPkgSelect();
    var ne = byId('rule_group_name'); if (ne) ne.value = '';
    var gf = byId('rule_group_filter'); if (gf) gf.value = '';
    var me = byId('rule_minutes'); if (me) me.value = 60;
    MEMBER_SEL = {};
    renderMemberList();
    updateEditUi();
  }

  function renderLimits(L) {
    L = L || {};

    /* 第三方应用列表：指纹变了才重画（重画会重置下拉与勾选，没必要每 5 秒来一次） */
    var psig = (L.pkgs || []).join(',');
    if (psig !== PKG_SIG) {
      PKG_SIG = psig;
      PKGS = L.pkgs || [];
      fillPkgSelect();
      renderMemberList();
    }

    /* 处置方式与编辑状态无关，永远跟随服务端 */
    LIMITS_ACTION = L.action || 'home';
    renderLimitAction();

    /* 规则列表：用户改过还没保存时不覆盖，免得每 5 秒把编辑冲掉 */
    if (LIMIT_DIRTY) return;
    var lsig = JSON.stringify(L.items || []) + '|' + (L.action || '');
    if (lsig === LIMIT_SIG) return;
    LIMIT_SIG = lsig;
    LIMITS = (L.items || []).map(function (it) {
      return { t: it.t, n: it.n, m: parseInt(it.m, 10) || 0, a: (it.a || []).slice() };
    });
    renderLimitRows();
    updateLimitTag();
  }

  function addRule() {
    syncLimitInputs();
    var me = byId('rule_minutes');
    var m = parseInt(me && me.value, 10);
    if (isNaN(m) || m < 0) { toast('每日上限请填 0–1440 的整数'); return; }
    if (m > 1440) m = 1440;

    var rule;
    if (RULE_KIND === 'group') {
      var ne = byId('rule_group_name');
      /* 单引号也要去掉：宿主桥接模式是把整张规则表作为一个单引号字符串
         交给 shell 的，名字里带单引号会把引用截断 */
      var gname = String((ne && ne.value) || '').trim().replace(/[|'\r\n]/g, '');
      if (!gname) { toast('请先填一个分组名'); return; }
      var mem = Object.keys(MEMBER_SEL).filter(function (k) { return MEMBER_SEL[k]; });
      if (!mem.length) { toast('请至少勾选一个成员应用'); return; }
      rule = { t: 'group', n: gname, m: m, a: mem };
    } else {
      var sel = byId('rule_app');
      var p = sel && sel.value;
      if (!p) { toast('请先在下拉里选择一个应用'); return; }
      rule = { t: 'app', n: p, m: m, a: [] };
    }

    /* 正在编辑某一条时就**就地替换**它（改名、换成员、改上限都算「编辑」），
       否则追加为新规则。 */
    var wasEdit = EDIT_INDEX >= 0 && !!LIMITS[EDIT_INDEX];
    var at = EDIT_INDEX;
    if (wasEdit) LIMITS[at] = rule; else LIMITS.push(rule);

    LIMIT_DIRTY = true;
    EDIT_INDEX = -1;
    renderLimitRows();
    updateLimitTag();
    cancelEdit();                                   // 表单复位成「新增」
    toast(wasEdit ? ('已更新第 ' + (at + 1) + ' 条，记得点「保存全部规则」')
                  : '已添加，记得点「保存全部规则」');
  }

  /* 规则表 → 纯文本（每行一条，格式与 ctl.sh limits-save 完全一致）：
       app|<包名>|<分钟>
       group|<分组名>|<分钟>|<成员包名 …>                        */
  function limitsPayload() {
    syncLimitInputs();
    var lines = [];
    LIMITS.forEach(function (r) {
      if (!r.n) return;
      var m = parseInt(r.m, 10) || 0;
      if (r.t === 'group') lines.push('group|' + r.n + '|' + m + '|' + (r.a || []).join(' '));
      else lines.push('app|' + r.n + '|' + m);
    });
    /* ⚠️ 一条规则都没有时也必须发出**非空**请求体。后端把空 body 当成
       「没收到内容（或为空表）」直接拒绝 —— 这正是「删掉最后一条规则后
       怎么点保存都失败」的原因。放一行注释占位（ctl.sh 会跳过 # 开头的行），
       语义仍然是「清空全部规则」。 */
    lines.push('#momguard-limits');
    return lines.join('\n');
  }

  /* 宿主桥接（KernelSU / WebUI X / Magisk 内置 WebUI）下压根没有 HTTP 通道，
     postRaw 只会立刻报「不支持」。这里走 ctl.sh limits-put '<整张规则表>'：
     单引号字符串里换行是合法的，所以规则表可以原样传过去。 */
  function saveLimitsBridge(payload) {
    var cmd = 'sh ' + MODDIR + '/bin/ctl.sh limits-put ' + "'" + payload + "'";
    return shellRun(cmd).then(function (out) {
      var m = String(out).match(/\{[\s\S]*\}/);
      try { return JSON.parse(m ? m[0] : out); } catch (e) { return { ok: false, msg: '输出解析失败' }; }
    });
  }

  function setLimitResult(text, kind) {
    var el = byId('limit_result');
    if (!el) return;
    el.textContent = text || '';
    el.classList.remove('warn', 'ok');
    if (kind) el.classList.add(kind);
  }

  function saveLimits() {
    var payload = limitsPayload();
    var n = Math.max(0, payload.split('\n').length - 1);   // 去掉占位行
    var btn = byId('btn_limit_save');
    if (btn) btn.disabled = true;
    setLimitResult('正在保存 ' + n + ' 条规则…', '');

    var req = BRIDGE ? saveLimitsBridge(payload)
                     : postRaw('/cgi-bin/api?cmd=limits-save', payload, null);

    req.then(function (d) {
      if (d && d.ok) {
        LIMIT_DIRTY = false;
        LIMIT_SIG = '';
        setLimitResult('✅ 已保存 ' + (d.n != null ? d.n : n) + ' 条规则（' + hmNow() + '）', 'ok');
        toast('已保存 ' + (d.n != null ? d.n : n) + ' 条规则');
      } else {
        var why = (d && d.msg) || '未知错误';
        setLimitResult('❌ 保存失败：' + why + ' —— 改动仍留在页面上，可重试或点「从手机重新读取」', 'warn');
        toast('保存失败：' + why);
      }
      return refresh();
    }).catch(function (e) {
      var why = (e && e.message) ? e.message : String(e);
      /* 失败时**不**清 LIMIT_DIRTY，也不刷新 —— 用户刚敲进去的规则不能被冲掉 */
      setLimitResult('❌ 保存失败：' + why + ' —— 改动仍留在页面上', 'warn');
      toast('保存失败：' + why);
    }).then(function () { if (btn) btn.disabled = false; });
  }

  /* 丢弃页面上的本地改动，重新按手机上的规则表渲染 */
  function reloadLimits() {
    LIMIT_DIRTY = false;
    LIMIT_SIG = '';
    if (EDIT_INDEX >= 0) cancelEdit();          // 放弃编辑态，免得编辑框里留着旧值
    setLimitResult('正在从手机重新读取…', '');
    refresh().then(function () { setLimitResult('已按手机上的规则表刷新', ''); });
  }

  function initLimits() {
    var box = byId('limits_list');
    if (box) {
      box.addEventListener('click', function (e) {
        var t = e.target;
        if (!t || !t.closest) return;
        var row = t.closest('.lrule');
        var i = row ? parseInt(row.getAttribute('data-i'), 10) : -1;
        if (i < 0 || !LIMITS[i]) return;
        if (t.closest('[data-role="edit"]')) { startEdit(i); return; }
        if (!t.closest('[data-role="del"]')) return;
        var wasEditing = EDIT_INDEX >= 0;
        LIMITS.splice(i, 1);
        if (EDIT_INDEX === i) EDIT_INDEX = -1;
        else if (EDIT_INDEX > i) EDIT_INDEX--;     // 删掉的是前面一条，索引要跟着挪
        LIMIT_DIRTY = true;
        renderLimitRows();
        updateLimitTag();
        if (wasEditing && EDIT_INDEX < 0) cancelEdit();
      });
      box.addEventListener('change', function (e) {
        var t = e.target;
        if (!t || t.getAttribute('data-role') !== 'min') return;
        var row = t.closest ? t.closest('.lrule') : null;
        var i = row ? parseInt(row.getAttribute('data-i'), 10) : -1;
        if (i < 0 || !LIMITS[i]) return;
        var v = parseInt(t.value, 10);
        if (isNaN(v) || v < 0) v = 0;
        if (v > 1440) v = 1440;
        LIMITS[i].m = v;
        LIMIT_DIRTY = true;
      });
    }

    var sk = byId('seg_rule_kind');
    if (sk) Array.prototype.forEach.call(sk.querySelectorAll('button'), function (b) {
      b.addEventListener('click', function () { setRuleKind(b.getAttribute('data-v')); });
    });
    setRuleKind('app');

    var gf = byId('rule_group_filter');
    if (gf) gf.addEventListener('input', renderMemberList);

    var ml = byId('rule_group_members');
    if (ml) ml.addEventListener('change', function (e) {
      var t = e.target;
      if (t && t.getAttribute && t.getAttribute('data-pkg')) {
        MEMBER_SEL[t.getAttribute('data-pkg')] = !!t.checked;
      }
    });

    var ab = byId('btn_rule_add');
    if (ab) ab.addEventListener('click', addRule);

    var cb = byId('btn_rule_cancel');
    if (cb) cb.addEventListener('click', cancelEdit);

    var sb = byId('btn_limit_save');
    if (sb) sb.addEventListener('click', saveLimits);

    var rb = byId('btn_limit_reload');
    if (rb) rb.addEventListener('click', reloadLimits);
  }

  /* ================= 小程序 / 快应用管控 =================
     模型：小程序没有独立包名、寄生在宿主 App 内，纯外部 dumpsys 只有**微信**
     能读出「是哪个小程序」（取前台任务的 taskDescription 标题）。**支付宝读不到
     具体小程序名**——它的标题是页面里画出来的图片，系统层面无字可读，只能按
     **页面类型 / 整类**管控：有标题栏的按宿主整体算，没标题栏的那批（短剧频道、
     天天秒杀等）记为中性的「支付宝内置页」整类条目。字节系的容器同样不给名字。
     因此默认策略是「白名单」：没被放行的一律拦 —— 这样新出现的购物类小程序
     不用等用户逐个去禁，天然就是禁着的。 */

  function renderMpSeg(segId, val) {
    var seg = byId(segId);
    if (!seg) return;
    Array.prototype.forEach.call(seg.querySelectorAll('button'), function (b) {
      b.classList.toggle('on', b.getAttribute('data-v') === val);
    });
  }

  function mpCatHtml(c) {
    var cls = MP_CAT_CLS[c] || '';
    return '<span class="bd' + (cls ? ' ' + cls : '') + '">' +
      esc(MP_CAT[c] || '其它') + '</span>';
  }

  /* 固定名条目 = **一个容器整类**，不是某一个具体页面（实测微信小店/卡包、城市服务
     共用 AppBrandPluginUI，系统层面分不出是哪个；支付宝那边同理 —— 短剧频道、
     天天秒杀这类页没有标题栏、标题又是 H5 里画的图片，只能由「支付宝内置页」整类承接）
     → 界面上要讲清楚，否则用户会以为「禁用这一条 = 只禁了小店」，
     其实会连带禁掉城市服务等同类页面。 */
  var MP_CLASS = { '微信内置页': 1, '支付宝内置页': 1 };

  function mpRowHtml(it, i) {
    /* 名字为 `*` = 拿不到小程序名，只能按**宿主整体**管控（微信内置页这类整类固定名已拆出）。
       一定要在界面上讲清楚，否则用户会以为「怎么只有一条」。 */
    var unnamed = (!it.n || it.n === '*');
    var name = unnamed ? '（未识别名称）' : it.n;
    var hint = unnamed ? ' · 按宿主整体管控'
                       : (MP_CLASS[it.n] ? ' · 整类管控（多个页面共用）' : '');
    var pol = it.p || '-';
    var host = MP_HOST[it.h] || it.h || '?';
    var seg = '';
    [['-', '默认'], ['allow', '允许'], ['deny', '禁用']].forEach(function (o) {
      seg += '<button data-role="mp" data-v="' + o[0] + '"' +
             (pol === o[0] ? ' class="on"' : '') + '>' + o[1] + '</button>';
    });
    return '<div class="lrule mprow" data-i="' + i + '">' +
      mpCatHtml(it.c) +
      '<div class="nm"><div class="n">' + esc(name) + '</div>' +
      '<div class="p">' + esc(host) + ' · 打开 ' + (parseInt(it.k, 10) || 0) + ' 次' +
        hint + '</div></div>' +
      '<div class="seg mpseg">' + seg + '</div></div>';
  }

  function renderMpList() {
    var box = byId('mp_list');
    if (!box) return;

    /* 排序：购物类排最前（用户要重点管的就是它们），其余按打开次数降序。
       i 始终指回 MP_ITEMS 的下标，所以排序/筛选不会影响「点哪一行改哪一条」。 */
    var arr = MP_ITEMS.map(function (it, i) { return { it: it, i: i }; });
    arr.sort(function (a, b) {
      var sa = a.it.c === 'shop' ? 0 : 1, sb = b.it.c === 'shop' ? 0 : 1;
      if (sa !== sb) return sa - sb;
      return (parseInt(b.it.k, 10) || 0) - (parseInt(a.it.k, 10) || 0);
    });
    if (MP_FILTER === 'shop') arr = arr.filter(function (o) { return o.it.c === 'shop'; });
    else if (MP_FILTER === 'none') arr = arr.filter(function (o) { return (o.it.p || '-') === '-'; });

    if (!arr.length) {
      box.innerHTML = '<div class="empty">' +
        (MP_ITEMS.length ? '当前筛选下没有小程序'
                         : '还没有打开过任何小程序 —— 用手机打开一个小程序后这里会出现') +
        '</div>';
    } else {
      var html = '';
      arr.forEach(function (o) { html += mpRowHtml(o.it, o.i); });
      box.innerHTML = html;
    }

    var nAllow = 0, nDeny = 0, nShop = 0, nNone = 0;
    MP_ITEMS.forEach(function (it) {
      if (it.p === 'allow') nAllow++;
      else if (it.p === 'deny') nDeny++;
      else nNone++;
      if (it.c === 'shop') nShop++;
    });
    var d = byId('d_mp_list');
    if (d) {
      d.textContent = MP_ITEMS.length
        ? (MP_ITEMS.length + ' 个 · 允许 ' + nAllow + ' · 禁用 ' + nDeny +
           (nNone ? ' · 未设置 ' + nNone : '') + ' · 其中购物类 ' + nShop + ' 个')
        : '还没有记录';
    }
  }

  /* 登记表 → TSV 纯文本（每行 5 列 TAB 分隔，与 ctl.sh mp-save 完全一致）：
       host <TAB> policy <TAB> cat <TAB> count <TAB> name
     名字里去掉 TAB/换行/单引号 —— 宿主桥接模式是把整张表作为**单引号字符串**
     交给 shell 的，名字里带单引号会把引用截断。 */
  function mpPayload() {
    var lines = [];
    MP_ITEMS.forEach(function (it) {
      var name = String(it.n || '').replace(/[\t\r\n']/g, ' ').slice(0, 120);
      if (!name) return;
      lines.push([it.h, it.p || '-', it.c || 'other', parseInt(it.k, 10) || 0, name].join('\t'));
    });
    /* 空表也要发**非空**请求体：后端把空 body 当成「没收到内容」直接拒。
       放一行注释占位（ctl.sh 跳过 # 开头的行），语义仍是「清空登记表」。 */
    lines.push('#momguard-miniapp');
    return lines.join('\n');
  }

  function saveMpBridge(payload) {
    var cmd = 'sh ' + MODDIR + '/bin/ctl.sh mp-put ' + "'" + payload + "'";
    return shellRun(cmd).then(function (out) {
      var m = String(out).match(/\{[\s\S]*\}/);
      try { return JSON.parse(m ? m[0] : out); } catch (e) { return { ok: false, msg: '输出解析失败' }; }
    });
  }

  function setMpResult(text, kind) {
    var el = byId('mp_result');
    if (!el) return;
    el.textContent = text || '';
    el.classList.remove('warn', 'ok');
    if (kind) el.classList.add(kind);
  }

  function saveMp() {
    var payload = mpPayload();
    var n = MP_ITEMS.length;
    var btn = byId('btn_mp_save');
    if (btn) btn.disabled = true;
    setMpResult('正在保存 ' + n + ' 个小程序的策略…', '');

    var req = BRIDGE ? saveMpBridge(payload)
                     : postRaw('/cgi-bin/api?cmd=mp-save', payload, null);

    req.then(function (d) {
      if (d && d.ok) {
        MP_DIRTY = false;
        MP_SIG = '';
        setMpResult('✅ 已保存 ' + (d.n != null ? d.n : n) + ' 条（' + hmNow() + '）', 'ok');
        toast('已保存 ' + (d.n != null ? d.n : n) + ' 条小程序策略');
      } else {
        var why = (d && d.msg) || '未知错误';
        setMpResult('❌ 保存失败：' + why + ' —— 改动仍留在页面上，可重试或点「从手机重新读取」', 'warn');
        toast('保存失败：' + why);
      }
      return refresh();
    }).catch(function (e) {
      var why = (e && e.message) ? e.message : String(e);
      /* 失败时不刷新、不清 MP_DIRTY —— 用户刚点进去的改动不能被冲掉 */
      setMpResult('❌ 保存失败：' + why + ' —— 改动仍留在页面上', 'warn');
      toast('保存失败：' + why);
    }).then(function () { if (btn) btn.disabled = false; });
  }

  function reloadMp() {
    MP_DIRTY = false;
    MP_SIG = '';
    setMpResult('正在从手机重新读取…', '');
    refresh().then(function () { setMpResult('已按手机上的登记表刷新', ''); });
  }

  function mpShopDenyAll() {
    var n = 0;
    MP_ITEMS.forEach(function (it) { if (it.c === 'shop') { it.p = 'deny'; n++; } });
    if (!n) { toast('列表里还没有购物类小程序'); return; }
    MP_DIRTY = true;
    renderMpList();
    toast('已把 ' + n + ' 个购物类设为禁用，记得点「保存」');
  }

  function initMp() {
    var box = byId('mp_list');
    if (box) {
      box.addEventListener('click', function (e) {
        var t = e.target;
        if (!t || !t.closest) return;
        var b = t.closest('[data-role="mp"]');
        if (!b) return;
        var row = t.closest('.lrule');
        var i = row ? parseInt(row.getAttribute('data-i'), 10) : -1;
        if (i < 0 || !MP_ITEMS[i]) return;
        MP_ITEMS[i].p = b.getAttribute('data-v');
        MP_DIRTY = true;
        renderMpList();
      });
    }

    var f = byId('seg_mp_filter');
    if (f) Array.prototype.forEach.call(f.querySelectorAll('button'), function (b) {
      b.addEventListener('click', function () {
        MP_FILTER = b.getAttribute('data-v');
        Array.prototype.forEach.call(f.querySelectorAll('button'), function (x) {
          x.classList.toggle('on', x === b);
        });
        renderMpList();
      });
      b.classList.toggle('on', b.getAttribute('data-v') === MP_FILTER);
    });

    var sb = byId('btn_mp_save'); if (sb) sb.addEventListener('click', saveMp);
    var rb = byId('btn_mp_reload'); if (rb) rb.addEventListener('click', reloadMp);
    var sd = byId('btn_mp_shop_deny'); if (sd) sd.addEventListener('click', mpShopDenyAll);
  }

  /* ================= 微信网页（域名）管控 =================
     与小程序那套一样：服务端下发名单 → 本地可编辑 → 整张表回传（TSV）。
     开关 / 默认策略 / 有效期走 cfg 块（`c.web_guard` 等，全是字符串），
     不走 web 块 —— 避免 mp 块那种「块间类型不一致」的坑。 */

  /* 域名规整：用户常会直接粘一整条 URL —— 统一剥掉协议、user@、端口、路径/查询，
     只留纯域名；后端 ctl.sh web-save 还会再校验一次（只放行 a-z0-9.-）。 */
  function normDomain(raw) {
    var s = String(raw || '').trim().toLowerCase();
    s = s.replace(/^[a-z][a-z0-9+.-]*:\/\//, '');   // http(s):// 等协议
    s = s.replace(/^\/\//, '');
    s = s.replace(/^[^@\/]*@/, '');                 // user@
    s = s.replace(/[\/?#].*$/, '');                 // 路径 / 查询 / 锚
    s = s.replace(/:\d+$/, '');                     // 端口
    s = s.replace(/\.+$/, '');                      // 结尾的点
    return s;
  }

  function webRowHtml(it, i) {
    var seg = '';
    [['allow', '放行'], ['deny', '拦截'], ['del', '删']].forEach(function (o) {
      seg += '<button data-role="web" data-v="' + o[0] + '"' +
             ((o[0] !== 'del' && (it.p || 'deny') === o[0]) ? ' class="on"' : '') +
             '>' + o[1] + '</button>';
    });
    var sub = it.n ? esc(it.n) : '未命名';
    return '<div class="lrule mprow" data-i="' + i + '">' +
      '<div class="nm"><div class="n">' + esc(it.d) + '</div>' +
      '<div class="p">' + sub + '</div></div>' +
      '<div class="seg mpseg">' + seg + '</div></div>';
  }

  function renderWebList() {
    var box = byId('web_list');
    if (!box) return;
    if (!WEB_ITEMS.length) {
      box.innerHTML = '<div class="empty">还没有配置域名 —— 在上面输入域名后点「添加」</div>';
    } else {
      var html = '';
      WEB_ITEMS.forEach(function (it, i) { html += webRowHtml(it, i); });
      box.innerHTML = html;
    }
    var nA = 0, nD = 0;
    WEB_ITEMS.forEach(function (it) { if (it.p === 'allow') nA++; else nD++; });
    var d = byId('d_web_list');
    if (d) {
      d.textContent = WEB_ITEMS.length
        ? (WEB_ITEMS.length + ' 个域名 · 放行 ' + nA + ' · 拦截 ' + nD)
        : '还没有配置';
    }
  }

  /* 名单 → TSV 纯文本（每行 3 列 TAB 分隔，与 ctl.sh web-save 完全一致）：
       domain <TAB> policy <TAB> name
     名字里去掉 TAB/换行/单引号 —— 宿主桥接模式是把整张表作为**单引号字符串**
     交给 shell 的，名字里带单引号会把引用截断。 */
  function webPayload() {
    var lines = [];
    WEB_ITEMS.forEach(function (it) {
      var d = normDomain(it.d);
      if (!d) return;
      var nm = String(it.n || '').replace(/[\t\r\n']/g, ' ').slice(0, 60);
      lines.push([d, (it.p === 'allow' ? 'allow' : 'deny'), nm].join('\t'));
    });
    /* 空表也要发**非空**请求体：后端把空 body 当成「没收到内容」直接拒。 */
    lines.push('#momguard-webrule');
    return lines.join('\n');
  }

  function saveWebBridge(payload) {
    var cmd = 'sh ' + MODDIR + '/bin/ctl.sh web-put ' + "'" + payload + "'";
    return shellRun(cmd).then(function (out) {
      var m = String(out).match(/\{[\s\S]*\}/);
      try { return JSON.parse(m ? m[0] : out); } catch (e) { return { ok: false, msg: '输出解析失败' }; }
    });
  }

  function setWebResult(text, kind) {
    var el = byId('web_result');
    if (!el) return;
    el.textContent = text || '';
    el.classList.remove('warn', 'ok');
    if (kind) el.classList.add(kind);
  }

  function saveWeb() {
    var payload = webPayload();
    var n = WEB_ITEMS.length;
    var btn = byId('btn_web_save');
    if (btn) btn.disabled = true;
    setWebResult('正在保存 ' + n + ' 条域名…', '');

    var req = BRIDGE ? saveWebBridge(payload)
                     : postRaw('/cgi-bin/api?cmd=web-save', payload, null);

    req.then(function (d) {
      if (d && d.ok) {
        WEB_DIRTY = false;
        WEB_SIG = '';
        var extra = d.bad ? ('（另有 ' + d.bad + ' 行非法已丢弃）') : '';
        setWebResult('✅ 已保存 ' + (d.n != null ? d.n : n) + ' 条（' + hmNow() + '）' + extra, 'ok');
        toast('已保存 ' + (d.n != null ? d.n : n) + ' 条域名');
      } else {
        var why = (d && d.msg) || '未知错误';
        setWebResult('❌ 保存失败：' + why + ' —— 改动仍留在页面上，可重试或点「从手机重新读取」', 'warn');
        toast('保存失败：' + why);
      }
      return refresh();
    }).catch(function (e) {
      var why = (e && e.message) ? e.message : String(e);
      /* 失败时不刷新、不清 WEB_DIRTY —— 用户刚填的域名不能被冲掉 */
      setWebResult('❌ 保存失败：' + why + ' —— 改动仍留在页面上', 'warn');
      toast('保存失败：' + why);
    }).then(function () { if (btn) btn.disabled = false; });
  }

  function reloadWeb() {
    WEB_DIRTY = false;
    WEB_SIG = '';
    setWebResult('正在从手机重新读取…', '');
    refresh().then(function () { setWebResult('已按手机上的域名表刷新', ''); });
  }

  function webAdd() {
    var inp = byId('in_web_domain');
    if (!inp) return;
    var d = normDomain(inp.value);
    if (!d) { toast('请先填写域名'); return; }
    if (!/[a-z0-9]/.test(d)) { toast('域名不合法：' + d); return; }
    for (var i = 0; i < WEB_ITEMS.length; i++) {
      if (WEB_ITEMS[i].d === d) { toast('该域名已在名单里'); inp.value = ''; return; }
    }
    WEB_ITEMS.push({ d: d, p: 'deny', n: '' });
    WEB_DIRTY = true;
    inp.value = '';
    renderWebList();
    toast('已添加 ' + d + '（默认拦截），记得点「保存域名设置」');
  }

  function initWeb() {
    var box = byId('web_list');
    if (box) {
      box.addEventListener('click', function (e) {
        var t = e.target;
        if (!t || !t.closest) return;
        var b = t.closest('[data-role="web"]');
        if (!b) return;
        var row = t.closest('.lrule');
        var i = row ? parseInt(row.getAttribute('data-i'), 10) : -1;
        if (i < 0 || !WEB_ITEMS[i]) return;
        var v = b.getAttribute('data-v');
        if (v === 'del') WEB_ITEMS.splice(i, 1);
        else WEB_ITEMS[i].p = (v === 'allow') ? 'allow' : 'deny';
        WEB_DIRTY = true;
        renderWebList();
      });
    }
    var ab = byId('btn_web_add'); if (ab) ab.addEventListener('click', webAdd);
    var sb = byId('btn_web_save'); if (sb) sb.addEventListener('click', saveWeb);
    var rb = byId('btn_web_reload'); if (rb) rb.addEventListener('click', reloadWeb);
    var di = byId('in_web_domain');
    if (di) di.addEventListener('keydown', function (e) { if (e.key === 'Enter') webAdd(); });
  }

  function renderWeb(web, c) {
    web = web || {};
    setSwitch(byId('sw_web_guard'), c.web_guard === '1');
    renderMpSeg('seg_web_default', c.web_default === 'allow' ? 'allow' : 'deny');
    var fIn = byId('in_web_fresh');
    if (fIn && document.activeElement !== fIn) fIn.value = c.web_fresh || '15';
    /* 默认策略 / 有效期只在总开关打开时才有意义 */
    setSubsDisabled('#subs_web', c.web_guard !== '1');

    var items = (web.items || []).map(function (x) {
      return { d: x.d || '', p: (x.p === 'allow' ? 'allow' : 'deny'), n: x.n || '' };
    });
    /* 用户改过还没保存时不许覆盖（否则每 5 秒轮询会把他的编辑冲掉） */
    var sig = JSON.stringify(items);
    if (!WEB_DIRTY && sig !== WEB_SIG) { WEB_ITEMS = items; WEB_SIG = sig; }
    renderWebList();

    var blocked = parseInt(web.blocked, 10) || 0;
    var tg = byId('tag_web');
    if (tg) {
      if (c.web_guard === '1') tg.textContent = (c.web_default === 'deny') ? '运行中(激进)' : '运行中';
      else tg.textContent = '已停用';
    }
    var dw = byId('d_web');
    if (dw) {
      var s;
      if (c.web_guard !== '1') {
        s = '未开启：不解析微信网页网址';
      } else {
        s = '已开启：' + (c.web_default === 'allow'
              ? '黑名单模式（只拦名单里标为「拦截」的域名）'
              : '白名单模式（除「放行」的以外全拦）') +
            '，网址有效期 ' + (c.web_fresh || '15') + 's，名单 ' + WEB_ITEMS.length + ' 条';
      }
      dw.textContent = s + '；累计拦截 ' + blocked + ' 次';
      dw.classList.toggle('warn', c.web_guard === '1' && c.web_default === 'deny');
    }
  }

  function renderMiniapp(mp) {
    mp = mp || {};
    /* ⚠️ 类型归一化：ctl.sh 的 "mp" 块里这些字段是**裸数字**（`"guard":1`），
       而 "cfg" 块是字符串（`"wechat_guard":"1"`）。JSON.parse 之后前者是 number、
       后者是 string —— 不同步归一化，下面 `mp.guard === '1'` 就恒为 false，
       表现是「点了『禁用系统快应用』/『启用小程序精细管控』后自己跳回关闭」。
       这里统一成 '1'/'0'，后续一律用严格比较。 */
    ['guard', 'quickapp', 'wx', 'alipay', 'byte', 'baidu', 'toast'].forEach(function (k) {
      mp[k] = (mp[k] === 1 || mp[k] === '1' || mp[k] === true) ? '1' : '0';
    });
    setSwitch(byId('sw_mp_guard'), mp.guard === '1');
    setSwitch(byId('sw_mp_quickapp'), mp.quickapp === '1');
    setSwitch(byId('sw_mp_wx'), mp.wx === '1');
    setSwitch(byId('sw_mp_alipay'), mp.alipay === '1');
    setSwitch(byId('sw_mp_byte'), mp.byte === '1');
    setSwitch(byId('sw_mp_baidu'), mp.baidu === '1');
    setSwitch(byId('sw_mp_toast'), mp.toast === '1');

    MP_DEFAULT = mp.default || 'deny';
    MP_ACTION = mp.action || 'back';
    renderMpSeg('seg_mp_default', MP_DEFAULT);
    renderMpSeg('seg_mp_action', MP_ACTION);
    /* 宿主开关 / 默认策略 / 处置 / toast 都只在总开关打开时才有意义 */
    setSubsDisabled('#subs_mp', mp.guard !== '1');

    var blocked = parseInt(mp.blocked, 10) || 0;
    var tg = byId('tag_mp');
    if (tg) {
      if (mp.guard === '1' && mp.quickapp === '1') tg.textContent = '运行中';
      else if (mp.guard === '1') tg.textContent = '小程序管控';
      else if (mp.quickapp === '1') tg.textContent = '仅禁快应用';
      else tg.textContent = '已停用';
    }

    var dm = byId('d_mp');
    if (dm) {
      var s;
      if (mp.guard !== '1' && mp.quickapp !== '1') {
        s = '未开启：不干预小程序与快应用';
      } else {
        var parts = [];
        if (mp.quickapp === '1') parts.push('快应用');
        if (mp.guard === '1') {
          var hs = [];
          if (mp.wx === '1') hs.push('微信');
          if (mp.alipay === '1') hs.push('支付宝');
          if (mp.byte === '1') hs.push('头条/抖音');
          if (mp.baidu === '1') hs.push('百度');
          parts.push(hs.length ? (hs.join('、') + ' 小程序') : '未选任何宿主');
        }
        s = '已开启：' + parts.join(' + ') + '；' +
            (MP_DEFAULT === 'allow' ? '黑名单模式' : '白名单模式');
      }
      dm.textContent = s + '；累计拦截 ' + blocked + ' 次';
      dm.classList.toggle('warn', mp.guard === '1' && (mp.wx !== '1' && mp.alipay !== '1' &&
                            mp.byte !== '1' && mp.baidu !== '1'));
    }

    /* 列表：用户改过还没保存时不覆盖（否则每 5 秒把策略选择冲掉） */
    if (MP_DIRTY) return;
    var sig = JSON.stringify(mp.items || []);
    if (sig === MP_SIG) return;
    MP_SIG = sig;
    MP_ITEMS = (mp.items || []).map(function (it) {
      return { h: it.h, p: it.p || '-', c: it.c || 'other',
               k: parseInt(it.k, 10) || 0, n: it.n || '' };
    });
    renderMpList();
  }

  /* ================= 页面安装 APK ================= */
  function initApkUpload() {
    var fileEl = byId('apk_file'), btn = byId('btn_apk_install');
    if (!btn) return;
    var prog = byId('apk_prog');
    var bar = prog ? prog.querySelector('i') : null;
    var msg = byId('apk_msg');

    function say(t, warn) {
      if (!msg) return;
      msg.textContent = t;
      msg.classList.toggle('warn', !!warn);
    }
    function setProg(frac, state) {
      if (!prog) return;
      prog.classList.add('on');
      prog.classList.remove('done', 'err');
      if (state === 'done') prog.classList.add('done');
      if (state === 'err') prog.classList.add('err');
      if (bar) bar.style.width = Math.round(Math.max(0, Math.min(1, frac || 0)) * 100) + '%';
    }

    if (BRIDGE) {
      btn.disabled = true;
      say('页面安装需要经 127.0.0.1 的网页访问；当前是宿主桥接模式，无法上传二进制文件。');
      return;
    }

    btn.addEventListener('click', function () {
      var f = fileEl && fileEl.files && fileEl.files[0];
      if (!f) { toast('请先选择一个 .apk 文件'); return; }
      if (!/\.apk$/i.test(f.name)) { toast('请选择 .apk 文件'); return; }

      btn.disabled = true;
      setProg(0, 'run');
      say('正在上传 ' + f.name + '（' + fmtSize(f.size) + '）…');

      var safe = String(f.name).replace(/[^A-Za-z0-9_.-]/g, '_');
      var url = '/cgi-bin/api?cmd=install-upload&name=' + encodeURIComponent(safe);

      postRaw(url, f, function (frac) {
        setProg(frac * 0.9, 'run');            // 前 90% 是上传，剩下留给手机端 pm install
        say('正在上传 ' + f.name + ' · ' + Math.round(frac * 100) + '%');
      }).then(function (d) {
        if (d && d.ok) {
          setProg(1, 'done');
          say('安装成功：' + (d.added ? String(d.added).trim() : f.name) + '（已记入允许清单，不会被自动卸载）');
          toast('安装成功');
        } else {
          setProg(1, 'err');
          say('安装失败：' + ((d && d.msg) || '未知错误'), true);
        }
        return refresh();
      }).catch(function (e) {
        setProg(1, 'err');
        say('上传失败：' + (e && e.message ? e.message : e), true);
      }).then(function () { btn.disabled = false; });
    });
  }

  function initUsageActions() {
    var ur = byId('btn_usage_refresh');
    if (ur) ur.addEventListener('click', function () {
      if (USAGE_DAY) { toast('历史记录不会变；要看今天请把日期切回「今天」'); return; }
      api('usage-refresh').then(function (r) {
        toast((r && r.msg) || '已请求刷新');
        setTimeout(function () { refresh(); loadUsageDays(); }, 2500);   // 守护进程下一轮（≤1 秒）才算完
      });
    });
    var sel = byId('usage_daysel');
    if (sel) sel.addEventListener('change', function () {
      var v = String(sel.value || '');
      if (!v || (USAGE_TODAY && v === USAGE_TODAY)) {
        USAGE_DAY = '';
        refresh();
        return;
      }
      showUsageDay(v);
    });
    loadUsageDays();
  }

  function render(d) {
    var c = d.cfg || {}, s = d.status || {}, v = d.vol || {};

    /* ============ 顶部全局状态 ============ */
    var p = '';
    p += s.guard == 1 ? pill('on', '守护进程 运行中') : pill('off', '守护进程 未运行');
    p += s.install_state == 1 ? pill('on', '安装拦截 已生效') : pill('mid', '安装拦截 已放行');
    p += c.wechat_guard == '1' ? pill('on', '微信管控 开启') : pill('', '微信管控 关闭');
    if (c.wechat_keepalive == '1') {
      p += pill('on', '微信保活' + (String(s.wx_main) === '1' ? '' : ' · 进程不在'));
    }
    if (c.usage_limit == '1') {
      var limN = (d.limits && parseInt(d.limits.count, 10)) || 0;
      p += pill(limN ? 'on' : 'mid', '时长管控 ' + (limN ? limN + ' 条规则' : '无规则'));
    }
    if (c.mp_guard == '1' || c.mp_quickapp == '1') {
      var mpN = (d.mp && parseInt(d.mp.count, 10)) || 0;
      if (c.mp_guard == '1') p += pill('on', '小程序管控' + (mpN ? ' ' + mpN + ' 个' : ''));
      else p += pill('mid', '仅禁快应用');
    }

    var onCount = 0;
    VOLS.forEach(function (k) { if (c['vol_' + k + '_on'] === '1') onCount++; });
    if (onCount > 0) p += pill('on', '音量监管 ' + onCount + ' 条流');
    else p += pill('', '音量不干预');

    if (c.wifi_keep == '1') {
      if (s.wifi_on == '1') p += pill('on', s.wifi_link == '1' ? 'WiFi 已连接' : 'WiFi 已开启');
      else p += pill('off', 'WiFi 已关闭');
    }
    if (c.adb_tcp == '1') {
      p += (s.adb_listen == '1') ? pill('on', '无线调试 :' + s.adb_port) : pill('mid', '无线调试 等待监听');
    }
    if (c.nfc_auto == '1') {
      if (s.nfc_on == '1') p += pill('mid', 'NFC 剩余 ' + fmtSec(s.nfc_remain));
      else if (s.nfc_on == 'x') p += pill('', 'NFC 不可用');
      else p += pill('', 'NFC 已关闭');
    }
    byId('pills').innerHTML = p;

    /* ============ 页签一：自动管家 ============ */
    VOLS.forEach(function (k) {
      var info = v[k] || {};
      var on = c['vol_' + k + '_on'] === '1';
      setSwitch(byId('sw_vol_' + k + '_on'), on);

      var dEl = byId('d_vol_' + k);
      if (dEl) {
        dEl.textContent = '当前 ' + (info.cur || '?') + ' / 上限 ' + (info.max || '?') +
          (on ? ' · 目标 ' + (info.target || '?') : ' · 未监管');
      }
      var hEl = byId('h_vol_' + k);
      if (hEl) hEl.textContent = '0–' + (info.max || '?') + '，或 max';

      var box = byId('row_vol_' + k);
      if (box) { if (on) box.removeAttribute('disabled'); else box.setAttribute('disabled', ''); }

      var inp = byId('in_vol_' + k);
      if (inp && document.activeElement !== inp) inp.value = c['vol_' + k] || '';
    });

    Array.prototype.forEach.call(byId('seg_vol_mode').querySelectorAll('button'), function (b) {
      b.classList.toggle('on', b.getAttribute('data-v') === c.vol_mode);
    });

    var fixCount = parseInt(s.vol_fix, 10) || 0;
    byId('tag_vol').textContent = (onCount ? ('监管 ' + onCount + ' 条 · ') : '已停用 · ') + '累计拉回 ' + fixCount + ' 次';

    /* 通知 / 铃声别名提示：两条流都在监管且目标值不同时才有必要警告 */
    var aliasEl = byId('notif_alias');
    if (aliasEl) {
      var bothOn = c.vol_notif_on === '1' && c.vol_ring_on === '1';
      var same = String(c.vol_ring) === String(c.vol_notif);
      aliasEl.style.display = (s.alias_notif_ring === '1' && bothOn && !same) ? '' : 'none';
    }

    /* 静音 / 免打扰 */
    setSwitch(byId('sw_ring_normal'), c.ring_normal === '1');
    setSwitch(byId('sw_ring_dnd'), c.ring_dnd === '1');
    var forcing = (c.ring_normal === '1' || c.ring_dnd === '1');
    byId('tag_ringer').textContent = forcing ? '强制响铃' : '不干预';

    var RMAP = { NORMAL: '响铃', SILENT: '静音', VIBRATE: '振动' };
    var ZMAP = {
      ZEN_MODE_OFF: '已关闭',
      ZEN_MODE_IMPORTANT_INTERRUPTIONS: '仅允许重要打扰',
      ZEN_MODE_NO_INTERRUPTIONS: '完全不打扰',
      ZEN_MODE_ALARMS: '仅允许闹钟'
    };
    var rtxt = '当前 铃声模式 ' + (RMAP[s.ringer] || s.ringer || '未知') +
      ' · 免打扰 ' + (ZMAP[s.zen] || s.zen || '未知');
    rtxt += '。累计拉回 ' + (s.ring_fix || 0) + ' 次';
    var dRing = byId('d_ringer');
    if (dRing) {
      dRing.textContent = rtxt;
      dRing.classList.toggle('warn', (s.ringer === 'SILENT' || s.ringer === 'VIBRATE') ||
        (s.zen && s.zen !== 'ZEN_MODE_OFF'));
    }

    /* WiFi */
    setSwitch(byId('sw_wifi_keep'), c.wifi_keep === '1');
    setSwitch(byId('sw_wifi_reconnect'), c.wifi_reconnect === '1');
    byId('tag_wifi').textContent = c.wifi_keep === '1' ? '监管中' : '已停用';
    var wtxt = s.wifi_on === '1' ? '已开启' : (s.wifi_on === '0' ? '已关闭' : '状态未知');
    if (s.wifi_on === '1') wtxt += (s.wifi_link == '1' ? '，已连接网络' : '，未连接网络');
    wtxt += '，累计自动处理 ' + (s.wifi_fix || 0) + ' 次';
    byId('d_wifi').textContent = wtxt;
    setSubsDisabled('#subs_wifi', c.wifi_keep !== '1');

    /* 无线调试 */
    setSwitch(byId('sw_adb_tcp'), c.adb_tcp === '1');
    setSwitch(byId('sw_adb_noauth'), c.adb_noauth === '1');
    byId('tag_adb').textContent = c.adb_tcp === '1' ? '已开启' : '已停用';
    var atxt;
    if (s.adb_listen == '1') atxt = 'adbd 正在监听 :' + s.adb_port;
    else if (s.adb_listen == '0') atxt = 'adbd 尚未监听 :' + s.adb_port + '，守护进程会自动拉起';
    else atxt = '无法读取监听状态，端口配置为 :' + s.adb_port;
    atxt += '，累计端口校正 ' + (s.adb_fix || 0) + ' 次';
    byId('d_adb').textContent = atxt;

    var nIn = byId('in_adb_port');
    if (nIn && document.activeElement !== nIn) nIn.value = s.adb_port || '';

    /* 来源网段白名单：state 由 guard 下发 iptables 后写回 stats
       0=未确认/下发失败  1=已生效  2=未启用（未配置网段） */
    var aIn = byId('in_adb_allow');
    if (aIn && document.activeElement !== aIn) aIn.value = c.adb_allow || '';

    var dAllow = byId('d_adb_allow');
    if (dAllow) {
      var allow = c.adb_allow || '';
      var alst = String(s.adb_allow_state);
      if (!allow) {
        dAllow.textContent = '未限制来源：任何能连到本机的主机都可尝试连接 :' + (s.adb_port || '');
        dAllow.classList.remove('warn');
      } else if (alst === '1') {
        dAllow.textContent = '已生效：仅 ' + allow + ' 可连接 :' + (s.adb_port || '') + '，其他来源被丢弃';
        dAllow.classList.remove('warn');
      } else if (alst === '2') {
        dAllow.textContent = '已设为 ' + allow + '，守护进程尚未确认（约 30 秒内生效）';
        dAllow.classList.add('warn');
      } else {
        dAllow.textContent = '白名单未生效（' + allow + '）—— 本机可能没有 iptables，详见事件日志';
        dAllow.classList.add('warn');
      }
    }

    var secure = s.adb_secure === '0';
    var dNoAuth = byId('d_noauth');
    if (dNoAuth) {
      dNoAuth.textContent = secure
        ? '已关闭密钥校验（ro.adb.secure=0），任何 adb 客户端可直接连接，只剩来源白名单一层保护'
        : '当前校验密钥（ro.adb.secure=' + (s.adb_secure || '?') + '）：模块预置的公钥免弹窗，其他客户端需在手机上确认';
      dNoAuth.classList.toggle('warn', secure);
    }

    var ip = s.wifi_ip || '';
    var cmdEl = byId('adb_cmd');
    if (cmdEl) cmdEl.textContent = '连接命令： adb connect ' + (ip ? ip : '<手机局域网IP>') + ':' + (s.adb_port || '5555');

    setSubsDisabled('#subs_adb', c.adb_tcp !== '1');

    /* NFC */
    setSwitch(byId('sw_nfc_auto'), c.nfc_auto === '1');
    byId('tag_nfc').textContent = c.nfc_auto === '1'
      ? (s.nfc_on === '1' ? '计时中' : (s.nfc_on === 'x' ? '不可用' : '待命'))
      : '已停用';
    var ntxt;
    if (s.nfc_on === '1') ntxt = 'NFC 已开启，剩余 ' + fmtSec(s.nfc_remain) + ' 后自动关闭';
    else if (s.nfc_on === '0') ntxt = 'NFC 当前关闭，开启后自动开始计时';
    else if (s.nfc_on === 'x') ntxt = '系统当前未注册 nfc 服务（NFC 关闭时不注册，属正常现象），本功能只在本机 NFC 开启后生效';
    else ntxt = '无法读取 NFC 状态';
    ntxt += '，累计自动关闭 ' + (s.nfc_off || 0) + ' 次';
    byId('d_nfc').textContent = ntxt;

    REMAIN = parseInt(s.nfc_remain, 10) || 0;

    var mIn = byId('in_nfc_minutes');
    if (mIn && document.activeElement !== mIn) mIn.value = c.nfc_minutes || '';
    var uK = byId('in_usage_keep_days');
    if (uK && document.activeElement !== uK) uK.value = c.usage_keep_days || '';

    setSubsDisabled('#subs_nfc', c.nfc_auto !== '1');

    /* ============ 页签二：应用管控 ============ */
    setSwitch(byId('sw_install'), c.install_block === '1');
    var tI = byId('tag_install'), dI = byId('d_install');
    var baseN = parseInt(s.pkg_base, 10) || 0;
    var blkN = parseInt(s.install_blocked, 10) || 0;
    /* 系统级一刀切禁装必须为 off，否则连升级都会被 PackageInstallerService 拒绝 */
    var sysBan = s.sys_restriction === 'true';
    if (c.install_block === '1') {
      tI.textContent = '管控中';
      var itxt = baseN > 0
        ? '已记录 ' + baseN + ' 个已装应用，只允许它们升级'
        : '正在建立应用基线…';
      itxt += '；累计拦截新装 ' + blkN + ' 次';
      if (sysBan) itxt += '。⚠️ 系统仍处于全面禁装状态，应用升级会被拒绝，守护进程正在自动解除';
      dI.textContent = itxt;
    } else if (c.install_block === '0') {
      tI.textContent = '已停用';
      dI.textContent = '允许任意安装与升级，累计拦截新装 ' + blkN + ' 次'
        + (sysBan ? '。⚠️ 检测到系统级全面禁装仍在生效，打开本开关会自动解除' : '');
    } else {
      tI.textContent = '状态未知';
      dI.textContent = '无法读取配置，请确认 root 授权正常';
    }

    setSwitch(byId('sw_wechat_guard'), c.wechat_guard === '1');
    setSwitch(byId('sw_wechat_block_finder'), c.wechat_block_finder === '1');
    setSwitch(byId('sw_wechat_block_misc'), c.wechat_block_misc === '1');
    byId('tag_wechat').textContent = c.wechat_guard === '1' ? '运行中' : '已停用';

    var wd = byId('d_wechat');
    if (wd) {
      var wtxt2 = '累计拦截 ' + (s.wechat_blocked || 0) + ' 次';
      if (s.front) wtxt2 += '，当前前台 ' + String(s.front).split('/')[0];
      wd.textContent = wtxt2;
    }

    Array.prototype.forEach.call(byId('seg_wx_mode').querySelectorAll('button'), function (b) {
      b.classList.toggle('on', b.getAttribute('data-v') === c.wechat_mode);
    });
    setSubsDisabled('#subs_wechat', c.wechat_guard !== '1');

    /* 微信保活（独立于上面的管控总开关，管控关着也能用） */
    setSwitch(byId('sw_wechat_keepalive'), c.wechat_keepalive === '1');
    var wk = byId('d_wxkeep');
    if (wk) {
      var keep = c.wechat_keepalive === '1';
      var mainAlive = String(s.wx_main) === '1', pushAlive = String(s.wx_push) === '1';
      var wkt;
      if (!keep) {
        wkt = '未启用：微信可能被系统在深度休眠时冻结，消息会延迟';
      } else {
        wkt = '主进程' + (mainAlive ? '存活' : '已退出') +
              ' · 推送进程' + (pushAlive ? '存活' : '已退出') +
              ' · 系统放行' + (String(s.wx_keep) === '1' ? '已生效' : '待确认');
        if (s.wx_bucket) wkt += ' · 待机桶 ' + bucketName(s.wx_bucket);
      }
      wk.textContent = wkt;
      wk.classList.toggle('warn', keep && !mainAlive);
    }
    var wkn = byId('wx_keep_note');
    if (wkn) wkn.style.display =
      (c.wechat_keepalive === '1' && c.wechat_mode === 'kill') ? '' : 'none';

    /* 小程序 / 快应用管控 */
    renderMiniapp(d.mp);

    /* ============ 微信网页（域名）管控 ============ */
    /* ⚠️ 这一行曾经漏掉：renderWeb/initWeb 只定义、没有调用点 →
       卡片永远停在 HTML 里的「读取中…」占位，开关和按钮也全都没绑事件。 */
    renderWeb(d.web, c);

    /* ============ 页签三：使用统计 / 时长管控 ============ */
    // 历史视图下不跟着 5 秒轮询覆盖：历史数据不会变，覆盖了用户就没法安稳看
    if (d.usage && d.usage.day && !USAGE_TODAY) {
      USAGE_TODAY = d.usage.day;
      loadUsageDays();
    }
    if (!USAGE_DAY) renderUsage(d.usage);
    renderLimits(d.limits);

    setSwitch(byId('sw_usage_track'), c.usage_track === '1');
    setSwitch(byId('sw_usage_limit'), c.usage_limit === '1');
    setSwitch(byId('sw_toast_on'), c.toast_on === '1');
    /* 注意：只灰掉「处置方式」那一行。规则编辑器（#limit_editor）**不在** #subs_limit
       里面 —— 放进去的话总开关一关，添加按钮和输入框就会因为
       .row[disabled]{pointer-events:none} 直接点不动。 */
    setSubsDisabled('#subs_limit', c.usage_limit !== '1');

    /* 规则表状态提示（保存结果另有 #limit_result，两者互不干扰） */
    var lm = '';
    if (c.usage_limit !== '1') lm = '时长管控当前已关闭：规则可以先在这里配好，打开上面的开关才生效';
    else if (LIMIT_DIRTY) lm = '有未保存的改动 —— 点「保存全部规则」才会写到手机上';
    else if (LIMITS.length) lm = '与手机上的规则表一致，共 ' + LIMITS.length + ' 条';
    else lm = '手机上还没有规则，用下面「新增一条规则」添加';
    var lme = byId('limit_msg');
    if (lme) {
      if (lme.textContent !== lm) lme.textContent = lm;
      lme.classList.toggle('warn', (LIMIT_DIRTY || c.usage_limit !== '1') && !!lm);
    }

    var tF = byId('tag_front');
    if (tF) tF.textContent = s.front ? '前台' : '待机';
    var uC = byId('usage_cur');
    if (uC) uC.textContent = s.front
      ? ('当前前台：' + appLabel(s.front))
      : '当前没有前台应用（可能熄屏了，或系统未暴露前台组件）';

    var dL = byId('d_limit');
    if (dL) {
      if (c.usage_limit === '1') {
        var lc = (LIMITS && LIMITS.length) || 0;
        dL.textContent = '已开启' +
          (lc ? ('，共 ' + lc + ' 条规则') : '，但还没有规则（等于不限制）') +
          '；累计禁用 ' + (s.limit_blocked || 0) + ' 次';
        dL.classList.toggle('warn', lc === 0);
      } else {
        dL.textContent = '未开启：只统计、不拦截';
        dL.classList.remove('warn');
      }
    }

    /* ============ 页签四：服务 ============ */
    setSwitch(byId('sw_webui_autostart'), c.webui_autostart === '1');
    setSwitch(byId('sw_debug_trace'), c.debug_trace === '1');

    /* 访问密码状态（json 只回报设没设，不回哈希本身） */
    S_ADBKEY_IN = s.adbkey_in === '1';
    var dUp = byId('d_ui_pass');
    if (dUp) {
      dUp.textContent = (s.ui_pass === '1')
        ? '已设置。页面不存密码、不写 cookie，重新打开需再次输入'
        : '未设置 —— 任何本机页面都能调用这套接口，建议设置一个';
      dUp.classList.toggle('warn', s.ui_pass !== '1');
    }
    renderAdbkey();

    renderLogs(d.log);
    byId('tag_count').textContent = '最近 ' + ((d.log && d.log.length) || 0) + ' 条';

    byId('foot_info').innerHTML =
      '服务端口 127.0.0.1:' + esc(c.webui_port || '8899') +
      ' · 传输方式 ' + (BRIDGE ? ('宿主桥接 ' + esc(BRIDGE)) : '本地 HTTP') +
      (s.guard_started ? '<br>守护进程启动于 ' + esc(fmtTime(s.guard_started)) : '');
  }

  /* ---------- 交互 ---------- */
  var failCount = 0;

  function refresh() {
    if (AUTH_LOCK) return Promise.resolve();
    return api('json').then(function (d) {
      if (!d || d.ok === false) {
        /* auth:1 = 手机上设了访问密码而本页没有正确凭证 —— 弹闸门拦住，
           轮询在 AUTH_LOCK 期间自动挂起，输对密码后由 tryGate 恢复 */
        if (d && d.auth === 1) { showGate(''); return; }
        failCount++;
        if (failCount === 1) toast((d && d.msg) || '读取失败');
        return;
      }
      failCount = 0;
      render(d);
    });
  }

  function bindSwitch(id, key) {
    var el = byId(id);
    if (!el) return;
    el.addEventListener('click', function () {
      var next = el.classList.contains('on') ? '0' : '1';
      setSwitch(el, next === '1');
      api('set', key, next).then(function (r) {
        if (!r || r.ok === false) toast('修改失败：' + ((r && r.msg) || '未知错误'));
        return refresh();
      });
    });
  }

  function bindNumber(inputId, btnId, key, label, allowMax) {
    var inp = byId(inputId), btn = byId(btnId);
    if (!inp || !btn) return;
    var apply = function (forced) {
      var raw = String(forced != null ? forced : inp.value).trim().toLowerCase();
      var val;
      if (allowMax && (raw === 'max' || raw === '最大')) {
        val = 'max';
      } else {
        val = raw.replace(/[^0-9]/g, '');
        if (!val) { toast(label + '不能为空' + (allowMax ? '（可填 max）' : '')); return; }
      }
      api('set', key, val).then(function (r) {
        if (!r || r.ok === false) toast('设置失败：' + ((r && r.msg) || '未知错误'));
        else toast(label + ' 已设为 ' + val);
        return refresh();
      });
    };
    btn.addEventListener('click', function () { apply(); });
    inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') apply(); });
    if (allowMax) {
      var bx = byId(inputId + '_max') || byId(btnId + '_max');
      if (bx) bx.addEventListener('click', function () { inp.value = 'max'; apply('max'); });
    }
  }

  /* 文本型配置：不能按数字清洗，例如 CIDR 里有点和斜杠 */
  function bindText(inputId, btnId, key, label) {
    var inp = byId(inputId), btn = byId(btnId);
    if (!inp || !btn) return;
    var apply = function () {
      var raw = String(inp.value).trim();
      if (raw !== '' && !/^[0-9]{1,3}(\.[0-9]{1,3}){3}\/[0-9]{1,2}$/.test(raw)) {
        toast(label + ' 格式应为 192.168.2.0/24，或留空表示不限制');
        return;
      }
      api('set', key, raw).then(function (r) {
        if (!r || r.ok === false) toast('设置失败：' + ((r && r.msg) || '未知错误'));
        else toast(label + ' 已设为 ' + (raw || '不限制'));
        return refresh();
      });
    };
    btn.addEventListener('click', apply);
    inp.addEventListener('keydown', function (e) { if (e.key === 'Enter') apply(); });
  }

  function bindSeg(segId, key) {
    var seg = byId(segId);
    if (!seg) return;
    Array.prototype.forEach.call(seg.querySelectorAll('button'), function (b) {
      b.addEventListener('click', function () {
        api('set', key, b.getAttribute('data-v')).then(function () { refresh(); });
      });
    });
  }

  function init() {
    BRIDGE = detectBridge();
    initTabs();

    /* 页签一 */
    VOLS.forEach(function (k) {
      bindSwitch('sw_vol_' + k + '_on', 'vol_' + k + '_on');
      bindNumber('in_vol_' + k, 'btn_vol_' + k, 'vol_' + k, VOL_LABEL[k] + '目标音量', true);
    });
    bindSeg('seg_vol_mode', 'vol_mode');

    var volNow = byId('btn_vol_now');
    if (volNow) {
      volNow.addEventListener('click', function () {
        api('vol-now').then(function (r) { toast((r && r.msg) || '已执行'); return refresh(); });
      });
    }

    bindSwitch('sw_ring_normal', 'ring_normal');
    bindSwitch('sw_ring_dnd', 'ring_dnd');
    bindSwitch('sw_wifi_keep', 'wifi_keep');
    bindSwitch('sw_wifi_reconnect', 'wifi_reconnect');
    bindSwitch('sw_adb_tcp', 'adb_tcp');
    bindSwitch('sw_adb_noauth', 'adb_noauth');
    bindSwitch('sw_nfc_auto', 'nfc_auto');

    bindNumber('in_adb_port', 'btn_adb_port', 'adb_port', '无线调试端口', false);
    bindText('in_adb_allow', 'btn_adb_allow', 'adb_allow', '来源网段');
    bindNumber('in_nfc_minutes', 'btn_nfc_minutes', 'nfc_minutes', 'NFC 关闭延时', false);
    bindNumber('in_usage_keep_days', 'btn_usage_keep_days', 'usage_keep_days', '归档保留天数', false);

    var nfcOff = byId('btn_nfc_off');
    if (nfcOff) {
      nfcOff.addEventListener('click', function () {
        api('nfc-off').then(function (r) { toast((r && r.msg) || '已执行'); return refresh(); });
      });
    }

    /* 页签二 */
    bindSwitch('sw_install', 'install_block');
    bindSwitch('sw_wechat_guard', 'wechat_guard');
    bindSwitch('sw_wechat_block_finder', 'wechat_block_finder');
    bindSwitch('sw_wechat_block_misc', 'wechat_block_misc');
    bindSwitch('sw_wechat_keepalive', 'wechat_keepalive');
    bindSeg('seg_wx_mode', 'wechat_mode');
    initApkUpload();

    /* 页签二：小程序 / 快应用管控 */
    bindSwitch('sw_mp_guard', 'mp_guard');
    bindSwitch('sw_mp_quickapp', 'mp_quickapp');
    bindSwitch('sw_mp_wx', 'mp_wx');
    bindSwitch('sw_mp_alipay', 'mp_alipay');
    bindSwitch('sw_mp_byte', 'mp_byte');
    bindSwitch('sw_mp_baidu', 'mp_baidu');
    bindSwitch('sw_mp_toast', 'mp_toast');
    bindSeg('seg_mp_default', 'mp_default');
    bindSeg('seg_mp_action', 'mp_action');
    initMp();

    /* 微信网页（域名）管控：总开关 / 默认策略 / 有效期 + 名单事件 */
    bindSwitch('sw_web_guard', 'web_guard');
    bindSeg('seg_web_default', 'web_default');
    bindNumber('in_web_fresh', 'btn_web_fresh', 'web_fresh', '网址判定有效期', false);
    initWeb();

    /* 页签三 */
    bindSwitch('sw_usage_track', 'usage_track');
    bindSwitch('sw_usage_limit', 'usage_limit');
    bindSwitch('sw_toast_on', 'toast_on');
    bindSeg('seg_limit_action', 'limit_action');
    initLimits();
    initUsageActions();

    /* 页签四 */
    bindSwitch('sw_webui_autostart', 'webui_autostart');
    bindSwitch('sw_debug_trace', 'debug_trace');

    /* 内置 adb 白名单公钥：复制 / 下载 */
    var kCopy = byId('btn_adbkey_copy');
    if (kCopy) kCopy.addEventListener('click', function () { copyText(ADBKEY_TXT, '公钥已复制到剪贴板'); });
    var kDl = byId('btn_adbkey_dl');
    if (kDl) kDl.addEventListener('click', downloadAdbkey);
    loadAdbkey();

    /* 访问密码：保存（清空输入＝清除密码）。请求本身要过闸门 ——
       改密码必须先输对当前密码，否则网页 CSRF 可以直接把密码改掉 */
    var upBtn = byId('btn_ui_pass');
    if (upBtn) {
      upBtn.addEventListener('click', function () {
        var inp = byId('in_ui_pass');
        var v = String((inp && inp.value) || '');
        if (v.length > 0 && v.length < 4) { toast('密码至少 4 位（留空＝清除密码）'); return; }
        var h = v ? sha256hex(v) : '';
        api('set', 'ui_pass', h).then(function (r) {
          if (!r || r.ok === false) {
            if (r && r.auth === 1) showGate('');
            else toast('设置失败：' + ((r && r.msg) || '未知错误'));
            return;
          }
          if (inp) inp.value = '';
          toast(v ? '访问密码已更新，请牢记' : '访问密码已清除');
          PASS = h;          // 本页凭证同步更新，避免下一次轮询撞上闸门
          return refresh();
        });
      });
    }

    /* 密码闸门 */
    var gBtn = byId('btn_gate_ok');
    if (gBtn) gBtn.addEventListener('click', tryGate);
    var gInp = byId('gate_pass');
    if (gInp) {
      gInp.addEventListener('keydown', function (e) { if (e.key === 'Enter') tryGate(); });
    }

    byId('btn_refresh').addEventListener('click', function () { refresh().then(function () { toast('已刷新'); }); });

    byId('btn_clear').addEventListener('click', function () {
      api('clear-log').then(function () { toast('日志已清空'); return refresh(); });
    });

    var stopBtn = byId('btn_stop');
    if (!BRIDGE && stopBtn) {
      stopBtn.addEventListener('click', function () {
        api('stop-webui').then(function () {
          document.body.innerHTML =
            '<div style="padding:60px 20px;text-align:center;color:#8b93a7;font-family:sans-serif">' +
            '<div style="font-size:17px;color:#e7eaf0;margin-bottom:8px">WebUI 服务已关闭</div>' +
            '<div style="font-size:13px">需要再次进入时，点击 Magisk 模块卡片上的『操作』按钮</div></div>';
        });
      });
    } else if (stopBtn) {
      byId('webui_actions').style.display = 'none';
    }

    refresh();
    if (!TIMER) TIMER = setInterval(refresh, 5000);
    /* NFC 倒计时本地每秒递减，避免只能 5 秒跳一次 */
    setInterval(function () {
      if (REMAIN > 0) {
        REMAIN--;
        var el = byId('d_nfc');
        if (el && el.textContent.indexOf('剩余') >= 0) {
          el.textContent = el.textContent.replace(/剩余 [^后]*后/, '剩余 ' + fmtSec(REMAIN) + ' 后');
        }
      }
    }, 1000);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
