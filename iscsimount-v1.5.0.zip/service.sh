#!/system/bin/sh
# Magisk late_start service：开机自动挂载
#
# 顺序：等 boot_completed → 等 zygote → 等目标可达 → ctl.sh start（带重试）
# 为什么要等网络：iSCSI 目标在 WiFi 上的 NAS，late_start 时 WiFi 常常还没连上；
#   不等就会连不上、当次自启静默失败（这是"重启后没挂上"最常见的原因）。
# 为什么要重试：ctl.sh start 内部会先 umount/kill/detach 再挂，可安全重复调用。

# MODDIR 归一化成绝对路径（Magisk 一般传绝对路径，这里兜底）
SELF=$0
case "$SELF" in
  /*) : ;;
  *)  SELF=$PWD/$SELF ;;
esac
MODDIR=${SELF%/*}

DATA=/data/adb/iscsimount
LOG=$DATA/log/service.log
mkdir -p "$DATA/log" 2>/dev/null

log() { echo "$(date '+%Y-%m-%d %H:%M:%S') [service] $*" >> "$LOG"; }
log "启动 (MODDIR=$MODDIR)"

# 1) 等系统启动完成
i=0
while [ "$(getprop sys.boot_completed)" != "1" ] && [ $i -lt 180 ]; do
  sleep 1
  i=$((i + 1))
done

# 2) 等 zygote 就绪（nsenter 要用它的 mount namespace）
i=0
while [ -z "$(pidof zygote64 2>/dev/null)$(pidof zygote 2>/dev/null)" ] && [ $i -lt 60 ]; do
  sleep 1
  i=$((i + 1))
done

# 3) 等目标可达。ping 只作"提前放行"提示，超时也继续（由 start 的重试兜底，
#    避免 NAS 屏蔽 ICMP 时误判为不可达而白等）。
host=$(sed -n 's/^host=//p' "$DATA/config.conf" 2>/dev/null | head -n 1)
[ -z "$host" ] && host=192.168.2.5
i=0
while [ $i -lt 60 ]; do
  if ping -c 1 -W 2 "$host" >/dev/null 2>&1; then
    log "目标 $host 可达（等待 ${i}s）"
    break
  fi
  sleep 1
  i=$((i + 1))
done
[ $i -ge 60 ] && log "等待 $host 超时，仍继续尝试挂载"

sleep 3

# 4) 执行挂载（最多 6 次，每次间隔 10s）
if [ -x "$MODDIR/bin/ctl.sh" ]; then
  n=0
  while [ $n -lt 6 ]; do
    MODDIR="$MODDIR" sh "$MODDIR/bin/ctl.sh" start >> "$LOG" 2>&1
    rc=$?
    log "ctl start rc=$rc（第 $((n + 1)) 次）"
    [ "$rc" = "0" ] && break
    n=$((n + 1))
    sleep 10
  done
  [ "$rc" = "0" ] && log "开机自动挂载成功" || log "[ERR] 开机自动挂载失败（已重试 6 次）"
else
  log "[ERR] 缺少 $MODDIR/bin/ctl.sh"
fi

log "结束"
