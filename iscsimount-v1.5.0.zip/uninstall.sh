#!/system/bin/sh
# 卸载：先停 WebUI、再停挂载，最后清运行态数据
MODDIR=${0%/*}
case "$MODDIR" in /*) : ;; *) MODDIR=$PWD/$MODDIR ;; esac

# WebUI 的 httpd / 看门狗要先收掉，否则卸载后还会守着（端口也不释放）
if [ -x "$MODDIR/bin/webui.sh" ]; then
  MODDIR="$MODDIR" sh "$MODDIR/bin/webui.sh" stop >/dev/null 2>&1
fi
pkill -f "[i]scsimount/webroot" 2>/dev/null

if [ -x "$MODDIR/bin/ctl.sh" ]; then
  MODDIR="$MODDIR" sh "$MODDIR/bin/ctl.sh" stop
fi

# 兜底：杀掉残留守护、拆掉指向 disk.img 的 loop、卸载挂载点
pkill -f "[i]scsi_fuse" 2>/dev/null
for i in 0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59 60 61 62 63; do
  bf=$(cat "/sys/block/loop$i/loop/backing_file" 2>/dev/null)
  case "$bf" in *disk.img*) losetup -d "/dev/block/loop$i" 2>/dev/null ;; esac
done
umount /mnt/iscsidisk 2>/dev/null
umount -l /mnt/iscsidisk 2>/dev/null
umount /mnt/iscsi 2>/dev/null
umount -l /mnt/iscsi 2>/dev/null

rm -rf /data/adb/iscsimount/run /data/adb/iscsimount/log
