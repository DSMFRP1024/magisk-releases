#!/system/bin/sh
# ============================================================
# Magisk 模块页「操作」按钮 —— 打开 WebUI
#
# 为什么要这样：用户点这个按钮的意图是"进界面改配置"，不是"重启一下"。
# 早期版本这里只做 ctl.sh restart，点了没反应（用户反馈"操作没打开 webui"）。
# Magisk 的 action 只能跑一个脚本、没有交互输入，所以正确做法是
# **保证 WebUI 在跑 + 直接把手机浏览器拉到那个页面**，点一下就进去了。
#
# 挂载的启停已经放在 WebUI 里（三个按钮），所以这里不再重复做 restart。
# ============================================================
MODDIR=${0%/*}
case "$MODDIR" in /*) : ;; *) MODDIR=/data/adb/modules/iscsimount ;; esac
LOG=/data/adb/iscsimount/log/action.log
mkdir -p /data/adb/iscsimount/log 2>/dev/null

BB=""
for _c in /data/adb/magisk/busybox /data/adb/ksu/bin/busybox /data/adb/ap/bin/busybox \
          /data/adb/modules/busybox-ndk/system/bin/busybox /system/xbin/busybox; do
  if [ -x "$_c" ]; then BB=$_c; break; fi
done
[ -z "$BB" ] && BB=/system/bin/busybox

{
  echo "===== $(date '+%Y-%m-%d %H:%M:%S') action: 打开 WebUI ====="
  echo "--- webui.sh start ---"
} >> "$LOG"

MODDIR="$MODDIR" sh "$MODDIR/bin/webui.sh" start >> "$LOG" 2>&1
rc=$?

# 读回实际端口（可能与默认值不同）
PORT=$($BB grep -E '^webui_port=' /data/adb/iscsimount/config.conf 2>/dev/null \
        | $BB tail -n 1 | $BB cut -d= -f2-)
case "$PORT" in ''|*[!0-9]*) PORT=8898 ;; esac
URL="http://127.0.0.1:$PORT/"

{
  echo "--- open $URL ---"
  # 拉起手机浏览器。★ Magisk 的 action 脚本没有前台 Activity 上下文，
  #   必须补 -c BROWSABLE + 显式 action，否则部分 ROM 上 am start 直接静默失败。
  am start -a android.intent.action.VIEW -c android.intent.category.BROWSABLE -d "$URL" >> "$LOG" 2>&1
  sleep 1
  # 有些 ROM 第一次 am 会被拦（没默认浏览器/弹选择器），补一次不带 category 的
  am start -a android.intent.action.VIEW -d "$URL" >> "$LOG" 2>&1
  echo "--- 挂载状态 ---"
  MODDIR="$MODDIR" sh "$MODDIR/bin/ctl.sh" status >> "$LOG" 2>&1
} >> "$LOG" 2>&1

if [ "$rc" = "0" ]; then
  echo "已打开 WebUI：$URL"
  echo "（若没自动弹出，手动在浏览器输入这个地址；电脑端可用 iscsiMount/工具/webui.py）"
else
  echo "WebUI 启动失败，请看 $LOG"
  $BB tail -n 5 "$LOG" 2>/dev/null
fi
