#!/system/bin/sh
# Magisk 安装脚本

SKIPUNZIP=0

ui_print "- iSCSI 磁盘挂载 (iscsimount)"
ui_print "- 架构: $ARCH"

if [ "$ARCH" != "arm64" ]; then
  ui_print "!! 本模块内置的 iscsi_fuse 只编译了 arm64"
  ui_print "!! 当前架构 $ARCH，请自行交叉编译后替换 bin/iscsi_fuse"
  abort "不支持的架构: $ARCH"
fi

ui_print "- 准备配置目录 /data/adb/iscsimount"
mkdir -p /data/adb/iscsimount/run /data/adb/iscsimount/log
if [ ! -f /data/adb/iscsimount/config.conf ]; then
  cp -f "$MODPATH/bin/config.default" /data/adb/iscsimount/config.conf 2>/dev/null
  ui_print "- 已生成默认配置 config.conf"
else
  ui_print "- 保留已有 config.conf（不覆盖）"
fi

ui_print "- 设置权限"
set_perm_recursive "$MODPATH" 0 0 0755 0644
for f in "$MODPATH/bin/iscsi_fuse" "$MODPATH/bin/iscsi_probe" "$MODPATH/bin/ctl.sh" \
         "$MODPATH/bin/webui.sh" \
         "$MODPATH/service.sh" "$MODPATH/action.sh" "$MODPATH/uninstall.sh" \
         "$MODPATH/customize.sh" \
         "$MODPATH/webroot/cgi-bin/api"; do
  [ -e "$f" ] && set_perm "$f" 0 0 0755
done

# v1.2.1 去掉了访问密码（只用本机监听 + 空闲自动关闭），把旧配置里的残留键清掉。
# 用 `sed -i` 原地删行，不动其它键和注释。
if [ -f /data/adb/iscsimount/config.conf ]; then
  if grep -q '^web_pass=' /data/adb/iscsimount/config.conf 2>/dev/null; then
    sed -i '/^web_pass=/d' /data/adb/iscsimount/config.conf 2>/dev/null
    ui_print "- 已清理旧配置里的 web_pass（该功能已移除）"
  fi
fi

ui_print "- 完成。默认目标: 见 /data/adb/iscsimount/config.conf"
ui_print "- 重启后自动挂载。"
ui_print "- 改配置/挂载/看日志：点模块「操作」按钮，会自动打开网页界面。"
ui_print "- 电脑上访问: python iscsiMount/工具/webui.py -s <手机IP>:5555"
