# update.sh —— 检查更新 / 一键安装
# 清单托管在公开分发仓（设备端没有 GitHub 凭据，私有源码仓一律拉不到）
# 用法：tc update | tc update check | tc update install

UPD_OWNER=DSMFRP1024
UPD_REPO=magisk-releases
UPD_JSONNAME=tracecleaner.json
UPD_RAW="https://raw.githubusercontent.com/$UPD_OWNER/$UPD_REPO/main"
UPD_CDN="https://cdn.jsdelivr.net/gh/$UPD_OWNER/$UPD_REPO@main"
UPD_GCR="https://gcore.jsdelivr.net/gh/$UPD_OWNER/$UPD_REPO@main"
# 顺序有讲究：MI 8 实测（2026-10-23）raw 与 gcore 在国内直连不通，cdn.jsdelivr 可通。
# raw 放第一是因为它无 CDN 缓存延迟（刚发的版本立刻可见），但超时给得短，避免白等。
UPD_MIRRORS="$UPD_RAW $UPD_CDN $UPD_GCR"
UPD_TMP="$DATADIR/tmp"
UPD_CHANGELOGFILE="CHANGELOG-tracecleaner.md"

# 自包含的 JSON 转义（CLI 与 CGI 都能用，不依赖 jesc/jstr）
upd_esc() { printf '%s' "$1" | "$BB" tr -d '\n\r' | "$BB" sed -e 's/[\\"]/\\&/g'; }

# 下载器：系统 curl 优先（正规校验证书），busybox wget 兜底（不校验证书）
# upd_fetch <url> <out> [总超时秒]   —— 清单给短超时，安装包给长超时
upd_fetch() {
  _u=$1; _o=$2; _t=${3:-120}
  rm -f "$_o" 2>/dev/null
  if command -v curl >/dev/null 2>&1; then
    curl -fsSL --connect-timeout 5 -m "$_t" -o "$_o" "$_u" 2>/dev/null && [ -s "$_o" ] && return 0
  fi
  "$BB" wget -q -T "$_t" -O "$_o" "$_u" 2>/dev/null && [ -s "$_o" ] && return 0
  rm -f "$_o" 2>/dev/null
  return 1
}

upd_srcname() {
  case "$1" in
    *raw.githubusercontent*) printf 'raw' ;;
    *gcore*)                 printf 'gcore' ;;
    *cdn.jsdelivr*)          printf 'jsdelivr' ;;
    *)                       printf 'mirror' ;;
  esac
}

# 无 jq 的极简取值：只删换行（连空格删会吃掉值内部的空格），靠 sed 的 [[:space:]] 跳空白
upd_jget() {
  [ -s "$1" ] || return 1
  "$BB" tr -d '\r\n' < "$1" 2>/dev/null | "$BB" sed -n \
    -e "s/.*\"$2\"[[:space:]]*:[[:space:]]*\"\([^\"]*\)\".*/\1/p" \
    -e "s/.*\"$2\"[[:space:]]*:[[:space:]]*\([0-9][0-9]*\).*/\1/p" | "$BB" head -n 1
}

# 拉清单；成功时把所用源名（raw/jsdelivr/gcore）打到 stdout
# ★ 清单 URL 带时间戳：raw 与 jsDelivr 的边缘缓存会让刚发布的版本"看不见"，
#   加 ?ts= 让它回源。zip 不用加（URL 里已带版本号，内容固定）。
upd_meta() {
  _dst=$1
  mkdir -p "${_dst%/*}" 2>/dev/null
  _ts=$("$BB" date +%s)
  for _base in $UPD_MIRRORS; do
    if upd_fetch "$_base/$UPD_JSONNAME?ts=$_ts" "$_dst" 20; then
      upd_srcname "$_base"
      return 0
    fi
  done
  rm -f "$_dst" 2>/dev/null
  return 1
}

upd_cur_ver() { "$BB" grep '^version=' "$MODDIR/module.prop" 2>/dev/null | "$BB" cut -d= -f2; }
upd_cur_code() {
  _c=$("$BB" grep '^versionCode=' "$MODDIR/module.prop" 2>/dev/null | "$BB" cut -d= -f2)
  case "$_c" in ''|*[!0-9]*) _c=0 ;; esac
  printf '%s' "$_c"
}

# 检查更新：结果写进全局变量，返回 0=成功拿到清单 1=失败
upd_check() {
  UPD_ERR=
  mkdir -p "$UPD_TMP" 2>/dev/null
  UPD_META=$UPD_TMP/update.json
  UPD_SRC=$(upd_meta "$UPD_META") || { UPD_ERR="无法获取更新清单（设备网络不通或仓库不可达）"; return 1; }

  UPD_CUR=$(upd_cur_ver); UPD_CURC=$(upd_cur_code)
  UPD_LAT=$(upd_jget "$UPD_META" version)
  UPD_LATC=$(upd_jget "$UPD_META" versionCode)
  case "$UPD_LATC" in ''|*[!0-9]*) UPD_LATC=0 ;; esac
  [ -n "$UPD_LAT" ] || { UPD_ERR="更新清单格式异常（缺 version）"; return 1; }

  UPD_HAS=0
  [ "$UPD_LATC" -gt "$UPD_CURC" ] 2>/dev/null && UPD_HAS=1

  UPD_ZIPFILE=$(upd_jget "$UPD_META" zipFile)
  if [ -z "$UPD_ZIPFILE" ]; then
    UPD_ZIPFILE=$(upd_jget "$UPD_META" zipUrl | "$BB" sed 's|.*/||')
  fi
  UPD_CLFILE=$(upd_jget "$UPD_META" changelogFile)
  [ -n "$UPD_CLFILE" ] || UPD_CLFILE=$UPD_CHANGELOGFILE
  UPD_SIZE=$(upd_jget "$UPD_META" size)
  case "$UPD_SIZE" in ''|*[!0-9]*) UPD_SIZE=0 ;; esac
  UPD_SHA=$(upd_jget "$UPD_META" sha256)
  UPD_DATE=$(upd_jget "$UPD_META" date)
  UPD_NOTES=$(upd_jget "$UPD_META" notes)
  return 0
}

upd_json() {
  case "$UPD_HAS" in 1) _has=true ;; *) _has=false ;; esac
  printf '{"ok":true,"current":"%s","currentCode":%s,"latest":"%s","latestCode":%s,"hasUpdate":%s,"zipFile":"%s","changelogFile":"%s","size":%s,"sha256":"%s","date":"%s","notes":"%s","source":"%s","raw":"%s"}' \
    "$(upd_esc "$UPD_CUR")" "${UPD_CURC:-0}" "$(upd_esc "$UPD_LAT")" "${UPD_LATC:-0}" \
    "$_has" "$(upd_esc "$UPD_ZIPFILE")" "$(upd_esc "$UPD_CLFILE")" "${UPD_SIZE:-0}" \
    "$(upd_esc "$UPD_SHA")" "$(upd_esc "$UPD_DATE")" "$(upd_esc "$UPD_NOTES")" \
    "$(upd_esc "$UPD_SRC")" "$(upd_esc "$UPD_RAW")"
}

upd_check_human() {
  upd_check || { echo "[失败] $UPD_ERR"; return 1; }
  echo "当前版本 : $UPD_CUR（$UPD_CURC）"
  echo "最新版本 : $UPD_LAT（$UPD_LATC）  来源 $UPD_SRC"
  if [ "$UPD_HAS" = 1 ]; then
    echo "状态     : 有新版本"
    echo "发布包   : $UPD_ZIPFILE  ($(kb2human $((UPD_SIZE / 1024))))"
    echo "发布日期 : $UPD_DATE"
    [ -n "$UPD_SHA" ] && echo "sha256   : $UPD_SHA"
    [ -n "$UPD_NOTES" ] && { echo "更新说明 :"; printf '%s\n' "$UPD_NOTES" | "$BB" fold -w 76 -s | "$BB" sed 's/^/           /'; }
    echo
    echo "安装：su -c 'sh $MODDIR/bin/tc update install'   （装完需重启）"
  else
    echo "状态     : 已是最新"
  fi
  log "update check cur=$UPD_CUR lat=$UPD_LAT has=$UPD_HAS src=$UPD_SRC"
  return 0
}

# 下载 + 校验 + 安装；0=已装待重启 2=已最新 1=失败
upd_install() {
  upd_check || { echo "[失败] $UPD_ERR"; return 1; }
  if [ "$UPD_HAS" != 1 ]; then
    echo "当前 $UPD_CUR（$UPD_CURC）已是最新版本，无需安装"
    return 2
  fi
  case "$UPD_ZIPFILE" in
    ''|*/*) echo "[失败] 清单里的 zipFile 不合法：$UPD_ZIPFILE"; return 1 ;;
  esac

  mkdir -p "$UPD_TMP" 2>/dev/null
  _out=$UPD_TMP/$UPD_ZIPFILE

  # 下载 + 逐源校验：某个镜像可能仍在缓存旧包（同名 zip 曾重发过），
  # 校验不过就换下一个源，而不是直接判失败。
  _got=0; _from=
  for _base in $UPD_MIRRORS; do
    _sn=$(upd_srcname "$_base")
    echo "[下载] $_sn  $_base/$UPD_ZIPFILE"
    rm -f "$_out"
    if ! upd_fetch "$_base/$UPD_ZIPFILE" "$_out" 180; then
      echo "       不可达，换下一个"
      continue
    fi
    _sz=$("$BB" stat -c %s "$_out" 2>/dev/null)
    case "$_sz" in ''|*[!0-9]*) _sz=0 ;; esac
    echo "       收到 $_sz 字节"
    if [ "$UPD_SIZE" -gt 0 ] && [ "$_sz" != "$UPD_SIZE" ]; then
      echo "       大小与清单不符（期望 $UPD_SIZE），换下一个"
      rm -f "$_out"; continue
    fi
    if [ -n "$UPD_SHA" ]; then
      _h=$("$BB" sha256sum "$_out" 2>/dev/null | "$BB" cut -d' ' -f1)
      if [ "$_h" != "$UPD_SHA" ]; then
        echo "       sha256 不符（该源可能是缓存旧包），换下一个"
        rm -f "$_out"; continue
      fi
      echo "       sha256 一致"
    fi
    _got=1; _from=$_sn; break
  done
  if [ "$_got" != 1 ]; then
    echo "[失败] 所有镜像都没拿到与清单一致的包"
    echo "       若刚发布过新版，等 5~10 分钟让 CDN 缓存同步后重试"
    echo "       离线环境请手动 adb push 安装包后 magisk --install-module"
    rm -f "$_out"
    return 1
  fi
  echo "[来源] $_from"

  _mg=/data/adb/magisk/magisk
  [ -x "$_mg" ] || _mg=$(command -v magisk 2>/dev/null)
  if [ -z "$_mg" ] || [ ! -x "$_mg" ]; then
    echo "[失败] 找不到 magisk 可执行文件"
    rm -f "$_out"
    return 1
  fi

  echo "[安装] $_mg --install-module $UPD_ZIPFILE"
  _res=$("$_mg" --install-module "$_out" 2>&1); _rc=$?
  [ -n "$_res" ] && printf '%s\n' "$_res" | "$BB" sed 's/^/       /'
  rm -f "$_out"
  if [ "$_rc" != 0 ]; then
    echo "[失败] 安装命令返回码 $_rc"
    log "update install FAIL rc=$_rc"
    return 1
  fi
  if [ -d /data/adb/modules_update/trace_cleaner ]; then
    echo
    echo "[完成] 已安装 $UPD_LAT（$UPD_LATC）到 modules_update"
    echo "       ★ 必须重启手机才生效，重启后新版本才会替换当前模块"
    log "update install ok $UPD_LAT"
  else
    echo "[警告] 安装命令成功，但没看到 modules_update/trace_cleaner"
    echo "       请到 Magisk 应用的模块页确认"
    log "update install WARN no-modules_update $UPD_LAT"
  fi
  return 0
}

update_main() {
  case "$1" in
    ''|check|--check) upd_check_human ;;
    install|--install) upd_install ;;
    json) upd_check && upd_json ;;
    *) echo "用法：tc update [check|install|json]"; exit 2 ;;
  esac
}
